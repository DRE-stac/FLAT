import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import {
  MeshTriangle,
  ParametricConfig,
  PatternPiece,
  ShadingMode3D,
  SurfaceMesh,
  ToolMode3D,
  Vec3
} from '../types/pattern';
import { PIECE_PALETTE } from '../engine/meshGenerators';
import {
  Camera,
  Compass,
  Eye,
  Layers,
  Maximize2,
  Minimize2,
  Paintbrush,
  Scissors,
  Sparkles,
  ZoomIn,
  ZoomOut
} from 'lucide-react';

interface Viewport3DProps {
  mesh: SurfaceMesh;
  pieces: PatternPiece[];
  triangleStrainMap: Map<number, number>;
  shadingMode: ShadingMode3D;
  toolMode: ToolMode3D;
  selectedPieceId: string | null;
  hoveredTriangleId: number | null;
  activePaintPieceId: string;
  onSelectPiece: (pieceId: string | null) => void;
  onHoverTriangle: (triId: number | null) => void;
  onPaintTriangle: (triId: number, targetPieceId: string) => void;
  onSplitPiece: (pieceId: string) => void;
  onToggleShadingMode: (mode: ShadingMode3D) => void;
  onToggleToolMode: (mode: ToolMode3D) => void;
}

export const Viewport3D: React.FC<Viewport3DProps> = ({
  mesh,
  pieces,
  triangleStrainMap,
  shadingMode,
  toolMode,
  selectedPieceId,
  hoveredTriangleId,
  activePaintPieceId,
  onSelectPiece,
  onHoverTriangle,
  onPaintTriangle,
  onSplitPiece,
  onToggleShadingMode,
  onToggleToolMode
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const meshObjectRef = useRef<THREE.Mesh | null>(null);
  const wireframeRef = useRef<THREE.LineSegments | null>(null);
  const isDraggingRef = useRef(false);
  const isPaintingRef = useRef(false);
  const mousePrevRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const raycasterRef = useRef(new THREE.Raycaster());
  const mouseVecRef = useRef(new THREE.Vector2());

  // Camera spherical coordinates
  const sphericalRef = useRef({ radius: 750, phi: Math.PI / 3, theta: Math.PI / 4 });
  const targetRef = useRef(new THREE.Vector3(0, 0, 0));
  const lastLoadedModelNameRef = useRef<string>('');

  const [hoveredTriInfo, setHoveredTriInfo] = useState<{
    id: number;
    pieceId: string;
    area: number;
    strain: number;
  } | null>(null);

  const [gpuError,setGpuError]=useState(false);

  // Initialize Three.js scene
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth || 800;
    const height = container.clientHeight || 600;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0c1017);
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(40, width / height, 0.01, 1000000);
    cameraRef.current = camera;

    let renderer:THREE.WebGLRenderer;
    try {renderer=new THREE.WebGLRenderer({antialias:true,alpha:false,powerPreference:'high-performance'});} catch {setGpuError(true);return;}
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = false;
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Ambient & Studio Directional 3-Point Lighting
    const ambientLight = new THREE.AmbientLight(0xdde6ed, 0.7);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xffffff, 1.2);
    keyLight.position.set(400, 700, 600);
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0x7dd3fc, 0.6);
    fillLight.position.set(-500, 300, -300);
    scene.add(fillLight);

    const rimLight = new THREE.DirectionalLight(0xfef08a, 0.5);
    rimLight.position.set(0, -600, -500);
    scene.add(rimLight);

    // Subtle Engineering Reference Grid & Floor Disc
    const grid = new THREE.GridHelper(1200, 24, 0x1e293b, 0x0f172a);
    grid.position.y = -350;
    scene.add(grid);

    // Animation render loop
    let reqId: number;
    const render = () => {
      reqId = requestAnimationFrame(render);
      if (rendererRef.current && sceneRef.current && cameraRef.current) {
        // Update camera position from spherical coordinates
        const s = sphericalRef.current;
        const x = s.radius * Math.sin(s.phi) * Math.sin(s.theta);
        const y = s.radius * Math.cos(s.phi);
        const z = s.radius * Math.sin(s.phi) * Math.cos(s.theta);
        cameraRef.current.position.set(targetRef.current.x + x, targetRef.current.y + y, targetRef.current.z + z);
        cameraRef.current.lookAt(targetRef.current);

        rendererRef.current.render(sceneRef.current, cameraRef.current);
      }
    };
    render();

    const handleResize = () => {
      if (!container || !rendererRef.current || !cameraRef.current) return;
      const w = container.clientWidth;
      const h = Math.max(1,container.clientHeight);
      const previousAspect=cameraRef.current.aspect;
      cameraRef.current.aspect = Math.max(1,w) / h;
      sphericalRef.current.radius *= Math.min(1,previousAspect)/Math.min(1,cameraRef.current.aspect);
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(w, h);
    };

    const observer=new ResizeObserver(handleResize);
    observer.observe(container);

    return () => {
      cancelAnimationFrame(reqId);
      observer.disconnect();
      scene.traverse((obj)=>{const m=obj as THREE.Mesh;m.geometry?.dispose();if(Array.isArray(m.material))m.material.forEach(x=>x.dispose());else m.material?.dispose();});
      if (rendererRef.current && renderer.domElement) {
        container.removeChild(renderer.domElement);
        rendererRef.current.dispose();
      }
    };
  }, []);

  // Helper: Strain color map (compression: Cyan/Blue -> 0%: Neutral Slate -> stretch: Amber/Red)
  const getStrainColor = (strain: number): THREE.Color => {
    const c = new THREE.Color();
    if (Math.abs(strain) < 0.2) {
      c.setRGB(0.18, 0.22, 0.28); // Neutral dark slate
    } else if (strain > 0) {
      // Stretch: Amber to Crimson Red
      const t = Math.min(1.0, strain / 5.0);
      c.setRGB(0.25 + 0.75 * t, 0.35 * (1 - t * 0.7), 0.1);
    } else {
      // Compression: Teal to Deep Cyan
      const t = Math.min(1.0, -strain / 5.0);
      c.setRGB(0.08, 0.45 + 0.4 * t, 0.7 + 0.3 * t);
    }
    return c;
  };

  // Helper: Curvature color map (positive synclastic dome: Blue, zero developable: Charcoal, negative anticlastic saddle: Magenta)
  const getCurvatureColor = (curv: number): THREE.Color => {
    const c = new THREE.Color();
    if (curv > 0.1) {
      const t = Math.min(1, curv);
      c.setRGB(0.1, 0.3 + 0.4 * t, 0.85);
    } else if (curv < -0.1) {
      const t = Math.min(1, -curv);
      c.setRGB(0.85, 0.2, 0.4 + 0.4 * t);
    } else {
      c.setRGB(0.15, 0.2, 0.24);
    }
    return c;
  };

  // 1. Build Geometry & Wireframe when 3D Mesh changes (DO NOT reset zoom unless a new model was loaded)
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;

    if (meshObjectRef.current) {
      scene.remove(meshObjectRef.current);
      meshObjectRef.current.geometry.dispose();
      (meshObjectRef.current.material as THREE.Material).dispose();
      meshObjectRef.current = null;
    }
    if (wireframeRef.current) {
      scene.remove(wireframeRef.current);
      wireframeRef.current.geometry.dispose();
      (wireframeRef.current.material as THREE.Material).dispose();
      wireframeRef.current = null;
    }

    const geometry = new THREE.BufferGeometry();
    const positions = new Float32Array(mesh.triangles.length * 9);
    const normals = new Float32Array(mesh.triangles.length * 9);
    const colors = new Float32Array(mesh.triangles.length * 9);
    const wirePositions = new Float32Array(mesh.triangles.length * 18);

    for (let i = 0; i < mesh.triangles.length; i++) {
      const tri = mesh.triangles[i];
      const p0 = mesh.vertices[tri.v0];
      const p1 = mesh.vertices[tri.v1];
      const p2 = mesh.vertices[tri.v2];

      const pIdx = i * 9;
      positions[pIdx] = p0.x;
      positions[pIdx + 1] = p0.y;
      positions[pIdx + 2] = p0.z;
      positions[pIdx + 3] = p1.x;
      positions[pIdx + 4] = p1.y;
      positions[pIdx + 5] = p1.z;
      positions[pIdx + 6] = p2.x;
      positions[pIdx + 7] = p2.y;
      positions[pIdx + 8] = p2.z;

      normals[pIdx] = tri.normal.x;
      normals[pIdx + 1] = tri.normal.y;
      normals[pIdx + 2] = tri.normal.z;
      normals[pIdx + 3] = tri.normal.x;
      normals[pIdx + 4] = tri.normal.y;
      normals[pIdx + 5] = tri.normal.z;
      normals[pIdx + 6] = tri.normal.x;
      normals[pIdx + 7] = tri.normal.y;
      normals[pIdx + 8] = tri.normal.z;

      // Default slate neutral colors
      for (let k = 0; k < 9; k += 3) {
        colors[pIdx + k] = 0.22;
        colors[pIdx + k + 1] = 0.28;
        colors[pIdx + k + 2] = 0.36;
      }

      // Wireframe segments
      const wIdx = i * 18;
      wirePositions[wIdx] = p0.x;
      wirePositions[wIdx + 1] = p0.y;
      wirePositions[wIdx + 2] = p0.z;
      wirePositions[wIdx + 3] = p1.x;
      wirePositions[wIdx + 4] = p1.y;
      wirePositions[wIdx + 5] = p1.z;

      wirePositions[wIdx + 6] = p1.x;
      wirePositions[wIdx + 7] = p1.y;
      wirePositions[wIdx + 8] = p1.z;
      wirePositions[wIdx + 9] = p2.x;
      wirePositions[wIdx + 10] = p2.y;
      wirePositions[wIdx + 11] = p2.z;

      wirePositions[wIdx + 12] = p2.x;
      wirePositions[wIdx + 13] = p2.y;
      wirePositions[wIdx + 14] = p2.z;
      wirePositions[wIdx + 15] = p0.x;
      wirePositions[wIdx + 16] = p0.y;
      wirePositions[wIdx + 17] = p0.z;
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('normal', new THREE.BufferAttribute(normals, 3));
    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const material = new THREE.MeshStandardMaterial({
      vertexColors: true,
      roughness: 0.65,
      metalness: 0.1,
      side: THREE.DoubleSide
    });

    const meshObj = new THREE.Mesh(geometry, material);
    scene.add(meshObj);
    meshObjectRef.current = meshObj;

    const wireGeom = new THREE.BufferGeometry();
    wireGeom.setAttribute('position', new THREE.BufferAttribute(wirePositions, 3));
    const wireMat = new THREE.LineBasicMaterial({
      color: 0x000000,
      transparent: true,
      opacity: 0.18
    });
    const wireObj = new THREE.LineSegments(wireGeom, wireMat);
    scene.add(wireObj);
    wireframeRef.current = wireObj;

    // ONLY adjust camera zoom if a new model was loaded (never on re-renders/hovers)
    if (lastLoadedModelNameRef.current !== mesh.name) {
      const maxDimension = Math.max(mesh.boundingBox.size.x, mesh.boundingBox.size.y, mesh.boundingBox.size.z);
      sphericalRef.current.radius = Math.max(1,maxDimension*1.9/Math.min(1,cameraRef.current?.aspect||1));
      targetRef.current.set((mesh.boundingBox.min.x+mesh.boundingBox.max.x)/2,(mesh.boundingBox.min.y+mesh.boundingBox.max.y)/2,(mesh.boundingBox.min.z+mesh.boundingBox.max.z)/2);
      lastLoadedModelNameRef.current = mesh.name;
    }
  }, [mesh]);

  // 2. Fast In-Place Vertex Color Update (Hover, Selection, Shading Mode, Strain Map)
  useEffect(() => {
    const meshObj = meshObjectRef.current;
    if (!meshObj) return;

    const colorAttr = meshObj.geometry.getAttribute('color') as THREE.BufferAttribute | undefined;
    if (!colorAttr) return;

    const colorArray = colorAttr.array as Float32Array;

    const pieceColorMap = new Map<string, THREE.Color>();
    pieces.forEach((p) => {
      pieceColorMap.set(p.id, new THREE.Color(p.color));
    });

    for (let i = 0; i < mesh.triangles.length; i++) {
      const tri = mesh.triangles[i];
      const isHovered = hoveredTriangleId === tri.id;
      const isPieceSelected = selectedPieceId === tri.pieceId;

      let r = 0.22, g = 0.28, b = 0.36;

      if (shadingMode === 'panels') {
        const base = pieceColorMap.get(tri.pieceId) || new THREE.Color(0x38bdf8);
        r = base.r;
        g = base.g;
        b = base.b;

        if (selectedPieceId && !isPieceSelected) {
          r *= 0.35;
          g *= 0.35;
          b *= 0.35;
        }
      } else if (shadingMode === 'strain') {
        const sVal = triangleStrainMap.get(tri.id) ?? 0;
        const sColor = getStrainColor(sVal);
        r = sColor.r;
        g = sColor.g;
        b = sColor.b;
      } else if (shadingMode === 'curvature') {
        const cVal = mesh.vertexCurvature[tri.v0] || 0;
        const cColor = getCurvatureColor(cVal);
        r = cColor.r;
        g = cColor.g;
        b = cColor.b;
      } else {
        // Material weave mode
        r = 0.14;
        g = 0.18;
        b = 0.24;
      }

      if (isHovered) {
        r = Math.min(1.0, r + 0.38);
        g = Math.min(1.0, g + 0.38);
        b = Math.min(1.0, b + 0.38);
      }

      const pIdx = i * 9;
      // 3 vertices per triangle
      for (let k = 0; k < 9; k += 3) {
        colorArray[pIdx + k] = r;
        colorArray[pIdx + k + 1] = g;
        colorArray[pIdx + k + 2] = b;
      }
    }

    colorAttr.needsUpdate = true;
  }, [mesh, pieces, triangleStrainMap, shadingMode, selectedPieceId, hoveredTriangleId]);

  // Mouse & Orbit Camera Interaction Handlers
  const handlePointerDown = (e: React.PointerEvent) => {
    isDraggingRef.current = true;
    mousePrevRef.current = { x: e.clientX, y: e.clientY };

    if (toolMode === 'paint_piece') {
      isPaintingRef.current = true;
      executeRaycastAction(e.clientX, e.clientY);
    }
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    const rect = mountRef.current?.getBoundingClientRect();
    if (!rect) return;

    mouseVecRef.current.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    mouseVecRef.current.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    if (isDraggingRef.current) {
      const dx = e.clientX - mousePrevRef.current.x;
      const dy = e.clientY - mousePrevRef.current.y;
      mousePrevRef.current = { x: e.clientX, y: e.clientY };

      if (e.buttons === 1 && !isPaintingRef.current) {
        // Orbit rotation
        sphericalRef.current.theta -= dx * 0.007;
        sphericalRef.current.phi = Math.max(0.08, Math.min(Math.PI - 0.08, sphericalRef.current.phi - dy * 0.007));
      } else if (e.buttons === 2 || e.buttons === 4 || (e.buttons === 1 && e.shiftKey)) {
        // Pan
        const factor = sphericalRef.current.radius * 0.0012;
        const forward = new THREE.Vector3();
        cameraRef.current?.getWorldDirection(forward);
        const right = new THREE.Vector3().crossVectors(forward, new THREE.Vector3(0, 1, 0)).normalize();
        targetRef.current.addScaledVector(right, -dx * factor);
        targetRef.current.y += dy * factor;
      }

      if (isPaintingRef.current && toolMode === 'paint_piece') {
        executeRaycastAction(e.clientX, e.clientY);
      }
    } else {
      // Hover raycasting
      updateHoverRaycast();
    }
  };

  const handlePointerUp = () => {
    isDraggingRef.current = false;
    isPaintingRef.current = false;
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    sphericalRef.current.radius = Math.max(
      0.5,
      Math.min(100000, sphericalRef.current.radius * Math.exp(e.deltaY*0.001))
    );
  };

  const handleClick = (e: React.MouseEvent) => {
    // Only fire click if pointer did not drag
    executeRaycastAction(e.clientX, e.clientY);
  };

  const executeRaycastAction = (clientX: number, clientY: number) => {
    const rect = mountRef.current?.getBoundingClientRect();
    if (!rect || !cameraRef.current || !meshObjectRef.current) return;

    mouseVecRef.current.x = ((clientX - rect.left) / rect.width) * 2 - 1;
    mouseVecRef.current.y = -((clientY - rect.top) / rect.height) * 2 + 1;

    raycasterRef.current.setFromCamera(mouseVecRef.current, cameraRef.current);
    const intersects = raycasterRef.current.intersectObject(meshObjectRef.current);

    if (intersects.length > 0 && typeof intersects[0].faceIndex === 'number') {
      const triIndex = intersects[0].faceIndex;
      const tri = mesh.triangles[triIndex];
      if (!tri) return;

      if (toolMode === 'inspect') {
        onSelectPiece(selectedPieceId === tri.pieceId ? null : tri.pieceId);
      } else if (toolMode === 'paint_piece') {
        onPaintTriangle(tri.id, activePaintPieceId);
      } else if (toolMode === 'split_dart') {
        onSplitPiece(tri.pieceId);
      }
    }
  };

  const updateHoverRaycast = () => {
    if (!cameraRef.current || !meshObjectRef.current) return;
    raycasterRef.current.setFromCamera(mouseVecRef.current, cameraRef.current);
    const intersects = raycasterRef.current.intersectObject(meshObjectRef.current);

    if (intersects.length > 0 && typeof intersects[0].faceIndex === 'number') {
      const triIndex = intersects[0].faceIndex;
      const tri = mesh.triangles[triIndex];
      if (tri) {
        onHoverTriangle(tri.id);
        const strainVal = triangleStrainMap.get(tri.id) ?? 0;
        setHoveredTriInfo({
          id: tri.id,
          pieceId: tri.pieceId,
          area: tri.area3D,
          strain: strainVal
        });
        return;
      }
    }

    onHoverTriangle(null);
    setHoveredTriInfo(null);
  };

  // Preset Camera Angles
  const setCameraView = (view: 'iso' | 'front' | 'side' | 'top' | 'fit') => {
    targetRef.current.set((mesh.boundingBox.min.x+mesh.boundingBox.max.x)/2,(mesh.boundingBox.min.y+mesh.boundingBox.max.y)/2,(mesh.boundingBox.min.z+mesh.boundingBox.max.z)/2);
    const maxDim = Math.max(mesh.boundingBox.size.x, mesh.boundingBox.size.y, mesh.boundingBox.size.z);
    const rad = Math.max(1,maxDim*1.9/Math.min(1,cameraRef.current?.aspect||1));
    sphericalRef.current.radius = rad;

    if (view === 'iso') {
      sphericalRef.current.phi = Math.PI / 3;
      sphericalRef.current.theta = Math.PI / 4;
    } else if (view === 'front') {
      sphericalRef.current.phi = Math.PI / 2;
      sphericalRef.current.theta = 0;
    } else if (view === 'side') {
      sphericalRef.current.phi = Math.PI / 2;
      sphericalRef.current.theta = Math.PI / 2;
    } else if (view === 'top') {
      sphericalRef.current.phi = 0.05;
      sphericalRef.current.theta = 0;
    } else if (view === 'fit') {
      sphericalRef.current.phi = Math.PI / 3;
      sphericalRef.current.theta = Math.PI / 4;
      sphericalRef.current.radius = rad;
    }
  };

  return (
    <div
      ref={mountRef}
      className="relative w-full h-full select-none overflow-hidden bg-[#0C1017] cursor-grab active:cursor-grabbing"
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onWheel={handleWheel}
      onClick={handleClick}
      onContextMenu={(e) => e.preventDefault()}
    >
      {gpuError&&<div role="alert" className="absolute inset-0 flex items-center justify-center p-8 text-center text-sm text-amber-200">3D graphics unavailable. Enable WebGL or use the 2D Pattern Table.</div>}
      {/* Top Floating Control Bar: Shading & Interaction Modes */}
      <div onPointerDown={e=>e.stopPropagation()} onClick={e=>e.stopPropagation()} className="viewport-toolbar absolute top-3 left-3 z-10 flex flex-col items-start gap-2 pointer-events-auto">
        {/* Shading Mode Segmented Control */}
        <div className="flex items-center p-1 bg-slate-900/90 backdrop-blur-md border border-slate-800 rounded-lg shadow-xl">
          <button
            onClick={() => onToggleShadingMode('panels')}
            className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              shadingMode === 'panels'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Inspect 3D pattern pieces and seam boundaries"
          >
            Pattern Panels
          </button>
          <button
            onClick={() => onToggleShadingMode('strain')}
            className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              shadingMode === 'strain'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Inspect 3D stretch & compression strain heatmap"
          >
            Strain Heatmap
          </button>
          <button
            onClick={() => onToggleShadingMode('curvature')}
            className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              shadingMode === 'curvature'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Inspect Gaussian curvature (developable vs non-developable)"
          >
            Curvature
          </button>
          <button
            onClick={() => onToggleShadingMode('material')}
            className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              shadingMode === 'material'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Preview realistic material texture"
          >
            Material Weave
          </button>
        </div>

        {/* 3D Tool Mode Control */}
        <div className="flex items-center p-1 bg-slate-900/90 backdrop-blur-md border border-slate-800 rounded-lg shadow-xl">
          <button
            onClick={() => onToggleToolMode('inspect')}
            className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              toolMode === 'inspect'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Click to select piece and inspect local geometry"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Inspect</span>
          </button>
          <button
            onClick={() => onToggleToolMode('paint_piece')}
            className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              toolMode === 'paint_piece'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Paint or reassign 3D triangles to customize seams"
          >
            <Paintbrush className="w-3.5 h-3.5" />
            <span>Paint Seam</span>
          </button>
          <button
            onClick={() => onToggleToolMode('split_dart')}
            className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              toolMode === 'split_dart'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Split piece or cut relief dart to alleviate high strain"
          >
            <Scissors className="w-3.5 h-3.5" />
            <span>Relief Dart</span>
          </button>
        </div>
      </div>

      {/* Top Right: Camera Presets HUD */}
      <div onPointerDown={e=>e.stopPropagation()} onClick={e=>e.stopPropagation()} className="absolute bottom-12 left-3 z-10 flex items-center gap-1 p-1 bg-slate-900/90 backdrop-blur-md border border-slate-800 rounded-lg shadow-xl pointer-events-auto">
        <button
          onClick={() => setCameraView('iso')}
          className="px-2 py-1 text-[11px] font-mono font-medium text-slate-300 hover:text-white rounded hover:bg-slate-800 transition-colors"
          title="Isometric View"
        >
          ISO
        </button>
        <button
          onClick={() => setCameraView('front')}
          className="px-2 py-1 text-[11px] font-mono font-medium text-slate-300 hover:text-white rounded hover:bg-slate-800 transition-colors"
          title="Front View"
        >
          FRONT
        </button>
        <button
          onClick={() => setCameraView('side')}
          className="px-2 py-1 text-[11px] font-mono font-medium text-slate-300 hover:text-white rounded hover:bg-slate-800 transition-colors"
          title="Side View"
        >
          SIDE
        </button>
        <button
          onClick={() => setCameraView('top')}
          className="px-2 py-1 text-[11px] font-mono font-medium text-slate-300 hover:text-white rounded hover:bg-slate-800 transition-colors"
          title="Top View"
        >
          TOP
        </button>
        <button
          onClick={() => setCameraView('fit')}
          className="p-1 text-slate-300 hover:text-white rounded hover:bg-slate-800 transition-colors"
          title="Zoom to Fit"
        >
          <Maximize2 className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Bottom Left: Live Raycast Surface Inspector */}
      {hoveredTriInfo && (
        <div className="absolute bottom-3 left-3 z-10 p-2.5 bg-slate-900/90 backdrop-blur-md border border-slate-800 rounded-lg shadow-xl text-xs font-mono pointer-events-none">
          <div className="flex items-center gap-2 text-slate-400">
            <span>Tri #{hoveredTriInfo.id}</span>
            <span>·</span>
            <span className="text-amber-400 font-medium">
              {pieces.find((p) => p.id === hoveredTriInfo.pieceId)?.name || hoveredTriInfo.pieceId}
            </span>
          </div>
          <div className="flex items-center gap-3 mt-1 text-slate-300 tabular-nums">
            <span>Area: {(hoveredTriInfo.area / 100).toFixed(2)} cm²</span>
            <span>·</span>
            <span
              className={
                Math.abs(hoveredTriInfo.strain) > 3.0
                  ? 'text-red-400 font-semibold'
                  : hoveredTriInfo.strain > 0
                  ? 'text-amber-400'
                  : 'text-cyan-400'
              }
            >
              Strain: {hoveredTriInfo.strain >= 0 ? '+' : ''}
              {hoveredTriInfo.strain.toFixed(2)}%
            </span>
          </div>
        </div>
      )}

      {/* Bottom Right: Viewport Controls Help */}
      <div className="canvas-hint absolute bottom-3 right-3 z-10 flex items-center gap-2 text-[11px] text-slate-500 font-mono pointer-events-none">
        <span>L-Click: Rotate</span>
        <span>·</span>
        <span>R-Click/Shift: Pan</span>
        <span>·</span>
        <span>Wheel: Zoom</span>
      </div>
    </div>
  );
};
