import React from 'react';
import { Download, Play, RefreshCw, Sparkles } from 'lucide-react';
import { SolverSettings } from '../types/pattern';

interface HeaderBarProps {
  layoutMode: 'split' | '3d' | '2d';
  isSolving: boolean;
  settings: SolverSettings;
  onSelectLayout: (mode: 'split' | '3d' | '2d') => void;
  onOpenExportModal: () => void;
  onRunOptimization: () => void;
  onOpenWorkflowHelp: () => void;
}

export const HeaderBar: React.FC<HeaderBarProps> = ({
  layoutMode,
  isSolving,
  settings,
  onSelectLayout,
  onOpenExportModal,
  onRunOptimization,
  onOpenWorkflowHelp
}) => {
  return (
    <header className="h-14 w-full bg-[#0B0E14] border-b border-slate-800/90 px-4 flex items-center justify-between shrink-0 select-none z-20">
      {/* Zone 1: Single text element wordmark in Display font */}
      <div className="flex items-center gap-3">
        <a href="/" className="text-lg font-bold tracking-tight text-white font-display hover:text-amber-400 transition-colors">
          OpenFlat Studio
        </a>
      </div>

      {/* Zone 2: 4 clean text navigation links / viewport layout modes */}
      <nav className="viewport-nav flex items-center gap-6 text-sm font-medium text-slate-400">
        <button
          onClick={() => onSelectLayout('split')}
          className={`hover:text-slate-200 transition-colors ${
            layoutMode === 'split' ? 'text-amber-400 font-semibold' : ''
          }`}
        >
          Split Workspace
        </button>
        <button
          onClick={() => onSelectLayout('3d')}
          className={`hover:text-slate-200 transition-colors ${
            layoutMode === '3d' ? 'text-amber-400 font-semibold' : ''
          }`}
        >
          3D Surface View
        </button>
        <button
          onClick={() => onSelectLayout('2d')}
          className={`hover:text-slate-200 transition-colors ${
            layoutMode === '2d' ? 'text-amber-400 font-semibold' : ''
          }`}
        >
          2D Pattern Table
        </button>
        <button
          onClick={onOpenWorkflowHelp}
          className="hover:text-slate-200 transition-colors text-slate-400"
        >
          Workflow Guide
        </button>
      </nav>

      {/* Zone 3: 1-2 primary actions */}
      <div className="flex items-center gap-2.5">
        <button
          onClick={onRunOptimization}
          disabled={isSolving}
          className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg shadow transition-all whitespace-nowrap ${
            isSolving
              ? 'bg-amber-600/50 text-amber-200 cursor-not-allowed'
              : 'bg-amber-500 hover:bg-amber-400 text-slate-950 hover:shadow-amber-500/25'
          }`}
        >
          {isSolving ? (
            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
          ) : (
            <Play className="w-3.5 h-3.5 fill-current" />
          )}
          <span className="solver-label">{settings.stage === 'pre_flatten' ? 'Optimize Strain' : 'Re-Run Solver'}</span>
        </button>

        <button
          onClick={onOpenExportModal}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 hover:border-slate-600 rounded-lg shadow-sm transition-all whitespace-nowrap"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export</span>
        </button>
      </div>
    </header>
  );
};
