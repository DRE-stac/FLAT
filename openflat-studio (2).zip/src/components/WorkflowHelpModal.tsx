import React, {useRef} from 'react';
import {useDialog} from './useDialog';
import { BookOpen, CheckCircle2, ChevronRight, HelpCircle, X } from 'lucide-react';

interface WorkflowHelpModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WorkflowHelpModal: React.FC<WorkflowHelpModalProps> = ({ isOpen, onClose }) => {
  const dialogRef=useRef<HTMLDivElement>(null);
  useDialog(isOpen,onClose,dialogRef);
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 select-none">
      <div ref={dialogRef} role="dialog" aria-modal="true" aria-label="Workflow guide" className="w-full max-w-2xl bg-[#0F141C] border border-slate-800 rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-amber-500/10 text-amber-400 rounded-lg">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-white">
                OpenFlat 3D-to-2D Pattern Flattening Workflow
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                The open-source digital pipeline for technical textiles, upholstery, and composites.
              </p>
            </div>
          </div>
          <button
            aria-label="Close guide"
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="px-6 pt-4 text-xs text-amber-200">Import coordinates are interpreted as millimeters with no automatic rescaling. Solver outputs are geometric estimates. Material presets are illustrative and require physical validation.</p>
        {/* Content */}
        <div className="p-6 space-y-4 overflow-y-auto text-xs text-slate-300">
          {/* Step 1 */}
          <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-lg">
            <div className="flex items-center gap-2 text-sm font-semibold text-amber-400 mb-1">
              <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-300 flex items-center justify-center text-xs">
                1
              </span>
              <span>3D Surface & Curvature Inspection</span>
            </div>
            <p className="text-slate-400 leading-relaxed pl-7">
              Select an industrial 3D model template or upload your own 3D <code className="text-slate-200">.OBJ</code> or <code className="text-slate-200">.STL</code> mesh. Switch the 3D viewport to <strong>Curvature mode</strong> to reveal synclastic (dome) and anticlastic (saddle) non-developable regions where seams or darts are physically required.
            </p>
          </div>

          {/* Step 2 */}
          <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-lg">
            <div className="flex items-center gap-2 text-sm font-semibold text-cyan-400 mb-1">
              <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-300 flex items-center justify-center text-xs">
                2
              </span>
              <span>Seam Placement & Relief Darts</span>
            </div>
            <p className="text-slate-400 leading-relaxed pl-7">
              Use the <strong>Paint Seam</strong> tool to assign 3D triangles to different pattern panels, or click <strong>Relief Dart</strong> on high-curvature areas. Slicing compound curves immediately relieves double-curvature Poisson strain and prevents fabric wrinkling.
            </p>
          </div>

          {/* Step 3 */}
          <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-lg">
            <div className="flex items-center gap-2 text-sm font-semibold text-emerald-400 mb-1">
              <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-300 flex items-center justify-center text-xs">
                3
              </span>
              <span>ExactFlat 2-Stage Physics Solver</span>
            </div>
            <p className="text-slate-400 leading-relaxed pl-7">
              • <strong>Stage 1 (Pre-Flatten):</strong> Projects 3D curved panels onto a principal tangent frame. Foreshortened surfaces will exhibit initial compression strain.<br />
              • <strong>Stage 2 (Optimize):</strong> Relaxes a geometric spring network using edge lengths and unfolded hinge distances. Preset Poisson and shear values tune heuristic weights. Young&apos;s modulus and thickness do not drive this solver; the displayed distortion is not a prediction of stress, forming pressure, wrinkling, or failure.
            </p>
          </div>

          {/* Step 4 */}
          <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-lg">
            <div className="flex items-center gap-2 text-sm font-semibold text-blue-400 mb-1">
              <span className="w-5 h-5 rounded-full bg-blue-500/20 text-blue-300 flex items-center justify-center text-xs">
                4
              </span>
              <span>Engineering Seam Allowances & Paired Notches</span>
            </div>
            <p className="text-slate-400 leading-relaxed pl-7">
              Configure the outward seam allowance offset (0mm to 25mm). The engine automatically computes outward miter-offset cutting paths and places matching numbered <strong>Alignment Notches</strong> along shared 3D seams so sewing and composite operators know exactly which edges mate during assembly.
            </p>
          </div>

          {/* Step 5 */}
          <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-lg">
            <div className="flex items-center gap-2 text-sm font-semibold text-purple-400 mb-1">
              <span className="w-5 h-5 rounded-full bg-purple-500/20 text-purple-300 flex items-center justify-center text-xs">
                5
              </span>
              <span>Roll Nesting & Multi-Format CAD Export</span>
            </div>
            <p className="text-slate-400 leading-relaxed pl-7">
              Click <strong>Auto-Nest on Roll</strong> to pack all 2D pieces onto your standard fabric roll width (e.g., 54&quot; / 1400mm or 60&quot; / 1500mm). Export directly to <strong>AutoCAD DXF</strong> with layered cutting paths for Gerber/Lectra/Eastman cutters, <strong>1:1 SVG</strong> for laser cutting, <strong>3D OBJ with baked UVs</strong>, or <strong>STL</strong> for tooling.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-800 bg-slate-950 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg transition-colors"
          >
            Got It
          </button>
        </div>
      </div>
    </div>
  );
};
