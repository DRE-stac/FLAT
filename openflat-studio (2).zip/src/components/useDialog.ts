import { useEffect } from 'react';
export function useDialog(open:boolean,close:()=>void,ref:React.RefObject<HTMLDivElement|null>) {
  useEffect(()=>{if(!open)return;const previous=document.activeElement as HTMLElement|null;
    const selectors='button:not(:disabled),input,select,a[href],[tabindex="0"]';
    const first=ref.current?.querySelector<HTMLElement>(selectors);first?.focus();
    const key=(e:KeyboardEvent)=>{if(e.key==='Escape'){e.preventDefault();close();}if(e.key==='Tab'){const all=[...(ref.current?.querySelectorAll<HTMLElement>(selectors)||[])];const first=all[0],last=all[all.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus()}}};
    document.addEventListener('keydown',key);return()=>{document.removeEventListener('keydown',key);previous?.focus()};
  },[open,close,ref]);
}
