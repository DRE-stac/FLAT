import React, { useRef } from 'react';
import {
  MaterialSpec,
  ParametricConfig,
  PatternPiece,
  SolverSettings,
  SolverSummaryMetrics,
  SurfaceMesh
} from '../types/pattern';
import { MATERIAL_LIBRARY, MODEL_TEMPLATES, PIECE_PALETTE } from '../engine/meshGenerators';
import {
  Activity,
  Box,
  ChevronDown,
  ChevronRight,
  Cpu,
  Layers,
  Play,
  RotateCcw,
  Scissors,
  Sliders,
  Sparkles,
  Upload,
  Wand2,
  Zap
} from 'lucide-react';
import { RepatternConfig } from '../types/pattern';

interface SidebarControlsProps {
  mesh: SurfaceMesh;
  pieces: PatternPiece[];
  material: MaterialSpec;
  parametricConfig: ParametricConfig;
  settings: SolverSettings;
  summary: SolverSummaryMetrics;
  selectedPieceId: string | null;
  activePaintPieceId: string;
  isSolving: boolean;
  repatternConfig: RepatternConfig;
  onSelectTemplate: (templateId: string) => void;
  onUploadCustomFile: (file: File) => void;
  onUpdateParametricConfig: (newConfig: Partial<ParametricConfig>) => void;
  onSelectMaterial: (materialId: string) => void;
  onUpdateSettings: (newSettings: Partial<SolverSettings>) => void;
  onSelectPiece: (pieceId: string | null) => void;
  onSplitPiece: (pieceId: string) => void;
  onSelectActivePaintPiece: (pieceId: string) => void;
  onRunOptimization: () => void;
  onUpdateRepatternConfig: (newConfig: Partial<RepatternConfig>) => void;
  onTriggerRepattern: () => void;
}

export const SidebarControls: React.FC<SidebarControlsProps> = ({
  mesh,
  pieces,
  material,
  parametricConfig,
  settings,
  summary,
  selectedPieceId,
  activePaintPieceId,
  isSolving,
  repatternConfig,
  onSelectTemplate,
  onUploadCustomFile,
  onUpdateParametricConfig,
  onSelectMaterial,
  onUpdateSettings,
  onSelectPiece,
  onSplitPiece,
  onSelectActivePaintPiece,
  onRunOptimization,
  onUpdateRepatternConfig,
  onTriggerRepattern
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onUploadCustomFile(file);
    }
  };

  return (
    <aside className="w-80 h-full bg-[#0D1117] border-r border-slate-800 flex flex-col shrink-0 select-none overflow-y-auto">
      {/* Section 1: 3D Surface Model & Geometry */}
      <div className="p-4 border-b border-slate-800">
        <div className="flex items-center justify-between mb-2.5">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            3D CAD Surface
          </span>
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1 text-[11px] text-amber-400 hover:text-amber-300 font-medium transition-colors"
          >
            <Upload className="w-3 h-3" />
            <span>Upload OBJ/STL</span>
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept=".obj,.stl"
            onChange={handleFileChange}
            className="hidden"
          />
        </div>

        {/* Model Template Dropdown */}
        <select
          value={mesh.templateId}
          onChange={(e) => onSelectTemplate(e.target.value)}
          className="w-full bg-slate-900 border border-slate-800 text-slate-200 text-xs rounded-lg px-2.5 py-2 font-medium focus:outline-none focus:border-amber-500 transition-colors"
        >
          {MODEL_TEMPLATES.map((t) => (
            <option key={t.id} value={t.id}>
              {t.name}
            </option>
          ))}
          {mesh.templateId === 'custom_upload' && (
            <option value="custom_upload">Custom Upload: {mesh.name}</option>
          )}
        </select>

        <p className="mt-2 text-[10px] font-mono text-slate-400">X {mesh.boundingBox.size.x.toFixed(2)} · Y {mesh.boundingBox.size.y.toFixed(2)} · Z {mesh.boundingBox.size.z.toFixed(2)} mm</p>
        <p className="mt-1 text-[10px] text-slate-500">Import uses millimeters. Scale is preserved.</p>
        {/* Parametric Adjustment Sliders (for built-in templates) */}
        {mesh.templateId !== 'custom_upload' && (
          <div className="mt-3 space-y-2 text-xs">
            <div>
              <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                <span>Curvature Intensity</span>
                <span className="font-mono text-slate-300">
                  {parametricConfig.curvatureBoost.toFixed(2)}x
                </span>
              </div>
              <input
                type="range"
                min="0.5"
                max="1.7"
                step="0.05"
                value={parametricConfig.curvatureBoost}
                onChange={(e) =>
                  onUpdateParametricConfig({ curvatureBoost: parseFloat(e.target.value) })
                }
                className="w-full accent-amber-500 h-1 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                <span>Width Scale (X)</span>
                <span className="font-mono text-slate-300">
                  {parametricConfig.scaleX.toFixed(2)}x
                </span>
              </div>
              <input
                type="range"
                min="0.7"
                max="1.4"
                step="0.05"
                value={parametricConfig.scaleX}
                onChange={(e) =>
                  onUpdateParametricConfig({ scaleX: parseFloat(e.target.value) })
                }
                className="w-full accent-amber-500 h-1 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between pt-1">
              <span className="text-[11px] text-slate-400">Mesh Density</span>
              <div className="flex items-center gap-1 p-0.5 bg-slate-900 border border-slate-800 rounded">
                <button
                  onClick={() => onUpdateParametricConfig({ resolution: 'standard' })}
                  className={`px-2 py-0.5 text-[10px] font-mono rounded ${
                    parametricConfig.resolution === 'standard'
                      ? 'bg-amber-500/20 text-amber-300'
                      : 'text-slate-400'
                  }`}
                >
                  Standard
                </button>
                <button
                  onClick={() => onUpdateParametricConfig({ resolution: 'high' })}
                  className={`px-2 py-0.5 text-[10px] font-mono rounded ${
                    parametricConfig.resolution === 'high'
                      ? 'bg-amber-500/20 text-amber-300'
                      : 'text-slate-400'
                  }`}
                >
                  Fine
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Section 1B: Repatterning & Auto-Seams (Ideal for STL & 3D Imports) */}
      <div className="p-4 border-b border-slate-800 bg-slate-900/30">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            Repattern & Seam Slicing
          </span>
          <span className="text-[10px] text-amber-400 font-mono font-medium">AUTO-SEAMS</span>
        </div>

        <p className="text-[11px] text-slate-400 mb-2.5 leading-snug">
          Partition STL surfaces into developable pattern panels using sharp crease detection, surface normal clustering, or gores.
        </p>

        {/* Algorithm Mode */}
        <div className="space-y-2 text-xs">
          <div>
            <span className="text-[11px] text-slate-400 block mb-1">Segmentation Strategy</span>
            <select
              value={repatternConfig.mode}
              onChange={(e) =>
                onUpdateRepatternConfig({ mode: e.target.value as any })
              }
              className="w-full bg-slate-900 border border-slate-800 text-slate-200 text-xs rounded-lg px-2.5 py-1.5 font-medium focus:outline-none focus:border-amber-500 transition-colors"
            >
              <option value="feature_crease">Crease Edges (Dihedral Angles)</option>
              <option value="normal_kmeans">Normal Clustering (Surface Patches)</option>
              <option value="axis_slices">Axis Gores (Longitudinal Strips)</option>
            </select>
          </div>

          {repatternConfig.mode === 'feature_crease' ? (
            <div>
              <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                <span>Crease Angle Sensitivity</span>
                <span className="font-mono text-slate-300">{repatternConfig.creaseAngleDeg}°</span>
              </div>
              <input
                type="range"
                min="20"
                max="70"
                step="2"
                value={repatternConfig.creaseAngleDeg}
                onChange={(e) =>
                  onUpdateRepatternConfig({ creaseAngleDeg: parseInt(e.target.value, 10) })
                }
                className="w-full accent-amber-500 h-1 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>
          ) : (
            <div>
              <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                <span>Target Panels Count</span>
                <span className="font-mono text-slate-300">{repatternConfig.targetPanelCount} pieces</span>
              </div>
              <div className="flex items-center gap-1">
                {[2, 3, 4, 5, 6, 8].map((num) => (
                  <button
                    key={num}
                    onClick={() => onUpdateRepatternConfig({ targetPanelCount: num })}
                    className={`flex-1 py-1 text-[11px] font-mono rounded transition-colors ${
                      repatternConfig.targetPanelCount === num
                        ? 'bg-amber-500 text-slate-950 font-bold'
                        : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                    }`}
                  >
                    {num}
                  </button>
                ))}
              </div>
            </div>
          )}

          <button
            onClick={onTriggerRepattern}
            disabled={isSolving}
            className="w-full mt-2 flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-semibold bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-300 rounded-lg transition-all shadow-sm"
          >
            <Wand2 className="w-3.5 h-3.5 text-amber-400" />
            <span>Auto-Repattern Mesh</span>
          </button>
        </div>
      </div>

      {/* Section 2: Material Mechanics Library */}
      <div className="p-4 border-b border-slate-800">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            Material Mechanics
          </span>
          <span className="text-[10px] text-slate-500 font-mono">{material.category}</span>
        </div>

        <select
          value={material.id}
          onChange={(e) => onSelectMaterial(e.target.value)}
          className="w-full bg-slate-900 border border-slate-800 text-slate-200 text-xs rounded-lg px-2.5 py-2 font-medium focus:outline-none focus:border-amber-500 transition-colors"
        >
          {MATERIAL_LIBRARY.map((m) => (
            <option key={m.id} value={m.id}>
              {m.name}
            </option>
          ))}
        </select>

        {/* Physical Properties Grid */}
        <div className="grid grid-cols-2 gap-2 mt-2.5 p-2 bg-slate-900/60 border border-slate-800/80 rounded-lg text-[11px] font-mono">
          <div>
            <span className="text-slate-500 text-[10px] block">Modulus E</span>
            <span className="text-slate-200 font-medium">{material.youngsModulusMPa} MPa</span>
          </div>
          <div>
            <span className="text-slate-500 text-[10px] block">Poisson Ratio ν</span>
            <span className="text-slate-200 font-medium">{material.poissonRatio}</span>
          </div>
          <div>
            <span className="text-slate-500 text-[10px] block">Thickness</span>
            <span className="text-slate-200 font-medium">{material.thicknessMm} mm</span>
          </div>
          <div>
            <span className="text-slate-500 text-[10px] block">Max Strain Yield</span>
            <span className="text-amber-400 font-medium">±{material.maxAllowableStrainPct}%</span>
          </div>
        </div>
      </div>

      {/* Section 3: ExactFlat 2-Stage Unwrapping & Physics Optimizer */}
      <div className="p-4 border-b border-slate-800">
        <div className="flex items-center justify-between mb-2.5">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            Flattening Solver
          </span>
          <span className="text-[10px] text-amber-400 font-mono font-medium">2-STAGE SOLVER</span>
        </div>

        {/* Solver Stage Switcher */}
        <div className="grid grid-cols-2 gap-1 p-1 bg-slate-900 border border-slate-800 rounded-lg mb-3">
          <button
            onClick={() => onUpdateSettings({ stage: 'pre_flatten' })}
            className={`py-1.5 px-2 text-xs font-medium rounded-md transition-all ${
              settings.stage === 'pre_flatten'
                ? 'bg-amber-500 text-slate-950 font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Stage 1: Pre-Flatten
          </button>
          <button
            onClick={() => onUpdateSettings({ stage: 'optimized' })}
            className={`py-1.5 px-2 text-xs font-medium rounded-md transition-all ${
              settings.stage === 'optimized'
                ? 'bg-amber-500 text-slate-950 font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Stage 2: Optimize
          </button>
        </div>

        {/* Solver Controls */}
        <div className="space-y-3 text-xs">
          <div>
            <div className="flex justify-between text-[11px] text-slate-400 mb-1">
              <span>Optimization Iterations</span>
              <span className="font-mono text-slate-300">{settings.iterations} steps</span>
            </div>
            <input
              type="range"
              min="10"
              max="100"
              step="5"
              value={settings.iterations}
              onChange={(e) => onUpdateSettings({ iterations: parseInt(e.target.value, 10) })}
              className="w-full accent-amber-500 h-1 bg-slate-800 rounded-lg cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between text-[11px] text-slate-400 mb-1">
              <span>Seam Allowance Offset</span>
              <span className="font-mono text-slate-300">{settings.seamAllowanceMm} mm</span>
            </div>
            <input
              type="range"
              min="0"
              max="25"
              step="1"
              value={settings.seamAllowanceMm}
              onChange={(e) => onUpdateSettings({ seamAllowanceMm: parseInt(e.target.value, 10) })}
              className="w-full accent-amber-500 h-1 bg-slate-800 rounded-lg cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between text-[11px] text-slate-400 mb-1">
              <span>Notches Per Seam</span>
              <span className="font-mono text-slate-300">{settings.notchCountPerSeam} marks</span>
            </div>
            <input
              type="range"
              min="0"
              max="5"
              step="1"
              value={settings.notchCountPerSeam}
              onChange={(e) =>
                onUpdateSettings({ notchCountPerSeam: parseInt(e.target.value, 10) })
              }
              className="w-full accent-amber-500 h-1 bg-slate-800 rounded-lg cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between text-[11px] text-slate-400 mb-1">
              <span>Fabric Roll Width</span>
              <span className="font-mono text-slate-300">{settings.rollWidthMm} mm</span>
            </div>
            <input
              type="number"
              min="800"
              max="3000"
              step="10"
              value={settings.rollWidthMm}
              onChange={(e) =>
                onUpdateSettings({ rollWidthMm: Math.max(500, parseInt(e.target.value, 10) || 1400) })
              }
              className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1 text-slate-200 text-xs font-mono"
            />
          </div>
        </div>
      </div>

      {/* Section 4: Pattern Pieces & Strain Inspector */}
      <div className="p-4 flex-1">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            Pattern Pieces ({pieces.length})
          </span>
          <span className="text-[10px] text-slate-500 font-mono">
            Avg Strain: {summary.overallMeanStrainPct.toFixed(1)}%
          </span>
        </div>

        <div className="space-y-1.5">
          {pieces.map((piece) => {
            const isSelected = selectedPieceId === piece.id;
            const isExceeding = Math.abs(piece.maxStretchPct) > material.maxAllowableStrainPct;

            return (
              <div
                key={piece.id}
                onClick={() => onSelectPiece(isSelected ? null : piece.id)}
                className={`p-2 rounded-lg border cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-slate-800 border-amber-500/80 shadow-md'
                    : 'bg-slate-900/50 border-slate-800/80 hover:bg-slate-800/50'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-2">
                    <span
                      className="w-2.5 h-2.5 rounded-full shrink-0"
                      style={{ backgroundColor: piece.color }}
                    />
                    <span className="text-xs font-medium text-slate-200 truncate max-w-[140px]">
                      {piece.name}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    {/* Split dart action button */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSplitPiece(piece.id);
                      }}
                      className="p-1 text-slate-500 hover:text-amber-400 rounded transition-colors"
                      title="Split Piece / Dart to relieve strain"
                    >
                      <Scissors className="w-3 h-3" />
                    </button>
                    <span
                      className={`text-[11px] font-mono font-medium ${
                        isExceeding
                          ? 'text-red-400'
                          : piece.meanStrainPct > 0
                          ? 'text-amber-400'
                          : 'text-cyan-400'
                      }`}
                    >
                      {piece.meanStrainPct.toFixed(1)}%
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono">
                  <span>{(piece.area2DMm2 / 100).toFixed(1)} cm²</span>
                  <span>{piece.perimeterMm.toFixed(0)} mm perimeter</span>
                  <span>{piece.notches.length} notches</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </aside>
  );
};
