import {useDialog} from './useDialog';
import type {QualityIssue} from '../engine/quality';
import React, { useState, useRef } from 'react';
import {
  MaterialSpec,
  PatternPiece,
  SolverSettings,
  SolverSummaryMetrics,
  SurfaceMesh
} from '../types/pattern';
import {
  generateCSVReport,
  generateDXFContent,
  generateOBJWithUVContent,
  generateSTLContent,
  generateSVGContent,
  triggerFileDownload
} from '../engine/cadExporters';
import { Check, Download, FileCode, FileText, Layers, X } from 'lucide-react';

interface ExportModalProps {
  isOpen: boolean;
  issues: QualityIssue[];
  onSaveProject: () => void;
  mesh: SurfaceMesh;
  pieces: PatternPiece[];
  material: MaterialSpec;
  settings: SolverSettings;
  summary: SolverSummaryMetrics;
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  issues,
  onSaveProject,
  mesh,
  pieces,
  material,
  settings,
  summary,
  onClose
}) => {
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);
  const dialogRef=useRef<HTMLDivElement>(null);
  useDialog(isOpen,onClose,dialogRef);
  if(!isOpen)return null;
  const blocked=issues.some(i=>i.severity==='error');

  const notifySuccess = (name: string) => {
    setDownloadSuccess(name);
    setTimeout(() => setDownloadSuccess(null), 2500);
  };

  const baseFileName = `${mesh.name.toLowerCase().replace(/[^a-z0-9]+/g, '_')}_patterns`;

  const handleExportDXF = () => {
    const content = generateDXFContent(pieces, settings, summary);
    triggerFileDownload(`${baseFileName}.dxf`, content, 'application/dxf');
    notifySuccess('AutoCAD DXF');
  };

  const handleExportSVG = () => {
    const content = generateSVGContent(pieces, settings, summary, material);
    triggerFileDownload(`${baseFileName}.svg`, content, 'image/svg+xml');
    notifySuccess('1:1 Scale SVG');
  };

  const handleExportOBJ = () => {
    const content = generateOBJWithUVContent(mesh, pieces, settings, summary);
    triggerFileDownload(`${baseFileName}_uv.obj`, content, 'text/plain');
    notifySuccess('3D OBJ + UV Pattern');
  };

  const handleExportSTL = () => {
    const content = generateSTLContent(mesh);
    triggerFileDownload(`${baseFileName}_surface.stl`, content, 'application/sla');
    notifySuccess('3D Surface STL');
  };

  const handleExportCSV = () => {
    const content = generateCSVReport(pieces, material, settings, summary);
    triggerFileDownload(`${baseFileName}_cutlist.csv`, content, 'text/csv');
    notifySuccess('BOM Cut List (CSV)');
  };

  const handleExportProjectJSON = () => {
    onSaveProject();
    notifySuccess('OpenFlat Project JSON');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 select-none">
      <div ref={dialogRef} role="dialog" aria-modal="true" aria-label="Export files" className="w-full max-w-xl bg-[#0F141C] border border-slate-800 rounded-xl shadow-2xl overflow-hidden flex flex-col">
        {/* Modal Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h2 className="text-base font-semibold text-white">Export CAD & Workspace Files</h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Select standard 2D pattern cutting files or 3D geometry formats.
            </p>
          </div>
          <button
            aria-label="Close export"
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Success Alert Banner */}
        {downloadSuccess && (
          <div className="px-5 py-2 bg-emerald-500/10 border-b border-emerald-500/20 text-emerald-400 text-xs flex items-center gap-2">
            <Check className="w-4 h-4" />
            <span>Successfully generated and downloaded {downloadSuccess}!</span>
          </div>
        )}

        <div className="px-5 py-3 text-xs border-b border-slate-800 text-slate-400">{blocked?<span className="text-rose-300">Pattern exports blocked by {issues.filter(i=>i.severity==='error').length} geometric issues. Open Checks to repair panels. Source mesh, project and report exports remain available.</span>:<span>Approximate geometric patterns. Review {issues.length} distortion warnings and validate a physical sample before production.</span>}</div>
        {/* Export Formats Grid */}
        <div className="p-5 space-y-3 overflow-y-auto max-h-[70vh]">
          {/* Format 1: AutoCAD DXF */}
          <div className="flex items-center justify-between p-3.5 bg-slate-900/80 border border-slate-800 rounded-lg hover:border-slate-700 transition-all">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-amber-500/10 text-amber-400 rounded-lg shrink-0 mt-0.5">
                <FileCode className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold text-slate-200">AutoCAD DXF (.dxf)</span>
                  <span className="text-[10px] text-amber-400 font-mono">INDUSTRY STANDARD</span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  Production CAD layers: CUT_LINE, SEAM_LINE, NOTCHES, GRAINLINE, LABELS. Compatible with Gerber, Lectra, Eastman, Zünd, Rhino, AutoCAD.
                </p>
              </div>
            </div>
            <button
              disabled={blocked}
              onClick={handleExportDXF}
              className="ml-3 px-3 py-1.5 text-xs font-semibold bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg shadow transition-all shrink-0"
            >
              Download
            </button>
          </div>

          {/* Format 2: 1:1 Scale SVG */}
          <div className="flex items-center justify-between p-3.5 bg-slate-900/80 border border-slate-800 rounded-lg hover:border-slate-700 transition-all">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-cyan-500/10 text-cyan-400 rounded-lg shrink-0 mt-0.5">
                <Layers className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold text-slate-200">Scale Vector SVG (.svg)</span>
                  <span className="text-[10px] text-cyan-400 font-mono">1:1 TRUE SCALE</span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  Calibrated millimeter dimensions with nested fabric roll boundaries for Adobe Illustrator, CorelDRAW, Inkscape, and CNC laser tables.
                </p>
              </div>
            </div>
            <button
              disabled={blocked}
              onClick={handleExportSVG}
              className="ml-3 px-3 py-1.5 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg transition-all shrink-0"
            >
              Download
            </button>
          </div>

          {/* Format 3: Wavefront OBJ with UV Mapping */}
          <div className="flex items-center justify-between p-3.5 bg-slate-900/80 border border-slate-800 rounded-lg hover:border-slate-700 transition-all">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-blue-500/10 text-blue-400 rounded-lg shrink-0 mt-0.5">
                <FileCode className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold text-slate-200">3D OBJ with Baked UVs (.obj)</span>
                  <span className="text-[10px] text-blue-400 font-mono">3D + 2D EMBEDDED</span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  3D geometry with flattened 2D pattern coordinates baked as UV texture maps (vt) and groups (g) for Blender, Clo3D, and Maya.
                </p>
              </div>
            </div>
            <button
              disabled={blocked}
              onClick={handleExportOBJ}
              className="ml-3 px-3 py-1.5 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg transition-all shrink-0"
            >
              Download
            </button>
          </div>

          {/* Format 4: 3D Surface STL */}
          <div className="flex items-center justify-between p-3.5 bg-slate-900/80 border border-slate-800 rounded-lg hover:border-slate-700 transition-all">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-lg shrink-0 mt-0.5">
                <FileCode className="w-5 h-5" />
              </div>
              <div>
                <span className="text-sm font-semibold text-slate-200">3D Surface STL (.stl)</span>
                <p className="text-xs text-slate-400 mt-0.5">
                  Source surface triangles only. Open shells remain open; no solid mold or tooling volume is generated.
                </p>
              </div>
            </div>
            <button
              onClick={handleExportSTL}
              className="ml-3 px-3 py-1.5 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg transition-all shrink-0"
            >
              Download
            </button>
          </div>

          {/* Format 5: BOM Cut List CSV */}
          <div className="flex items-center justify-between p-3.5 bg-slate-900/80 border border-slate-800 rounded-lg hover:border-slate-700 transition-all">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-pink-500/10 text-pink-400 rounded-lg shrink-0 mt-0.5">
                <FileText className="w-5 h-5" />
              </div>
              <div>
                <span className="text-sm font-semibold text-slate-200">Bill of Materials (.csv)</span>
                <p className="text-xs text-slate-400 mt-0.5">
                  Piece dimensions, net 3D vs 2D areas, perimeter lengths, seam allowance, and max strain tolerances.
                </p>
              </div>
            </div>
            <button
              onClick={handleExportCSV}
              className="ml-3 px-3 py-1.5 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg transition-all shrink-0"
            >
              Download
            </button>
          </div>

          {/* Format 6: OpenFlat Project JSON */}
          <div className="flex items-center justify-between p-3.5 bg-slate-900/80 border border-slate-800 rounded-lg hover:border-slate-700 transition-all">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-purple-500/10 text-purple-400 rounded-lg shrink-0 mt-0.5">
                <FileCode className="w-5 h-5" />
              </div>
              <div>
                <span className="text-sm font-semibold text-slate-200">OpenFlat Project (.openflat.json)</span>
                <p className="text-xs text-slate-400 mt-0.5">
                  Full project state: 3D mesh, seam segmentation, material preset, nesting coordinates, and solver settings.
                </p>
              </div>
            </div>
            <button
              onClick={handleExportProjectJSON}
              className="ml-3 px-3 py-1.5 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg transition-all shrink-0"
            >
              Download
            </button>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 border-t border-slate-800 bg-slate-950 flex items-center justify-between text-xs text-slate-400">
          <span>{pieces.length} Pattern Pieces · {summary.usedRollLengthMm}mm roll length</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-medium text-slate-300 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
