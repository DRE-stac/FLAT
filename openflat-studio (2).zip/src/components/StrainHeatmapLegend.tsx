import React from 'react';
import { ShadingMode3D } from '../types/pattern';

interface StrainHeatmapLegendProps {
  shadingMode: ShadingMode3D;
  maxStrainPct: number;
}

export const StrainHeatmapLegend: React.FC<StrainHeatmapLegendProps> = ({
  shadingMode,
  maxStrainPct
}) => {
  if (shadingMode === 'panels' || shadingMode === 'material') {
    return null;
  }

  return (
    <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-900/90 backdrop-blur-md border border-slate-800 rounded-lg shadow-xl text-xs font-mono pointer-events-auto">
      {shadingMode === 'strain' ? (
        <>
          <span className="text-cyan-400 font-medium">-5% Comp</span>
          <div className="w-28 h-2 rounded bg-gradient-to-r from-cyan-500 via-slate-700 to-red-500 border border-slate-700" />
          <span className="text-red-400 font-medium">+{Math.max(5, Math.ceil(maxStrainPct))}% Stretch</span>
        </>
      ) : (
        <>
          <span className="text-pink-400 font-medium">Saddle (K&lt;0)</span>
          <div className="w-28 h-2 rounded bg-gradient-to-r from-pink-500 via-slate-700 to-blue-500 border border-slate-700" />
          <span className="text-blue-400 font-medium">Dome (K&gt;0)</span>
        </>
      )}
    </div>
  );
};
