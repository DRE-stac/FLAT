import React, { useRef, useState, useEffect } from 'react';
import {
  PatternPiece,
  SolverSettings,
  SolverSummaryMetrics,
  Vec2
} from '../types/pattern';
import {
  Grid,
  Layers,
  Maximize2,
  Move,
  RotateCcw,
  RotateCw,
  Sliders,
  Sparkles,
  ZoomIn,
  ZoomOut
} from 'lucide-react';

interface PatternCanvas2DProps {
  pieces: PatternPiece[];
  settings: SolverSettings;
  summary: SolverSummaryMetrics;
  selectedPieceId: string | null;
  hoveredTriangleId: number | null;
  onSelectPiece: (pieceId: string | null) => void;
  onHoverTriangle: (triId: number | null) => void;
  onUpdatePieceTransform: (
    pieceId: string,
    position: Vec2,
    rotationDeg: number,
    grainlineAngleDeg: number
  ) => void;
  onAutoNest: () => void;
  onTransformStart: () => void;
}

export const PatternCanvas2D: React.FC<PatternCanvas2DProps> = ({
  pieces,
  settings,
  summary,
  selectedPieceId,
  hoveredTriangleId,
  onSelectPiece,
  onHoverTriangle,
  onUpdatePieceTransform,
  onAutoNest,
  onTransformStart
}) => {
  const containerRef = useRef<HTMLDivElement>(null);

  // Canvas Pan & Zoom view transform (scale: pixels per mm, pan: offset in pixels)
  const [viewTransform, setViewTransform] = useState<{ scale: number; panX: number; panY: number }>({
    scale: 0.42,
    panX: 45,
    panY: 55
  });

  const [isPanning, setIsPanning] = useState(false);
  const [draggedPieceId, setDraggedPieceId] = useState<string | null>(null);
  const dragStartRef = useRef<{ clientX: number; clientY: number; pieceStartPos: Vec2; panStart: { x: number; y: number } }>({
    clientX: 0,
    clientY: 0,
    pieceStartPos: { x: 0, y: 0 },
    panStart: { x: 0, y: 0 }
  });

  // Layer Visibility Toggles
  const [showCutLine, setShowCutLine] = useState(true);
  const [showSeamLine, setShowSeamLine] = useState(true);
  const [showInternalMesh, setShowInternalMesh] = useState(true);
  const [showNotches, setShowNotches] = useState(true);
  const [showGrainline, setShowGrainline] = useState(true);
  const [showDimensions, setShowDimensions] = useState(true);

  // Helper to get Strain Color for 2D Triangles
  const getStrainColor = (strain: number): string => {
    if (Math.abs(strain) < 0.2) return 'rgba(30, 41, 59, 0.5)'; // Dark neutral
    if (strain > 0) {
      const t = Math.min(1.0, strain / 5.0);
      const r = Math.round(180 + 75 * t);
      const g = Math.round(130 * (1 - t * 0.7));
      return `rgba(${r}, ${g}, 25, 0.7)`;
    } else {
      const t = Math.min(1.0, -strain / 5.0);
      const g = Math.round(140 + 75 * t);
      const b = Math.round(200 + 55 * t);
      return `rgba(20, ${g}, ${b}, 0.7)`;
    }
  };

  // Convert mm world coordinates on fabric roll to SVG screen pixels
  const mmToPixel = (xMm: number, yMm: number) => ({
    x: xMm * viewTransform.scale + viewTransform.panX,
    y: yMm * viewTransform.scale + viewTransform.panY
  });

  // Convert SVG screen pixels to mm world coordinates
  const pixelToMm = (pxX: number, pxY: number) => ({
    x: (pxX - viewTransform.panX) / viewTransform.scale,
    y: (pxY - viewTransform.panY) / viewTransform.scale
  });

  // Mouse wheel zoom
  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const container = containerRef.current;
    if (!container) return;

    const rect = container.getBoundingClientRect();
    const cursorX = e.clientX - rect.left;
    const cursorY = e.clientY - rect.top;

    const zoomFactor = e.deltaY < 0 ? 1.15 : 0.87;
    const nextScale = Math.max(0.01, Math.min(100, viewTransform.scale * zoomFactor));

    // Zoom centered around cursor
    const mmUnderCursor = pixelToMm(cursorX, cursorY);
    const nextPanX = cursorX - mmUnderCursor.x * nextScale;
    const nextPanY = cursorY - mmUnderCursor.y * nextScale;

    setViewTransform({
      scale: nextScale,
      panX: nextPanX,
      panY: nextPanY
    });
  };

  // Pointer Down (drag piece or pan canvas)
  const handlePointerDown = (e: React.PointerEvent, pieceId?: string) => {
    const isRightOrMiddle = e.button === 1 || e.button === 2;
    if (isRightOrMiddle || !pieceId) {
      // Pan canvas
      setIsPanning(true);
      dragStartRef.current.clientX = e.clientX;
      dragStartRef.current.clientY = e.clientY;
      dragStartRef.current.panStart = { x: viewTransform.panX, y: viewTransform.panY };
    } else {
      // Drag piece
      const piece = pieces.find((p) => p.id === pieceId);
      if (!piece) return;
      onSelectPiece(pieceId);
      onTransformStart();
      setDraggedPieceId(pieceId);
      dragStartRef.current.clientX = e.clientX;
      dragStartRef.current.clientY = e.clientY;
      dragStartRef.current.pieceStartPos = { ...piece.position };
    }
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (isPanning) {
      const dx = e.clientX - dragStartRef.current.clientX;
      const dy = e.clientY - dragStartRef.current.clientY;
      setViewTransform((prev) => ({
        ...prev,
        panX: dragStartRef.current.panStart.x + dx,
        panY: dragStartRef.current.panStart.y + dy
      }));
    } else if (draggedPieceId) {
      const piece = pieces.find((p) => p.id === draggedPieceId);
      if (!piece) return;

      const dxMm = (e.clientX - dragStartRef.current.clientX) / viewTransform.scale;
      const dyMm = (e.clientY - dragStartRef.current.clientY) / viewTransform.scale;

      const newPos: Vec2 = {
        x: Math.round(dragStartRef.current.pieceStartPos.x + dxMm),
        y: Math.max(10, Math.round(dragStartRef.current.pieceStartPos.y + dyMm))
      };

      onUpdatePieceTransform(piece.id, newPos, piece.rotationDeg, piece.grainlineAngleDeg);
    }
  };

  const handlePointerUp = () => {
    setIsPanning(false);
    setDraggedPieceId(null);
  };

  // Selected piece manipulation helpers
  const selectedPiece = pieces.find((p) => p.id === selectedPieceId);

  const rotateSelectedPiece = (deltaDeg: number) => {
    if (!selectedPiece) return;
    onTransformStart();
    const newRot = (selectedPiece.rotationDeg + deltaDeg) % 360;
    onUpdatePieceTransform(selectedPiece.id, selectedPiece.position, newRot, selectedPiece.grainlineAngleDeg);
  };

  const rotateGrainline = (deltaDeg: number) => {
    if (!selectedPiece) return;
    onTransformStart();
    const newGrain = (selectedPiece.grainlineAngleDeg + deltaDeg) % 360;
    onUpdatePieceTransform(selectedPiece.id, selectedPiece.position, selectedPiece.rotationDeg, newGrain);
  };

  const zoomToFitAll = () => {
    const container = containerRef.current;
    if (!container) return;
    const w = container.clientWidth;
    const h = container.clientHeight;

    const rollW = settings.rollWidthMm;
    const rollH = Math.max(600, summary.usedRollLengthMm + 60);

    const scaleX = (w - 80) / rollW;
    const scaleY = (h - 170) / rollH;
    const newScale = Math.min(scaleX, scaleY, 0.95);

    setViewTransform({
      scale: Math.max(0.01, newScale),
      panX: 40,
      panY: 110
    });
  };

  const fitRef=useRef(zoomToFitAll);fitRef.current=zoomToFitAll;
  useEffect(()=>{const container=containerRef.current;if(!container)return;const observer=new ResizeObserver(()=>fitRef.current());observer.observe(container);return()=>observer.disconnect();},[]);
  useEffect(()=>{if(pieces.length)zoomToFitAll();},[pieces.map(p=>p.id+':'+p.area2DMm2.toFixed(3)).join('|')]);

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full select-none overflow-hidden bg-[#0A0D13] cursor-default"
      onWheel={handleWheel}
      onPointerDown={(e) => handlePointerDown(e)}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onContextMenu={(e) => e.preventDefault()}
    >
      {/* Top Floating Control Bar: 2D Display Layers & Auto-Nest Action */}
      <div onPointerDown={e=>e.stopPropagation()} className="viewport-toolbar absolute top-3 left-3 z-10 flex flex-col items-start gap-2 pointer-events-auto">
        {/* Layer Toggles */}
        <div className="flex items-center p-1 bg-slate-900/90 backdrop-blur-md border border-slate-800 rounded-lg shadow-xl">
          <button
            onClick={() => setShowCutLine(!showCutLine)}
            className={`px-2 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              showCutLine
                ? 'bg-red-500/20 text-red-300 border border-red-500/40'
                : 'text-slate-500 hover:text-slate-300'
            }`}
            title="Toggle Cut Line (Outer Seam Allowance)"
          >
            Cut Line
          </button>
          <button
            onClick={() => setShowSeamLine(!showSeamLine)}
            className={`px-2 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              showSeamLine
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                : 'text-slate-500 hover:text-slate-300'
            }`}
            title="Toggle Net Seam Line"
          >
            Net Seam
          </button>
          <button
            onClick={() => setShowInternalMesh(!showInternalMesh)}
            className={`px-2 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              showInternalMesh
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                : 'text-slate-500 hover:text-slate-300'
            }`}
            title="Toggle Flattened Mesh & Strain Heatmap"
          >
            Strain Mesh
          </button>
          <button
            onClick={() => setShowNotches(!showNotches)}
            className={`px-2 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              showNotches
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                : 'text-slate-500 hover:text-slate-300'
            }`}
            title="Toggle Alignment Notches"
          >
            Notches
          </button>
          <button
            onClick={() => setShowGrainline(!showGrainline)}
            className={`px-2 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
              showGrainline
                ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40'
                : 'text-slate-500 hover:text-slate-300'
            }`}
            title="Toggle Grainline Direction"
          >
            Grainline
          </button>
        </div>

        {/* Auto-Nest Action */}
        <button
          onClick={onAutoNest}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold rounded-lg shadow-lg hover:shadow-amber-500/20 transition-all whitespace-nowrap"
          title="Auto-pack all flattened pieces onto the fabric roll"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Auto-Nest on Roll</span>
        </button>
      </div>

      {/* Top Right: Zoom & Navigation Controls */}
      <div onPointerDown={e=>e.stopPropagation()} className="absolute bottom-14 right-3 z-10 flex items-center gap-1 p-1 bg-slate-900/90 backdrop-blur-md border border-slate-800 rounded-lg shadow-xl pointer-events-auto">
        <button
          onClick={() => setViewTransform((prev) => ({ ...prev, scale: Math.min(2.5, prev.scale * 1.25) }))}
          className="p-1.5 text-slate-300 hover:text-white rounded hover:bg-slate-800 transition-colors"
          title="Zoom In"
        >
          <ZoomIn className="w-3.5 h-3.5" />
        </button>
        <button
          onClick={() => setViewTransform((prev) => ({ ...prev, scale: Math.max(0.12, prev.scale * 0.8) }))}
          className="p-1.5 text-slate-300 hover:text-white rounded hover:bg-slate-800 transition-colors"
          title="Zoom Out"
        >
          <ZoomOut className="w-3.5 h-3.5" />
        </button>
        <button
          onClick={zoomToFitAll}
          className="p-1.5 text-slate-300 hover:text-white rounded hover:bg-slate-800 transition-colors"
          title="Zoom to Fit Roll"
        >
          <Maximize2 className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Selected Piece Transform HUD (if a piece is selected) */}
      {selectedPiece && (
        <div className="absolute top-28 left-3 z-10 p-2.5 bg-slate-900/95 backdrop-blur-md border border-slate-800 rounded-lg shadow-2xl flex items-center gap-3 text-xs pointer-events-auto">
          <div className="flex items-center gap-2">
            <span
              className="w-2.5 h-2.5 rounded-full"
              style={{ backgroundColor: selectedPiece.color }}
            />
            <span className="font-semibold text-slate-200">{selectedPiece.name}</span>
          </div>

          <div className="h-4 w-px bg-slate-800" />

          {/* Piece Rotation Buttons */}
          <div className="flex items-center gap-1">
            <span className="text-slate-400 text-[11px] font-mono">Rotate:</span>
            <button
              onClick={() => rotateSelectedPiece(-15)}
              className="p-1 text-slate-300 hover:text-white rounded hover:bg-slate-800 transition-colors font-mono text-[11px]"
              title="Rotate -15°"
            >
              -15°
            </button>
            <button
              onClick={() => rotateSelectedPiece(15)}
              className="p-1 text-slate-300 hover:text-white rounded hover:bg-slate-800 transition-colors font-mono text-[11px]"
              title="Rotate +15°"
            >
              +15°
            </button>
            <button
              onClick={() => rotateSelectedPiece(90)}
              className="p-1 text-slate-300 hover:text-white rounded hover:bg-slate-800 transition-colors font-mono text-[11px]"
              title="Rotate +90°"
            >
              +90°
            </button>
          </div>

          <div className="h-4 w-px bg-slate-800" />

          {/* Grainline Adjustment */}
          <div className="flex items-center gap-1">
            <span className="text-slate-400 text-[11px] font-mono">Grain:</span>
            <button
              onClick={() => rotateGrainline(45)}
              className="px-1.5 py-0.5 text-sky-400 hover:text-sky-300 rounded hover:bg-slate-800 transition-colors font-mono text-[11px]"
              title="Bias Grainline +45°"
            >
              +45° Bias
            </button>
          </div>

          <button
            onClick={() => onSelectPiece(null)}
            className="text-slate-500 hover:text-slate-300 text-xs ml-1"
          >
            ✕
          </button>
        </div>
      )}

      {/* SVG Pattern Rendering Canvas */}
      <svg className="w-full h-full overflow-visible">
        <defs>
          {/* Millimeter Grid Pattern */}
          <pattern
            id="cad-grid-100"
            width={100 * viewTransform.scale}
            height={100 * viewTransform.scale}
            patternUnits="userSpaceOnUse"
          >
            <path
              d={`M ${100 * viewTransform.scale} 0 L 0 0 0 ${100 * viewTransform.scale}`}
              fill="none"
              stroke="#151C28"
              strokeWidth="0.8"
            />
          </pattern>
        </defs>

        {/* CAD Grid Background */}
        <rect
          x="0"
          y="0"
          width="100%"
          height="100%"
          fill="url(#cad-grid-100)"
          className="pointer-events-none"
        />

        {/* Global World Transform Group */}
        <g transform={`translate(${viewTransform.panX}, ${viewTransform.panY}) scale(${viewTransform.scale})`}>
          {/* Fabric Roll Width Boundaries */}
          <rect
            x={0}
            y={0}
            width={settings.rollWidthMm}
            height={Math.max(500, summary.usedRollLengthMm + 40)}
            fill="rgba(15, 23, 42, 0.45)"
            stroke="#1E293B"
            strokeWidth={1.5}
            strokeDasharray="8 4"
            className="pointer-events-none"
          />

          {/* Fabric Roll Edge Markers & Rulers */}
          <line
            x1={0}
            y1={0}
            x2={settings.rollWidthMm}
            y2={0}
            stroke="#38BDF8"
            strokeWidth={2}
            className="pointer-events-none"
          />
          <text
            x={10}
            y={-12}
            fill="#64748B"
            fontSize={14 / viewTransform.scale}
            fontFamily="monospace"
            className="pointer-events-none"
          >
            ROLL WIDTH: {settings.rollWidthMm}mm (54&quot;/60&quot; Standard)
          </text>

          {/* Used Roll Length Baseline Indicator */}
          <line
            x1={0}
            y1={summary.usedRollLengthMm}
            x2={settings.rollWidthMm}
            y2={summary.usedRollLengthMm}
            stroke="#F59E0B"
            strokeWidth={1.2}
            strokeDasharray="6 4"
            className="pointer-events-none"
          />
          <text
            x={10}
            y={summary.usedRollLengthMm + 24}
            fill="#F59E0B"
            fontSize={12 / viewTransform.scale}
            fontFamily="monospace"
            className="pointer-events-none"
          >
            CUT LENGTH: {summary.usedRollLengthMm}mm | YIELD: {summary.materialYieldPct.toFixed(1)}%
          </text>

          {/* Render All Pattern Pieces */}
          {pieces.map((piece) => {
            const isSelected = selectedPieceId === piece.id;
            const rad = (piece.rotationDeg * Math.PI) / 180;
            const cos = Math.cos(rad);
            const sin = Math.sin(rad);

            // Transform helper local -> piece table position
            const toTable = (pt: Vec2) => ({
              x: piece.position.x + (pt.x * cos - pt.y * sin),
              y: piece.position.y + (pt.x * sin + pt.y * cos)
            });

            return (
              <g
                key={piece.id}
                id={`piece_${piece.id}`}
                className="cursor-move"
                onPointerDown={(e) => {
                  e.stopPropagation();
                  handlePointerDown(e, piece.id);
                }}
              >
                {/* 1. Outer Cut Polygon (Seam Allowance) */}
                {showCutLine && settings.seamAllowanceMm > 0.05 && piece.cutPolygon2D.length >= 3 && (
                  <polygon
                    points={piece.cutPolygon2D
                      .map((pt) => {
                        const w = toTable(pt);
                        return `${w.x},${w.y}`;
                      })
                      .join(' ')}
                    fill="rgba(239, 68, 68, 0.04)"
                    stroke={isSelected ? '#F87171' : '#EF4444'}
                    strokeWidth={isSelected ? 1.6 : 1.0}
                    strokeDasharray="5 3"
                  />
                )}

                {/* 2. Internal Flattened Mesh Triangles & Strain Heatmap */}
                {showInternalMesh &&
                  piece.triangles.map((tri) => {
                    const p0 = toTable(piece.vertices2D[tri.localV0]);
                    const p1 = toTable(piece.vertices2D[tri.localV1]);
                    const p2 = toTable(piece.vertices2D[tri.localV2]);
                    const isHovered = hoveredTriangleId === tri.triId;

                    return (
                      <polygon
                        key={tri.triId}
                        points={`${p0.x},${p0.y} ${p1.x},${p1.y} ${p2.x},${p2.y}`}
                        fill={isHovered ? '#38BDF8' : getStrainColor(tri.maxEdgeStrainPct)}
                        stroke={isHovered ? '#FFFFFF' : 'rgba(148, 163, 184, 0.16)'}
                        strokeWidth={isHovered ? 1.5 : 0.4}
                        onMouseEnter={() => onHoverTriangle(tri.triId)}
                        onMouseLeave={() => onHoverTriangle(null)}
                      />
                    );
                  })}

                {/* 3. Net Seam Polygon Line */}
                {showSeamLine && piece.seamPolygon2D.length >= 3 && (
                  <polygon
                    points={piece.seamPolygon2D
                      .map((pt) => {
                        const w = toTable(pt);
                        return `${w.x},${w.y}`;
                      })
                      .join(' ')}
                    fill={showInternalMesh ? 'none' : 'rgba(6, 182, 212, 0.08)'}
                    stroke={isSelected ? '#22D3EE' : piece.color}
                    strokeWidth={isSelected ? 2.2 : 1.4}
                  />
                )}

                {/* 4. Alignment Notches */}
                {showNotches &&
                  piece.notches.map((notch) => {
                    const base = toTable(notch.position2D);
                    const notchLen = Math.max(6, settings.seamAllowanceMm > 0 ? settings.seamAllowanceMm : 7);
                    // Rotate normal
                    const rotNorm = {
                      x: notch.normal2D.x * cos - notch.normal2D.y * sin,
                      y: notch.normal2D.x * sin + notch.normal2D.y * cos
                    };
                    const tip = {
                      x: base.x + rotNorm.x * notchLen,
                      y: base.y + rotNorm.y * notchLen
                    };

                    return (
                      <g key={notch.id} className="pointer-events-none">
                        <line
                          x1={base.x}
                          y1={base.y}
                          x2={tip.x}
                          y2={tip.y}
                          stroke="#F59E0B"
                          strokeWidth={1.8}
                        />
                        <text
                          x={tip.x + rotNorm.x * 4}
                          y={tip.y + rotNorm.y * 4}
                          fill="#F59E0B"
                          fontSize={9 / viewTransform.scale}
                          fontFamily="monospace"
                          textAnchor="middle"
                          dominantBaseline="central"
                        >
                          #{notch.matchNumber}
                        </text>
                      </g>
                    );
                  })}

                {/* 5. Warp / Weft Grainline Arrow */}
                {showGrainline && (() => {
                  const gLen = Math.max(30, Math.min(piece.bboxWidthMm, piece.bboxHeightMm) * 0.4);
                  const totalAngle = ((piece.rotationDeg + piece.grainlineAngleDeg) * Math.PI) / 180;
                  const dx = Math.cos(totalAngle) * gLen * 0.5;
                  const dy = Math.sin(totalAngle) * gLen * 0.5;
                  const g1 = { x: piece.position.x - dx, y: piece.position.y - dy };
                  const g2 = { x: piece.position.x + dx, y: piece.position.y + dy };

                  return (
                    <g className="pointer-events-none">
                      <line
                        x1={g1.x}
                        y1={g1.y}
                        x2={g2.x}
                        y2={g2.y}
                        stroke="#10B981"
                        strokeWidth={1.6}
                      />
                      <circle cx={g1.x} cy={g1.y} r={2} fill="#10B981" />
                      <polygon
                        points={`${g2.x},${g2.y} ${g2.x - 5},${g2.y - 3} ${g2.x - 5},${g2.y + 3}`}
                        fill="#10B981"
                      />
                    </g>
                  );
                })()}

                {/* 6. Piece Title & Metrics Callout */}
                {showDimensions && (
                  <g className="pointer-events-none">
                    <text
                      x={piece.position.x}
                      y={piece.position.y - 4}
                      fill="#F8FAFC"
                      fontSize={11 / viewTransform.scale}
                      fontFamily="monospace"
                      fontWeight="bold"
                      textAnchor="middle"
                    >
                      {piece.name}
                    </text>
                    <text
                      x={piece.position.x}
                      y={piece.position.y + 11}
                      fill="#94A3B8"
                      fontSize={8.5 / viewTransform.scale}
                      fontFamily="monospace"
                      textAnchor="middle"
                    >
                      {(piece.area2DMm2 / 100).toFixed(1)} cm² · {piece.meanStrainPct.toFixed(1)}% strain
                    </text>
                  </g>
                )}
              </g>
            );
          })}
        </g>
      </svg>

      {/* Bottom Left: Live Nesting & Roll Stats Bar */}
      <div className="pattern-stats absolute bottom-3 left-3 z-10 flex items-center gap-3 p-2.5 bg-slate-900/90 backdrop-blur-md border border-slate-800 rounded-lg shadow-xl text-xs font-mono pointer-events-none tabular-nums">
        <div className="flex items-center gap-1.5 text-slate-300">
          <span className="text-slate-400">Yield:</span>
          <span className="text-amber-400 font-bold">{summary.materialYieldPct.toFixed(1)}%</span>
        </div>
        <span className="text-slate-600">|</span>
        <div className="flex items-center gap-1.5 text-slate-300">
          <span className="text-slate-400">Roll Used:</span>
          <span className="text-slate-200">
            {summary.usedRollLengthMm}mm ({(summary.usedRollLengthMm / 1000).toFixed(2)}m)
          </span>
        </div>
        <span className="text-slate-600">|</span>
        <div className="flex items-center gap-1.5 text-slate-300">
          <span className="text-slate-400">Pieces:</span>
          <span className="text-slate-200">{pieces.length} panels</span>
        </div>
      </div>

      {/* Bottom Right: Canvas Help */}
      <div className="canvas-hint absolute bottom-3 right-3 z-10 flex items-center gap-2 text-[11px] text-slate-500 font-mono pointer-events-none">
        <span>Drag: Move Piece</span>
        <span>·</span>
        <span>R-Click/Wheel: Pan/Zoom</span>
      </div>
    </div>
  );
};
