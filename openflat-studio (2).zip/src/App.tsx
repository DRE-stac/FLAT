import {separateTriangleIslands} from './engine/panelTopology';
import {auditPatterns} from './engine/quality';
import {makeProject,parseProject,Project} from './engine/project';
import {triggerFileDownload} from './engine/cadExporters';
import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import {
  MaterialSpec,
  ParametricConfig,
  PatternPiece,
  RepatternConfig,
  ShadingMode3D,
  SolverSettings,
  SolverSummaryMetrics,
  SurfaceMesh,
  ToolMode3D,
  Vec2
} from './types/pattern';
import {
  MATERIAL_LIBRARY,
  MODEL_TEMPLATES,
  generateParametricMesh,
  parseCustom3DFile,
  repatternMesh
} from './engine/meshGenerators';
import {
  computeSummaryMetrics,
  nestPiecesOnRoll,
  splitPieceToRelieveStrain
} from './engine/flatteningSolver';
import { HeaderBar } from './components/HeaderBar';
import { SidebarControls } from './components/SidebarControls';
import { Viewport3D } from './components/Viewport3D';
import { PatternCanvas2D } from './components/PatternCanvas2D';
import { StrainHeatmapLegend } from './components/StrainHeatmapLegend';
import { ExportModal } from './components/ExportModal';
import { WorkflowHelpModal } from './components/WorkflowHelpModal';

export default function App() {
  // Application State
  const [layoutMode, setLayoutMode] = useState<'split' | '3d' | '2d'>('split');
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>('automotive_seat');
  const [material, setMaterial] = useState<MaterialSpec>(MATERIAL_LIBRARY.find(m=>m.id==='leather_auto')!);

  const [parametricConfig, setParametricConfig] = useState<ParametricConfig>({
    scaleX: 1.0,
    scaleY: 1.0,
    scaleZ: 1.0,
    curvatureBoost: 1.0,
    resolution: 'standard'
  });

  const [settings, setSettings] = useState<SolverSettings>({
    stage: 'optimized',
    iterations: 45,
    seamAllowanceMm: 10,
    notchCountPerSeam: 2,
    rollWidthMm: 1400,
    piecePaddingMm: 25
  });

  const [repatternConfig, setRepatternConfig] = useState<RepatternConfig>({
    mode: 'feature_crease',
    targetPanelCount: 4,
    creaseAngleDeg: 38
  });

  // Current 3D Surface Mesh
  const [mesh, setMesh] = useState<SurfaceMesh>(() =>
    generateParametricMesh('automotive_seat', {
      scaleX: 1.0,
      scaleY: 1.0,
      scaleZ: 1.0,
      curvatureBoost: 1.0,
      resolution: 'standard'
    })
  );

  // Flattened Pieces & Solver Results
  const [pieces, setPieces] = useState<PatternPiece[]>([]);
  const [triangleStrainMap, setTriangleStrainMap] = useState<Map<number, number>>(new Map());
  const [summary, setSummary] = useState<SolverSummaryMetrics>({
    totalArea3DCm2: 0,
    totalArea2DCm2: 0,
    overallMeanStrainPct: 0,
    overallMaxStrainPct: 0,
    materialYieldPct: 0,
    usedRollLengthMm: 0,
    pieceCount: 0,
    triangleCount: 0,
    vertexCount: 0
  });

  // Selection & Interaction States
  const [selectedPieceId, setSelectedPieceId] = useState<string | null>(null);
  const [hoveredTriangleId, setHoveredTriangleId] = useState<number | null>(null);
  const [shadingMode, setShadingMode] = useState<ShadingMode3D>('panels');
  const [toolMode, setToolMode] = useState<ToolMode3D>('inspect');
  const [activePaintPieceId, setActivePaintPieceId] = useState<string>('piece_1');
  const [isSolving, setIsSolving] = useState(false);

  // Modals
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isHelpModalOpen, setIsHelpModalOpen] = useState(false);

  const piecesRef=useRef(pieces); piecesRef.current=pieces;
  const workerRef=useRef<Worker|null>(null), requestRef=useRef(0);
  const [error,setError]=useState<string|null>(null), [notice,setNotice]=useState('Dimensions in mm · Local workspace');
  const [showChecks,setShowChecks]=useState(false),[showControls,setShowControls]=useState(false);
  const fileRef=useRef<HTMLInputElement>(null),undoRef=useRef<Project[]>([]),redoRef=useRef<Project[]>([]);
  const [historyVersion,setHistoryVersion]=useState(0);
  const [recovery,setRecovery]=useState<string|null>(()=>{try{return localStorage.getItem('openflat-recovery-v2')}catch{return null}});
  const runSolver=useCallback((targetMesh:SurfaceMesh,targetMat:MaterialSpec,targetSettings:SolverSettings,preserve=true,placements?:Project['placements'])=>{
    workerRef.current?.terminate(); const id=++requestRef.current;setIsSolving(true);setError(null);
    const positions=new Map((placements||(preserve?piecesRef.current:[])).map(p=>[p.id,{position:{...p.position},rotationDeg:p.rotationDeg,grainlineAngleDeg:p.grainlineAngleDeg}]));
    const worker=new Worker(new URL('./workers/solver.worker.ts',import.meta.url),{type:'module'});workerRef.current=worker;
    worker.onmessage=({data})=>{if(data.id!==requestRef.current)return;if(data.error)setError(data.error);else{setPieces(data.result.pieces);setTriangleStrainMap(data.result.triangleStrainMap);setSummary(data.result.summary);setNotice('Pattern updated · Dimensions in mm');}setIsSolving(false);worker.terminate();workerRef.current=null;};
    worker.onerror=()=>{if(id===requestRef.current){setError('Solver failed. Reload and try a smaller mesh.');setIsSolving(false);}worker.terminate();};
    worker.postMessage({id,mesh:targetMesh,material:targetMat,settings:targetSettings,positions:positions.size?positions:undefined});
  },[]);
  const snapshot=()=>makeProject(mesh,material,settings,parametricConfig,repatternConfig,piecesRef.current);
  const checkpoint=()=>{undoRef.current.push(snapshot());if(undoRef.current.length>20)undoRef.current.shift();redoRef.current=[];setHistoryVersion(v=>v+1);};
  const loadProject=(p:Project)=>{setMesh(p.mesh);setMaterial(p.material);setSettings(p.settings);setParametricConfig(p.parametricConfig);setRepatternConfig(p.repatternConfig);setSelectedTemplateId(p.mesh.templateId);setSelectedPieceId(null);runSolver(p.mesh,p.material,p.settings,false,p.placements);};
  const undo=()=>{const p=undoRef.current.pop();if(p){redoRef.current.push(snapshot());loadProject(p);setHistoryVersion(v=>v+1);}};
  const redo=()=>{const p=redoRef.current.pop();if(p){undoRef.current.push(snapshot());loadProject(p);setHistoryVersion(v=>v+1);}};
  const saveProject=()=>{if(isSolving)return;triggerFileDownload(`${mesh.name.replace(/[^a-z0-9]+/gi,'_')}.openflat.json`,JSON.stringify(snapshot()),'application/json');setNotice('Project saved · Mesh, panels, settings and placements');};
  const openProject=async(file:File)=>{try{if(file.size>30*1024*1024)throw new Error('Project exceeds 30 MB.');const p=parseProject(await file.text());checkpoint();loadProject(p);}catch(e){setError(e instanceof Error?e.message:'Could not open project.');}};
  useEffect(()=>{runSolver(mesh,material,settings,false);return()=>workerRef.current?.terminate();},[]);
  useEffect(()=>{if(isSolving||!pieces.length||recovery)return;const t=setTimeout(()=>{try{localStorage.setItem('openflat-recovery-v2',JSON.stringify(snapshot()));}catch{setNotice('Recovery storage full · Save a project file');}},800);return()=>clearTimeout(t);},[mesh,material,settings,pieces,parametricConfig,repatternConfig,isSolving,recovery]);
  useEffect(()=>{const handler=(e:KeyboardEvent)=>{if((e.target as HTMLElement)?.matches('input,select,textarea'))return;if(e.key==='Escape'){setShowChecks(false);setShowControls(false);setIsExportModalOpen(false);setIsHelpModalOpen(false);}if((e.ctrlKey||e.metaKey)&&['s','z','o'].includes(e.key.toLowerCase())){e.preventDefault();if(e.key.toLowerCase()==='s')saveProject();if(e.key.toLowerCase()==='o')fileRef.current?.click();if(e.key.toLowerCase()==='z'&&!isSolving)(e.shiftKey?redo:undo)();}};window.addEventListener('keydown',handler);return()=>window.removeEventListener('keydown',handler);});
  const liveSummary=useMemo(()=>computeSummaryMetrics(mesh,pieces,settings.rollWidthMm,settings.seamAllowanceMm),[mesh,pieces,settings]);
  const issues=useMemo(()=>auditPatterns(mesh,pieces,material,settings.rollWidthMm),[mesh,pieces,material,settings.rollWidthMm]);
  const blockingCount=issues.filter(i=>i.severity==='error').length;

  // Handler: Select Template
  const handleSelectTemplate = (templateId: string) => {
    checkpoint();
    setSelectedTemplateId(templateId);
    const newMesh = generateParametricMesh(templateId, parametricConfig);
    setMesh(newMesh);

    // Pick template default material if available
    const meta = MODEL_TEMPLATES.find((t) => t.id === templateId);
    if (meta) {
      const defMat = MATERIAL_LIBRARY.find((m) => m.id === meta.defaultMaterialId);
      if (defMat) {
        setMaterial(defMat);
        setSettings((prev) => ({ ...prev, rollWidthMm: defMat.defaultRollWidthMm }));
        runSolver(newMesh, defMat, { ...settings, rollWidthMm: defMat.defaultRollWidthMm }, false);
        return;
      }
    }

    runSolver(newMesh, material, settings, false);
  };

  // Handler: Update Parametric Config
  const handleUpdateParametricConfig = (newConfig: Partial<ParametricConfig>) => {
    checkpoint();
    const updated = { ...parametricConfig, ...newConfig };
    setParametricConfig(updated);
    if (mesh.templateId !== 'custom_upload') {
      const newMesh = generateParametricMesh(selectedTemplateId, updated);
      setMesh(newMesh);
      runSolver(newMesh, material, settings, true);
    }
  };

  // Handler: Select Material
  const handleSelectMaterial = (materialId: string) => {
    checkpoint();
    const found = MATERIAL_LIBRARY.find((m) => m.id === materialId);
    if (found) {
      setMaterial(found);
      const updatedSettings = { ...settings, rollWidthMm: found.defaultRollWidthMm };
      setSettings(updatedSettings);
      runSolver(mesh, found, updatedSettings, true);
    }
  };

  // Handler: Update Solver Settings
  const handleUpdateSettings = (newSettings: Partial<SolverSettings>) => {
    checkpoint();
    const updated = { ...settings, ...newSettings };
    setSettings(updated);
    runSolver(mesh, material, updated, true);
  };

  // Handler: Upload Custom 3D Mesh (.OBJ or .STL)
  const handleUploadCustomFile = async (file: File) => {
    try {
      if(file.size>25*1024*1024)throw new Error('Mesh exceeds 25 MB. Simplify before import.');
      const buffer = await file.arrayBuffer();
      const customMesh = parseCustom3DFile(file.name, buffer);
      checkpoint();
      setSelectedTemplateId('custom_upload');
      setMesh(customMesh);
      runSolver(customMesh, material, settings, false);
    } catch (err) {
      console.error('Failed to parse 3D file:', err);
      setError(err instanceof Error?err.message:'Could not parse mesh.');
    }
  };

  // Handler: Paint / Reassign 3D Triangle to Pattern Piece
  const handlePaintTriangle = (triId: number, targetPieceId: string) => {
    checkpoint();
    const updatedTris = mesh.triangles.map((t) => {
      if (t.id === triId) {
        return { ...t, pieceId: targetPieceId };
      }
      return t;
    });
    const updatedMesh = { ...mesh, triangles: separateTriangleIslands(updatedTris) };
    setMesh(updatedMesh);
    runSolver(updatedMesh, material, settings, true);
  };

  // Handler: Split Piece / Slice Relief Dart to Relieve Strain
  const handleSplitPiece = (pieceId: string) => {
    checkpoint();
    const updatedMesh = splitPieceToRelieveStrain(mesh, pieceId);
    setMesh(updatedMesh);
    runSolver(updatedMesh, material, settings, false);
  };

  // Handler: Update 2D Piece Placement (Move/Rotate on Cutting Table)
  const handleUpdatePieceTransform = (
    pieceId: string,
    position: Vec2,
    rotationDeg: number,
    grainlineAngleDeg: number
  ) => {
    setPieces((prev) =>
      prev.map((p) => {
        if (p.id === pieceId) {
          return {
            ...p,
            position,
            rotationDeg,
            grainlineAngleDeg
          };
        }
        return p;
      })
    );
  };

  // Handler: Auto-Nest Pieces on Roll
  const handleAutoNest = () => {
    checkpoint();
    const updatedPieces=pieces.map(p=>({...p,position:{...p.position}}));
    nestPiecesOnRoll(updatedPieces,settings.rollWidthMm,settings.piecePaddingMm,settings.seamAllowanceMm);
    setPieces(updatedPieces);setNotice('Nested · Grain orientation preserved');
  };

  // Handler: Auto-Repattern Mesh (Creases, Normal Clusters, Gores)
  const handleTriggerRepattern = () => {
    checkpoint();
    const repatterned = repatternMesh(mesh, repatternConfig.mode, {
      targetPanelCount: repatternConfig.targetPanelCount,
      creaseAngleDeg: repatternConfig.creaseAngleDeg
    });
    setMesh(repatterned);
    runSolver(repatterned, material, settings, false);
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-[#0B0E14] text-slate-100 overflow-hidden font-sans">
      {/* Universal Top Bar adhering strictly to Top Bar Contract */}
      <HeaderBar
        layoutMode={layoutMode}
        isSolving={isSolving}
        settings={settings}
        onSelectLayout={setLayoutMode}
        onOpenExportModal={() => {if(!isSolving&&!error&&pieces.length)setIsExportModalOpen(true);}}
        onRunOptimization={() => runSolver(mesh, material, settings, true)}
        onOpenWorkflowHelp={() => setIsHelpModalOpen(true)}
      />

      <div className="project-bar flex items-center gap-2 px-4 py-2 border-b border-slate-800 bg-[#10151e] text-xs shrink-0">
        <button className="workspace-button lg:hidden" onClick={()=>setShowControls(!showControls)}>Controls</button>
        <span className="hidden sm:block text-slate-400 truncate mr-auto">{mesh.name}</span>
        <button className="workspace-button" onClick={()=>fileRef.current?.click()}>Open project</button>
        <button className="workspace-button" onClick={saveProject} disabled={isSolving}>Save project</button>
        <button className="workspace-button" onClick={undo} disabled={!undoRef.current.length||isSolving}>Undo</button>
        <button className="workspace-button" onClick={redo} disabled={!redoRef.current.length||isSolving}>Redo</button>
        <button className={`workspace-button ${blockingCount?'text-rose-300':'text-emerald-300'}`} onClick={()=>setShowChecks(!showChecks)}>Checks {issues.length?`(${issues.length})`:'✓'}</button>
        <input ref={fileRef} type="file" accept=".json" hidden onChange={e=>{const f=e.target.files?.[0];if(f)openProject(f);e.target.value='';}} />
      </div>
      {error&&<div role="alert" className="px-4 py-2 text-sm bg-rose-950 text-rose-200 flex justify-between">{error}<button onClick={()=>setError(null)} aria-label="Dismiss error">×</button></div>}
      {recovery&&<div className="px-4 py-2 text-xs bg-slate-800 flex gap-4 items-center"><span>Previous workspace available.</span><button className="workspace-button" onClick={()=>{try{const p=parseProject(recovery);checkpoint();loadProject(p);setRecovery(null);}catch(e){setError(String(e));}}}>Restore workspace</button><button onClick={()=>setRecovery(null)}>Dismiss</button></div>}
      {/* Main Workspace: Sidebar + Interactive Viewports */}
      <div className="flex flex-1 w-full min-h-0 relative overflow-hidden">
        {/* Left Engineering CAD Sidebar */}
        <div className={`controls-shell ${showControls?'is-open':''}`}>
        <SidebarControls
          mesh={mesh}
          pieces={pieces}
          material={material}
          parametricConfig={parametricConfig}
          settings={settings}
          summary={liveSummary}
          selectedPieceId={selectedPieceId}
          activePaintPieceId={activePaintPieceId}
          isSolving={isSolving}
          repatternConfig={repatternConfig}
          onSelectTemplate={handleSelectTemplate}
          onUploadCustomFile={handleUploadCustomFile}
          onUpdateParametricConfig={handleUpdateParametricConfig}
          onSelectMaterial={handleSelectMaterial}
          onUpdateSettings={handleUpdateSettings}
          onSelectPiece={setSelectedPieceId}
          onSplitPiece={handleSplitPiece}
          onSelectActivePaintPiece={setActivePaintPieceId}
          onRunOptimization={() => runSolver(mesh, material, settings, true)}
          onUpdateRepatternConfig={(cfg) => setRepatternConfig((prev) => ({ ...prev, ...cfg }))}
          onTriggerRepattern={handleTriggerRepattern}
        />

        </div>
        {/* Central Viewport Arena (Split, 3D-only, or 2D-only) */}
        <main className="flex-1 min-w-0 h-full relative overflow-hidden flex workspace-viewports">
          {/* 3D Surface Viewport */}
          {(layoutMode === 'split' || layoutMode === '3d') && (
            <div
              className={`h-full relative ${
                layoutMode === 'split' ? 'split-pane w-1/2 border-r border-slate-800' : 'w-full'
              }`}
            >
              <Viewport3D
                mesh={mesh}
                pieces={pieces}
                triangleStrainMap={triangleStrainMap}
                shadingMode={shadingMode}
                toolMode={toolMode}
                selectedPieceId={selectedPieceId}
                hoveredTriangleId={hoveredTriangleId}
                activePaintPieceId={activePaintPieceId}
                onSelectPiece={setSelectedPieceId}
                onHoverTriangle={setHoveredTriangleId}
                onPaintTriangle={handlePaintTriangle}
                onSplitPiece={handleSplitPiece}
                onToggleShadingMode={setShadingMode}
                onToggleToolMode={setToolMode}
              />

              {/* Strain / Curvature Legend floating overlay */}
              <div className="absolute top-28 left-3 z-10 pointer-events-none">
                <StrainHeatmapLegend
                  shadingMode={shadingMode}
                  maxStrainPct={liveSummary.overallMaxStrainPct}
                />
              </div>
            </div>
          )}

          {/* 2D Pattern Cutting Table & Nesting Canvas */}
          {(layoutMode === 'split' || layoutMode === '2d') && (
            <div className={`h-full relative ${layoutMode === 'split' ? 'split-pane w-1/2' : 'w-full'}`}>
              <PatternCanvas2D
                pieces={pieces}
                settings={settings}
                summary={liveSummary}
                selectedPieceId={selectedPieceId}
                hoveredTriangleId={hoveredTriangleId}
                onSelectPiece={setSelectedPieceId}
                onHoverTriangle={setHoveredTriangleId}
                onUpdatePieceTransform={handleUpdatePieceTransform}
                onTransformStart={checkpoint}
                onAutoNest={handleAutoNest}
              />
            </div>
          )}
        </main>
      </div>

      <div role="status" className="h-7 shrink-0 border-t border-slate-800 px-4 flex items-center justify-between text-[10px] text-slate-400 bg-[#0D1117]"><span>{isSolving?'Solving in background…':notice}</span><span>{pieces.length} panels · {mesh.triangles.length.toLocaleString()} triangles · Approximate solver</span></div>
      {showChecks&&<div className="absolute right-3 top-28 z-30 w-[min(420px,calc(100vw-24px))] max-h-[70vh] overflow-y-auto rounded-xl border border-slate-700 bg-[#111923] shadow-2xl p-5"><div className="flex justify-between mb-3"><h2 className="font-semibold">Pattern checks</h2><button aria-label="Close checks" onClick={()=>setShowChecks(false)}>×</button></div><p className="text-xs text-slate-400 mb-4">Geometric checks only. Material presets and edge distortion are estimates, not calibrated stress analysis. Validate seams, grain, and a physical sample before production.</p>{!issues.length&&<p className="text-emerald-300 text-sm">No geometric issues detected.</p>}{issues.map((issue,i)=><button key={i} className={`text-left w-full p-3 mb-2 rounded-lg text-xs ${issue.severity==='error'?'bg-rose-500/10 text-rose-200':'bg-amber-500/10 text-amber-200'}`} onClick={()=>{if(issue.pieceId)setSelectedPieceId(issue.pieceId);}}>{issue.severity==='error'?'FIX REQUIRED · ':'REVIEW · '}{issue.message}</button>)}</div>}
      {/* CAD Export Modal */}
      <ExportModal
        isOpen={isExportModalOpen}
        issues={issues}
        onSaveProject={saveProject}
        mesh={mesh}
        pieces={pieces}
        material={material}
        settings={settings}
        summary={liveSummary}
        onClose={() => setIsExportModalOpen(false)}
      />

      {/* Step-by-Step Workflow Guide Modal */}
      <WorkflowHelpModal
        isOpen={isHelpModalOpen}
        onClose={() => setIsHelpModalOpen(false)}
      />
    </div>
  );
}
