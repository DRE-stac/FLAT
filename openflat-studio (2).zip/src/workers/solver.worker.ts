import { flattenAndOptimizeMesh } from '../engine/flatteningSolver';
self.onmessage = ({data}) => {
  try { self.postMessage({id:data.id,result:flattenAndOptimizeMesh(data.mesh,data.material,data.settings,data.positions)}) }
  catch(error) { self.postMessage({id:data.id,error:error instanceof Error?error.message:'Flattening failed'}) }
};
