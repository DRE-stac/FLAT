import {separateTriangleIslands} from './panelTopology';
import {unfoldTriangles} from './unfold';
import {
  AlignmentNotch,
  FlattenedTriangle,
  MaterialSpec,
  PatternPiece,
  SolverSettings,
  SolverSummaryMetrics,
  SurfaceMesh,
  Vec2,
  Vec3
} from '../types/pattern';
import { MODEL_TEMPLATES, PIECE_PALETTE } from './meshGenerators';
import { bounds, polygonArea, tablePolygon } from './quality';

function dist3D(a: Vec3, b: Vec3): number {
  const dx = a.x - b.x;
  const dy = a.y - b.y;
  const dz = a.z - b.z;
  return Math.sqrt(dx * dx + dy * dy + dz * dz);
}

function dist2D(a: Vec2, b: Vec2): number {
  const dx = a.x - b.x;
  const dy = a.y - b.y;
  return Math.sqrt(dx * dx + dy * dy);
}

function signedArea2D(a: Vec2, b: Vec2, c: Vec2): number {
  return 0.5 * ((b.x - a.x) * (c.y - a.y) - (c.x - a.x) * (b.y - a.y));
}

interface SpringEdge {
  u: number;
  v: number;
  restLength: number;
  stiffness: number;
}

/**
 * Extracts ordered outer boundary loop of local vertex indices for a piece
 */
function extractOrderedBoundaryLoop(
  localTris: { localV0: number; localV1: number; localV2: number }[],
  vertices2D: Vec2[]
): number[] {
  // Count directed half-edges; boundary half-edges have no opposite half-edge
  const directedEdges = new Map<string, [number, number]>();
  const undirectedCounts = new Map<string, number>();

  const addHalfEdge = (a: number, b: number) => {
    directedEdges.set(`${a}_${b}`, [a, b]);
    const k = a < b ? `${a}_${b}` : `${b}_${a}`;
    undirectedCounts.set(k, (undirectedCounts.get(k) || 0) + 1);
  };

  for (const t of localTris) {
    addHalfEdge(t.localV0, t.localV1);
    addHalfEdge(t.localV1, t.localV2);
    addHalfEdge(t.localV2, t.localV0);
  }

  const nextVertexMap = new Map<number, number[]>();
  const boundaryVertices = new Set<number>();

  for (const [, [a, b]] of directedEdges.entries()) {
    const k = a < b ? `${a}_${b}` : `${b}_${a}`;
    if (undirectedCounts.get(k) === 1) {
      if (!nextVertexMap.has(a)) nextVertexMap.set(a, []);
      nextVertexMap.get(a)!.push(b);
      boundaryVertices.add(a);
      boundaryVertices.add(b);
    }
  }

  if (boundaryVertices.size < 3) {
    return Array.from(boundaryVertices);
  }

  // Find longest boundary loop
  let bestLoop: number[] = [];
  const visitedStarts = new Set<number>();

  for (const startNode of boundaryVertices) {
    if (visitedStarts.has(startNode)) continue;
    const loop: number[] = [];
    let curr: number | undefined = startNode;
    const localVisited = new Set<number>();

    while (curr !== undefined && !localVisited.has(curr)) {
      localVisited.add(curr);
      visitedStarts.add(curr);
      loop.push(curr);
      const nextCandidates: number[] = nextVertexMap.get(curr) || [];
      curr = nextCandidates.find((n: number) => !localVisited.has(n));
    }

    if (loop.length > bestLoop.length) {
      bestLoop = loop;
    }
  }

  // Ensure Counter-Clockwise (positive signed polygon area)
  if (bestLoop.length >= 3) {
    let signedPolyArea = 0;
    for (let i = 0; i < bestLoop.length; i++) {
      const p1 = vertices2D[bestLoop[i]];
      const p2 = vertices2D[bestLoop[(i + 1) % bestLoop.length]];
      signedPolyArea += p1.x * p2.y - p2.x * p1.y;
    }
    if (signedPolyArea < 0) {
      bestLoop.reverse();
    }
  }

  return bestLoop;
}

/**
 * Computes outward offset polygon (for seam allowance cut line) from a CCW polygon
 */
function computeOutwardOffsetPolygon(ccwPoly: Vec2[], offsetMm: number): Vec2[] {
  if (ccwPoly.length < 3 || offsetMm <= 0.05) {
    return ccwPoly.map((p) => ({ ...p }));
  }

  const n = ccwPoly.length;
  const offsetPoints: Vec2[] = [];

  for (let i = 0; i < n; i++) {
    const prev = ccwPoly[(i - 1 + n) % n];
    const curr = ccwPoly[i];
    const next = ccwPoly[(i + 1) % n];

    // Edge vectors
    const e1x = curr.x - prev.x;
    const e1y = curr.y - prev.y;
    const l1 = Math.max(1e-6, Math.hypot(e1x, e1y));
    // Outward normal for CCW polygon is (dy, -dx) / len
    const n1x = e1y / l1;
    const n1y = -e1x / l1;

    const e2x = next.x - curr.x;
    const e2y = next.y - curr.y;
    const l2 = Math.max(1e-6, Math.hypot(e2x, e2y));
    const n2x = e2y / l2;
    const n2y = -e2x / l2;

    // Bisector normal with miter clamp
    let bx = n1x + n2x;
    let by = n1y + n2y;
    const bLen = Math.hypot(bx, by);
    if (bLen < 1e-4) {
      bx = n1x;
      by = n1y;
    } else {
      bx /= bLen;
      by /= bLen;
    }

    const dot = Math.max(0.35, bx * n1x + by * n1y);
    const miterScale = Math.min(offsetMm * 1.85, offsetMm / dot);

    offsetPoints.push({
      x: curr.x + bx * miterScale,
      y: curr.y + by * miterScale
    });
  }

  return offsetPoints;
}

/**
 * Unwraps and optimizes all pattern pieces from a 3D SurfaceMesh
 */
export function flattenAndOptimizeMesh(
  mesh: SurfaceMesh,
  material: MaterialSpec,
  settings: SolverSettings,
  existingPositions?: Map<string, { position: Vec2; rotationDeg: number; grainlineAngleDeg: number }>
): {
  pieces: PatternPiece[];
  triangleStrainMap: Map<number, number>;
  summary: SolverSummaryMetrics;
} {
  const templateMeta = MODEL_TEMPLATES.find((t) => t.id === mesh.templateId);

  // Group triangles by pieceId
  const pieceTriGroups = new Map<string, number[]>();
  for (const tri of mesh.triangles) {
    if (!pieceTriGroups.has(tri.pieceId)) {
      pieceTriGroups.set(tri.pieceId, []);
    }
    pieceTriGroups.get(tri.pieceId)!.push(tri.id);
  }

  const pieces: PatternPiece[] = [];
  const triangleStrainMap = new Map<number, number>();

  let colorIdx = 0;
  for (const [pieceId, triIds] of pieceTriGroups.entries()) {
    if (triIds.length === 0) continue;

    const paletteEntry =
      PIECE_PALETTE.find((p) => p.id === pieceId) || PIECE_PALETTE[colorIdx % PIECE_PALETTE.length];
    colorIdx++;

    const pieceName =
      (pieceId.includes('_island_') ? `${templateMeta?.pieceNames[pieceId.split('_island_')[0]] || 'Panel'} · Island ${pieceId.split('_island_')[1]}` : templateMeta?.pieceNames[pieceId]) || paletteEntry.name || `Pattern Panel ${colorIdx}`;

    // Map global vertex indices used in this piece to local 0..V-1
    const globalToLocal = new Map<number, number>();
    const globalVertexIds: number[] = [];
    const vertices3D: Vec3[] = [];

    const getLocalIdx = (gIdx: number): number => {
      const existing = globalToLocal.get(gIdx);
      if (existing !== undefined) return existing;
      const localIdx = vertices3D.length;
      globalToLocal.set(gIdx, localIdx);
      globalVertexIds.push(gIdx);
      vertices3D.push(mesh.vertices[gIdx]);
      return localIdx;
    };

    const localTrisData = triIds.map((tId) => {
      const t = mesh.triangles[tId];
      return {
        triId: tId,
        localV0: getLocalIdx(t.v0),
        localV1: getLocalIdx(t.v1),
        localV2: getLocalIdx(t.v2),
        area3D: t.area3D,
        normal: t.normal
      };
    });

    // STAGE 1: Pre-Flattener — Compute area-weighted average normal & Tangent Plane Projection
    let nx = 0,
      ny = 0,
      nz = 0;
    let totalPieceArea3D = 0;
    for (const lt of localTrisData) {
      nx += lt.normal.x * lt.area3D;
      ny += lt.normal.y * lt.area3D;
      nz += lt.normal.z * lt.area3D;
      totalPieceArea3D += lt.area3D;
    }
    if (Math.hypot(nx,ny,nz)<1e-8) { const n=localTrisData[0].normal; nx=n.x;ny=n.y;nz=n.z; }
    const nLen = Math.max(1e-8, Math.hypot(nx, ny, nz));
    const avgNormal: Vec3 = { x: nx / nLen, y: ny / nLen, z: nz / nLen };

    // Choose stable up vector to construct orthonormal tangent basis (T1, T2)
    const upCandidate: Vec3 =
      Math.abs(avgNormal.y) < 0.9 ? { x: 0, y: 1, z: 0 } : { x: 1, y: 0, z: 0 };

    // T1 = normalize(up x avgNormal)
    let t1x = upCandidate.y * avgNormal.z - upCandidate.z * avgNormal.y;
    let t1y = upCandidate.z * avgNormal.x - upCandidate.x * avgNormal.z;
    let t1z = upCandidate.x * avgNormal.y - upCandidate.y * avgNormal.x;
    const t1Len = Math.max(1e-8, Math.hypot(t1x, t1y, t1z));
    t1x /= t1Len;
    t1y /= t1Len;
    t1z /= t1Len;

    // T2 = avgNormal x T1
    const t2x = avgNormal.y * t1z - avgNormal.z * t1y;
    const t2y = avgNormal.z * t1x - avgNormal.x * t1z;
    const t2z = avgNormal.x * t1y - avgNormal.y * t1x;

    // Compute 3D centroid of piece
    let cx = 0,
      cy = 0,
      cz = 0;
    for (const v of vertices3D) {
      cx += v.x;
      cy += v.y;
      cz += v.z;
    }
    cx /= vertices3D.length;
    cy /= vertices3D.length;
    cz /= vertices3D.length;

    // Initial 2D projection coordinates
    let vertices2D: Vec2[] = vertices3D.map((v) => {
      const dx = v.x - cx;
      const dy = v.y - cy;
      const dz = v.z - cz;
      return {
        x: dx * t1x + dy * t1y + dz * t1z,
        y: dx * t2x + dy * t2y + dz * t2z
      };
    });

    vertices2D = unfoldTriangles(vertices3D,localTrisData,vertices2D);

    // Build Structural Edge Springs + Cross-Edge Shear Springs from 3D rest lengths
    const springMap = new Map<string, SpringEdge>();
    const edgeToOppVertices = new Map<string, number[]>();

    const registerEdge = (u: number, v: number, opp: number) => {
      const a = Math.min(u, v);
      const b = Math.max(u, v);
      const key = `${a}_${b}`;
      if (!springMap.has(key)) {
        const restLength = Math.max(1e-10,dist3D(vertices3D[a],vertices3D[b]));
        springMap.set(key, {
          u: a,
          v: b,
          restLength,
          stiffness: 1.0
        });
      }
      if (!edgeToOppVertices.has(key)) edgeToOppVertices.set(key, []);
      edgeToOppVertices.get(key)!.push(opp);
    };

    for (const lt of localTrisData) {
      registerEdge(lt.localV0, lt.localV1, lt.localV2);
      registerEdge(lt.localV1, lt.localV2, lt.localV0);
      registerEdge(lt.localV2, lt.localV0, lt.localV1);
    }

    // Add cross-hinge springs across shared triangle edges to prevent folding & preserve shear stiffness
    for (const [sharedKey, opps] of edgeToOppVertices.entries()) {
      if (opps.length === 2 && opps[0] !== opps[1]) {
        const a = Math.min(opps[0], opps[1]);
        const b = Math.max(opps[0], opps[1]);
        const key = `cross_${a}_${b}`;
        // Geodesic hinge distance across the two triangles in 3D
        const [u,v]=sharedKey.split('_').map(Number);
        const hinge=dist3D(vertices3D[u],vertices3D[v]);
        const local=(i:number)=>{const du=dist3D(vertices3D[u],vertices3D[i]),dv=dist3D(vertices3D[v],vertices3D[i]);const x=(du*du-dv*dv+hinge*hinge)/(2*Math.max(hinge,1e-12));return {x,h:Math.sqrt(Math.max(0,du*du-x*x))};};
        const pa=local(a),pb=local(b);
        const restLength = Math.max(1e-10,Math.hypot(pa.x-pb.x,pa.h+pb.h));
        springMap.set(key, {
          u: a,
          v: b,
          restLength,
          stiffness: material.shearStiffnessRatio * 0.65
        });
      }
    }

    const springs = Array.from(springMap.values());

    // STAGE 2: Iterative Spring-Mass & Area-Preserving Relaxation
    // In 'pre_flatten' stage we run only 2 gentle smoothing steps; in 'optimized' we run full solver iterations
    const activeIterations = settings.stage === 'pre_flatten' ? 2 : Math.max(10, settings.iterations);
    const dispX = new Float64Array(vertices2D.length);
    const dispY = new Float64Array(vertices2D.length);
    const weightSum = new Float64Array(vertices2D.length);

    // Damping tuned by material properties
    const damping = settings.stage === 'pre_flatten' ? 0.15 : 0.58;

    for (let iter = 0; iter < activeIterations; iter++) {
      dispX.fill(0);
      dispY.fill(0);
      weightSum.fill(0);

      for (let sIdx = 0; sIdx < springs.length; sIdx++) {
        const s = springs[sIdx];
        const pU = vertices2D[s.u];
        const pV = vertices2D[s.v];
        const dx = pV.x - pU.x;
        const dy = pV.y - pU.y;
        const currentLen = Math.hypot(dx, dy);
        if (currentLen < 1e-6) continue;

        const diff = (currentLen - s.restLength) / currentLen;
        const fx = dx * 0.5 * diff * s.stiffness;
        const fy = dy * 0.5 * diff * s.stiffness;

        dispX[s.u] += fx;
        dispY[s.u] += fy;
        weightSum[s.u] += s.stiffness;

        dispX[s.v] -= fx;
        dispY[s.v] -= fy;
        weightSum[s.v] += s.stiffness;
      }

      // Also apply local triangle area-preservation & fold-prevention force
      if (settings.stage === 'optimized') {
        for (const lt of localTrisData) {
          const p0 = vertices2D[lt.localV0];
          const p1 = vertices2D[lt.localV1];
          const p2 = vertices2D[lt.localV2];
          const sArea = signedArea2D(p0, p1, p2);
          const absArea = Math.max(1e-12, Math.abs(sArea));
          const areaRatio = lt.area3D / absArea;

          if (sArea < 0 || Math.abs(areaRatio - 1) > 0.01) {
            const scaleCorrection = Math.max(0.88, Math.min(1.12, Math.sqrt(areaRatio)));
            const triCx = (p0.x + p1.x + p2.x) / 3;
            const triCy = (p0.y + p1.y + p2.y) / 3;
            const areaWeight = material.poissonRatio * 0.45;

            const ids = [lt.localV0, lt.localV1, lt.localV2];
            for (const vId of ids) {
              const pv = vertices2D[vId];
              const targetX = triCx + (pv.x - triCx) * scaleCorrection;
              const targetY = triCy + (pv.y - triCy) * scaleCorrection;
              dispX[vId] += (targetX - pv.x) * areaWeight;
              dispY[vId] += (targetY - pv.y) * areaWeight;
              weightSum[vId] += areaWeight;
            }
          }
        }
      }

      for (let i = 0; i < vertices2D.length; i++) {
        if (weightSum[i] > 1e-6) {
          vertices2D[i].x += (dispX[i] / weightSum[i]) * damping;
          vertices2D[i].y += (dispY[i] / weightSum[i]) * damping;
        }
      }
    }

    // Re-center local 2D vertices around (0,0)
    let min2DX = Infinity,
      min2DY = Infinity,
      max2DX = -Infinity,
      max2DY = -Infinity;
    for (const v of vertices2D) {
      if (v.x < min2DX) min2DX = v.x;
      if (v.y < min2DY) min2DY = v.y;
      if (v.x > max2DX) max2DX = v.x;
      if (v.y > max2DY) max2DY = v.y;
    }
    const midX = (min2DX + max2DX) * 0.5;
    const midY = (min2DY + max2DY) * 0.5;
    for (const v of vertices2D) {
      v.x -= midX;
      v.y -= midY;
    }

    const bboxWidthMm = Math.max(1, max2DX - min2DX);
    const bboxHeightMm = Math.max(1, max2DY - min2DY);

    // Compute per-triangle strain metrics
    let totalPieceArea2D = 0;
    let weightedStrainSum = 0;
    let maxStretchPct = 0;
    let maxCompressionPct = 0;

    const flattenedTriangles: FlattenedTriangle[] = localTrisData.map((lt) => {
      const p0_3d = vertices3D[lt.localV0];
      const p1_3d = vertices3D[lt.localV1];
      const p2_3d = vertices3D[lt.localV2];

      const p0_2d = vertices2D[lt.localV0];
      const p1_2d = vertices2D[lt.localV1];
      const p2_2d = vertices2D[lt.localV2];

      const area2D = Math.max(1e-12, Math.abs(signedArea2D(p0_2d, p1_2d, p2_2d)));
      totalPieceArea2D += area2D;

      const areaStrainPct = ((area2D - lt.area3D) / lt.area3D) * 100;

      // Edge strains
      const l0_3d = Math.max(1e-12, dist3D(p0_3d, p1_3d));
      const l1_3d = Math.max(1e-12, dist3D(p1_3d, p2_3d));
      const l2_3d = Math.max(1e-12, dist3D(p2_3d, p0_3d));

      const l0_2d = dist2D(p0_2d, p1_2d);
      const l1_2d = dist2D(p1_2d, p2_2d);
      const l2_2d = dist2D(p2_2d, p0_2d);

      const s0 = ((l0_2d - l0_3d) / l0_3d) * 100;
      const s1 = ((l1_2d - l1_3d) / l1_3d) * 100;
      const s2 = ((l2_2d - l2_3d) / l2_3d) * 100;

      // Pick dominant signed edge strain
      const edges = [s0, s1, s2];
      edges.sort((a, b) => Math.abs(b) - Math.abs(a));
      const maxEdgeStrainPct = edges[0];

      if (maxEdgeStrainPct > maxStretchPct) maxStretchPct = maxEdgeStrainPct;
      if (maxEdgeStrainPct < maxCompressionPct) maxCompressionPct = maxEdgeStrainPct;

      weightedStrainSum += Math.abs(maxEdgeStrainPct) * lt.area3D;
      triangleStrainMap.set(lt.triId, maxEdgeStrainPct);

      return {
        triId: lt.triId,
        localV0: lt.localV0,
        localV1: lt.localV1,
        localV2: lt.localV2,
        area3D: lt.area3D,
        area2D,
        areaStrainPct,
        maxEdgeStrainPct
      };
    });

    const meanStrainPct = totalPieceArea3D > 0 ? weightedStrainSum / totalPieceArea3D : 0;

    // Extract ordered outer boundary loop
    const boundaryLoop = extractOrderedBoundaryLoop(localTrisData, vertices2D);
    const seamPolygon2D = boundaryLoop.map((idx) => ({ ...vertices2D[idx] }));
    const cutPolygon2D = computeOutwardOffsetPolygon(seamPolygon2D, settings.seamAllowanceMm);

    // Compute perimeter
    let perimeterMm = 0;
    for (let i = 0; i < seamPolygon2D.length; i++) {
      const p1 = seamPolygon2D[i];
      const p2 = seamPolygon2D[(i + 1) % seamPolygon2D.length];
      perimeterMm += dist2D(p1, p2);
    }

    const savedPlacement = existingPositions?.get(pieceId);

    pieces.push({
      id: pieceId,
      name: pieceName,
      color: paletteEntry.color,
      triangleIds: triIds,
      vertices3D,
      globalVertexIds,
      vertices2D,
      triangles: flattenedTriangles,
      boundaryLoop,
      seamPolygon2D,
      cutPolygon2D,
      notches: [],
      position: savedPlacement ? { ...savedPlacement.position } : { x: 0, y: 0 },
      rotationDeg: savedPlacement ? savedPlacement.rotationDeg : 0,
      grainlineAngleDeg: savedPlacement ? savedPlacement.grainlineAngleDeg : 0,
      area3DMm2: totalPieceArea3D,
      area2DMm2: totalPieceArea2D,
      perimeterMm,
      bboxWidthMm,
      bboxHeightMm,
      meanStrainPct,
      maxStretchPct,
      maxCompressionPct
    });
  }

  // Generate paired alignment notches along shared 3D boundary edges between pieces
  generatePairedAlignmentNotches(pieces, settings.notchCountPerSeam);

  // If existingPositions was not supplied, auto-nest pieces onto the fabric roll
  if (!existingPositions || existingPositions.size === 0) {
    nestPiecesOnRoll(pieces, settings.rollWidthMm, settings.piecePaddingMm, settings.seamAllowanceMm);
  }

  // Calculate overall summary metrics
  const summary = computeSummaryMetrics(mesh, pieces, settings.rollWidthMm, settings.seamAllowanceMm);

  return {
    pieces,
    triangleStrainMap,
    summary
  };
}

/**
 * Finds shared 3D edges between different PatternPieces and places numbered alignment notches
 */
function generatePairedAlignmentNotches(pieces: PatternPiece[], notchesPerSeam: number) {
  if (notchesPerSeam <= 0) return;

  // Map global edge key "gMin_gMax" -> array of { pieceIdx, boundaryEdgeIdx, gA, gB }
  const sharedBoundaryEdges = new Map<
    string,
    { pieceIdx: number; boundaryEdgeIdx: number; localA: number; localB: number }[]
  >();

  pieces.forEach((piece, pieceIdx) => {
    const loop = piece.boundaryLoop;
    for (let i = 0; i < loop.length; i++) {
      const localA = loop[i];
      const localB = loop[(i + 1) % loop.length];
      const gA = piece.globalVertexIds[localA];
      const gB = piece.globalVertexIds[localB];
      const key = gA < gB ? `${gA}_${gB}` : `${gB}_${gA}`;
      if (!sharedBoundaryEdges.has(key)) {
        sharedBoundaryEdges.set(key, []);
      }
      sharedBoundaryEdges.get(key)!.push({
        pieceIdx,
        boundaryEdgeIdx: i,
        localA,
        localB
      });
    }
  });

  // Group shared edges by pair of pieces "(pieceIdxA, pieceIdxB)"
  const seamPairEdges = new Map<
    string,
    {
      pieceA: number;
      pieceB: number;
      edges: {
        edgeA: { localA: number; localB: number; boundaryEdgeIdx: number };
        edgeB: { localA: number; localB: number; boundaryEdgeIdx: number };
      }[];
    }
  >();

  for (const [, occurrences] of sharedBoundaryEdges.entries()) {
    if (occurrences.length === 2 && occurrences[0].pieceIdx !== occurrences[1].pieceIdx) {
      const [first, second] =
        occurrences[0].pieceIdx < occurrences[1].pieceIdx
          ? [occurrences[0], occurrences[1]]
          : [occurrences[1], occurrences[0]];
      const pairKey = `${first.pieceIdx}__${second.pieceIdx}`;
      if (!seamPairEdges.has(pairKey)) {
        seamPairEdges.set(pairKey, {
          pieceA: first.pieceIdx,
          pieceB: second.pieceIdx,
          edges: []
        });
      }
      seamPairEdges.get(pairKey)!.edges.push({
        edgeA: first,
        edgeB: second
      });
    }
  }

  let globalNotchNumber = 1;

  for (const [, seamGroup] of seamPairEdges.entries()) {
    const totalEdges = seamGroup.edges.length;
    if (totalEdges === 0) continue;

    const pA = pieces[seamGroup.pieceA];
    const pB = pieces[seamGroup.pieceB];

    const count = Math.min(notchesPerSeam, totalEdges);
    for (let k = 1; k <= count; k++) {
      const pickIdx = Math.min(totalEdges - 1, Math.floor((k / (count + 1)) * totalEdges));
      const shared = seamGroup.edges[pickIdx];

      // Add notch on Piece A
      const vA1 = pA.vertices2D[shared.edgeA.localA];
      const vA2 = pA.vertices2D[shared.edgeA.localB];
      const midA = { x: (vA1.x + vA2.x) * 0.5, y: (vA1.y + vA2.y) * 0.5 };
      const dxA = vA2.x - vA1.x;
      const dyA = vA2.y - vA1.y;
      const lenA = Math.max(1e-6, Math.hypot(dxA, dyA));
      const normA = { x: dyA / lenA, y: -dxA / lenA };

      pA.notches.push({
        id: `notch_${globalNotchNumber}_A`,
        position2D: midA,
        normal2D: normA,
        matchNumber: globalNotchNumber,
        targetPieceId: pB.id,
        edgeIndex: shared.edgeA.boundaryEdgeIdx
      });

      // Add matching notch on Piece B
      const vB1 = pB.vertices2D[shared.edgeB.localA];
      const vB2 = pB.vertices2D[shared.edgeB.localB];
      const midB = { x: (vB1.x + vB2.x) * 0.5, y: (vB1.y + vB2.y) * 0.5 };
      const dxB = vB2.x - vB1.x;
      const dyB = vB2.y - vB1.y;
      const lenB = Math.max(1e-6, Math.hypot(dxB, dyB));
      const normB = { x: dyB / lenB, y: -dxB / lenB };

      pB.notches.push({
        id: `notch_${globalNotchNumber}_B`,
        position2D: midB,
        normal2D: normB,
        matchNumber: globalNotchNumber,
        targetPieceId: pA.id,
        edgeIndex: shared.edgeB.boundaryEdgeIdx
      });

      globalNotchNumber++;
    }
  }
}

/**
 * Strip-packing nesting algorithm to arrange 2D pattern pieces onto a roll of width `rollWidthMm`
 */
export function nestPiecesOnRoll(
  pieces: PatternPiece[],
  rollWidthMm: number,
  paddingMm: number,
  seamAllowanceMm: number
): void {
  if (!Number.isFinite(rollWidthMm) || rollWidthMm <= 0) throw new Error('Roll width must be positive.');
  const margin = Math.max(0, paddingMm);
  let x = margin, y = margin, shelf = 0;
  const sorted = [...pieces].sort((a,b) => bounds(b.cutPolygon2D).maxY-bounds(b.cutPolygon2D).minY-(bounds(a.cutPolygon2D).maxY-bounds(a.cutPolygon2D).minY));
  for (const p of sorted) {
    const box = bounds(tablePolygon({...p,position:{x:0,y:0}}));
    const w = box.maxX-box.minX, h = box.maxY-box.minY;
    if (x + w + margin > rollWidthMm && x > margin) { x=margin; y+=shelf+margin; shelf=0; }
    p.position = {x:x-box.minX,y:y-box.minY};
    x += w+margin; shelf=Math.max(shelf,h);
  }
}

/**
 * Computes summary metrics across all pattern pieces
 */
export function computeSummaryMetrics(
  mesh: SurfaceMesh,
  pieces: PatternPiece[],
  rollWidthMm: number,
  seamAllowanceMm: number
): SolverSummaryMetrics {
  let totalArea3DMm2 = 0;
  let totalArea2DMm2 = 0;
  let weightedStrain = 0;
  let maxStrainPct = 0;
  let maxUsedLengthMm = 0;

  for (const p of pieces) {
    totalArea3DMm2 += p.area3DMm2;
    totalArea2DMm2 += p.area2DMm2;
    weightedStrain += p.meanStrainPct * p.area3DMm2;
    const piecePeak = Math.max(Math.abs(p.maxStretchPct), Math.abs(p.maxCompressionPct));
    if (piecePeak > maxStrainPct) maxStrainPct = piecePeak;

    const bottomEdge = bounds(tablePolygon(p)).maxY + 15;
    if (bottomEdge > maxUsedLengthMm) {
      maxUsedLengthMm = bottomEdge;
    }
  }

  const usedRollLengthMm = Math.max(100, Math.round(maxUsedLengthMm));
  const rollEnvelopeAreaMm2 = Math.max(1, rollWidthMm * usedRollLengthMm);
  const materialYieldPct = pieces.reduce((sum,p)=>sum+polygonArea(p.cutPolygon2D),0) / rollEnvelopeAreaMm2 * 100;

  return {
    totalArea3DCm2: totalArea3DMm2 / 100,
    totalArea2DCm2: totalArea2DMm2 / 100,
    overallMeanStrainPct: totalArea3DMm2 > 0 ? weightedStrain / totalArea3DMm2 : 0,
    overallMaxStrainPct: maxStrainPct,
    materialYieldPct,
    usedRollLengthMm,
    pieceCount: pieces.length,
    triangleCount: mesh.triangles.length,
    vertexCount: mesh.vertices.length
  };
}

/**
 * Splits a high-strain Pattern Piece along its principal spatial axis to relieve compound curvature strain
 */
export function splitPieceToRelieveStrain(mesh: SurfaceMesh, targetPieceId: string): SurfaceMesh {
  const pieceTris = mesh.triangles.filter((t) => t.pieceId === targetPieceId);
  if (pieceTris.length < 4) return mesh;

  // Find unused or next piece slot ID
  const usedIds = new Set(mesh.triangles.map((t) => t.pieceId));
  let newPieceId = `piece_${usedIds.size + 1}`;
  for (const p of PIECE_PALETTE) {
    if (!usedIds.has(p.id)) {
      newPieceId = p.id;
      break;
    }
  }

  // Compute bounding box & centroid of target piece in 3D
  let minX = Infinity,
    minY = Infinity,
    minZ = Infinity;
  let maxX = -Infinity,
    maxY = -Infinity,
    maxZ = -Infinity;
  let cx = 0,
    cy = 0,
    cz = 0;

  for (const t of pieceTris) {
    const v0 = mesh.vertices[t.v0];
    const v1 = mesh.vertices[t.v1];
    const v2 = mesh.vertices[t.v2];
    const tx = (v0.x + v1.x + v2.x) / 3;
    const ty = (v0.y + v1.y + v2.y) / 3;
    const tz = (v0.z + v1.z + v2.z) / 3;
    cx += tx;
    cy += ty;
    cz += tz;
    if (tx < minX) minX = tx;
    if (ty < minY) minY = ty;
    if (tz < minZ) minZ = tz;
    if (tx > maxX) maxX = tx;
    if (ty > maxY) maxY = ty;
    if (tz > maxZ) maxZ = tz;
  }

  cx /= pieceTris.length;
  cy /= pieceTris.length;
  cz /= pieceTris.length;

  const spanX = maxX - minX;
  const spanY = maxY - minY;
  const spanZ = maxZ - minZ;

  // Split along the widest spatial axis
  const updatedTriangles = mesh.triangles.map((t) => {
    if (t.pieceId !== targetPieceId) return t;
    const v0 = mesh.vertices[t.v0];
    const v1 = mesh.vertices[t.v1];
    const v2 = mesh.vertices[t.v2];
    const tx = (v0.x + v1.x + v2.x) / 3;
    const ty = (v0.y + v1.y + v2.y) / 3;
    const tz = (v0.z + v1.z + v2.z) / 3;

    let assignNew = false;
    if (spanX >= spanY && spanX >= spanZ) {
      assignNew = tx > cx;
    } else if (spanY >= spanX && spanY >= spanZ) {
      assignNew = ty > cy;
    } else {
      assignNew = tz > cz;
    }

    return {
      ...t,
      pieceId: assignNew ? newPieceId : targetPieceId
    };
  });

  return {
    ...mesh,
    triangles: separateTriangleIslands(updatedTriangles)
  };
}
