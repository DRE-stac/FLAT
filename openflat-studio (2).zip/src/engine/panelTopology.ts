// A pattern piece must be one edge-connected surface. Keep all islands as separately named pieces.
export function separateTriangleIslands<T extends {v0:number;v1:number;v2:number;pieceId:string}>(triangles:T[]):T[] {
  const edges=new Map<string,number[]>(),adj=triangles.map(()=>[] as number[]);
  triangles.forEach((t,i)=>{for(const [a,b] of [[t.v0,t.v1],[t.v1,t.v2],[t.v2,t.v0]]){const key=`${t.pieceId}:${Math.min(a,b)}_${Math.max(a,b)}`;if(!edges.has(key))edges.set(key,[]);edges.get(key)!.push(i);}});
  for(const list of edges.values())for(let i=1;i<list.length;i++){adj[list[0]].push(list[i]);adj[list[i]].push(list[0]);}
  const existingIds=new Set(triangles.map(t=>t.pieceId));let panelCount=0;
  const seen=new Set<number>(),counts=new Map<string,number>(),result=triangles.map(t=>({...t}));
  for(let seed=0;seed<triangles.length;seed++){
    if(seen.has(seed))continue;if(++panelCount>256)throw new Error('More than 256 disconnected panels. Repair or simplify the mesh before import.');const base=triangles[seed].pieceId,num=(counts.get(base)||0)+1;counts.set(base,num);let id=num===1?base:`${base}_island_${num}`;
    // Avoid collision with explicit imported identifiers.
    while(num>1&&existingIds.has(id))id+='_';
    const queue=[seed];seen.add(seed);
    for(let head=0;head<queue.length;head++){const i=queue[head];result[i].pieceId=id;for(const next of adj[i])if(!seen.has(next)){seen.add(next);queue.push(next);}}
  }
  return result;
}
