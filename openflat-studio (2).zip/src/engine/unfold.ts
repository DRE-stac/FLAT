import type {Vec2,Vec3} from '../types/pattern';
type Face={localV0:number;localV1:number;localV2:number};
const distance=(a:Vec3,b:Vec3)=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z);
// Triangle-by-triangle metric initialization. Loop closure on curved surfaces remains approximate.
export function unfoldTriangles(vertices:Vec3[],triangles:Face[],fallback:Vec2[]):Vec2[] {
  const coords:(Vec2|undefined)[]=Array(vertices.length);
  const edges=new Map<string,number[]>();
  const key=(a:number,b:number)=>a<b?`${a}_${b}`:`${b}_${a}`;
  const ids=(t:Face)=>[t.localV0,t.localV1,t.localV2];
  triangles.forEach((t,i)=>{const v=ids(t);for(let e=0;e<3;e++){const k=key(v[e],v[(e+1)%3]);if(!edges.has(k))edges.set(k,[]);edges.get(k)!.push(i);}});
  const seen=new Set<number>();
  for(let seed=0;seed<triangles.length;seed++){
    if(seen.has(seed))continue;
    const [a,b,c]=ids(triangles[seed]);
    if(coords[a]||coords[b]||coords[c])return fallback; // Vertex-only contact or inconsistent component.
    const ab=distance(vertices[a],vertices[b]);if(ab<1e-12)return fallback;
    const ac=distance(vertices[a],vertices[c]),bc=distance(vertices[b],vertices[c]);
    const x=(ac*ac-bc*bc+ab*ab)/(2*ab),h=Math.sqrt(Math.max(0,ac*ac-x*x));
    coords[a]={x:0,y:0};coords[b]={x:ab,y:0};coords[c]={x,y:h};
    const queue=[seed];seen.add(seed);
    for(let head=0;head<queue.length;head++){
      const t=triangles[queue[head]],v=ids(t);
      for(let e=0;e<3;e++){
        const u=v[e],w=v[(e+1)%3];
        for(const next of edges.get(key(u,w))||[]){
          if(seen.has(next))continue;const nv=ids(triangles[next]);
          const n=nv.find(n=>n!==u&&n!==w)!;
          if(!coords[n]){
            const p=coords[u]!,q=coords[w]!,len=Math.hypot(q.x-p.x,q.y-p.y);
            if(len<1e-12)return fallback;
            const un=distance(vertices[u],vertices[n]),wn=distance(vertices[w],vertices[n]);
            const x=(un*un-wn*wn+len*len)/(2*len),y=Math.sqrt(Math.max(0,un*un-x*x));
            const index=nv.indexOf(u),direction=nv[(index+1)%3]===w?1:-1;
            coords[n]={x:p.x+(q.x-p.x)/len*x-(q.y-p.y)/len*y*direction,y:p.y+(q.y-p.y)/len*x+(q.x-p.x)/len*y*direction};
          }
          seen.add(next);queue.push(next);
        }
      }
    }
  }
  const unfolded=coords as Vec2[];
  if(unfolded.some(v=>!v))return fallback;
  const score=(vs:Vec2[])=>{
    let error=0,flips=0;
    for(const t of triangles){const v=ids(t);const a=vs[v[0]],b=vs[v[1]],c=vs[v[2]];if((b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x)<=0)flips++;
      for(let e=0;e<3;e++){const i=v[e],j=v[(e+1)%3];const rest=distance(vertices[i],vertices[j]);if(rest>1e-12)error+=((Math.hypot(vs[i].x-vs[j].x,vs[i].y-vs[j].y)-rest)/rest)**2;}}
    return error+flips*10;
  };
  return score(unfolded)<score(fallback)?unfolded:fallback;
}
