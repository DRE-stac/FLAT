import type { MaterialSpec, PatternPiece, SurfaceMesh, Vec2 } from '../types/pattern';
export interface QualityIssue { severity: 'error' | 'warning'; pieceId?: string; message: string }
export function tablePolygon(p: PatternPiece): Vec2[] {
  const a = p.rotationDeg * Math.PI / 180;
  return (p.cutPolygon2D.length?p.cutPolygon2D:p.vertices2D).map(v => ({x:p.position.x + v.x*Math.cos(a)-v.y*Math.sin(a), y:p.position.y+v.x*Math.sin(a)+v.y*Math.cos(a)}));
}
export function polygonArea(poly: Vec2[]): number {
  return Math.abs(poly.reduce((s,p,i)=>{const q=poly[(i+1)%poly.length];return s+p.x*q.y-q.x*p.y},0)/2);
}
export function bounds(poly: Vec2[]) {
  if(!poly.length)return {minX:0,maxX:0,minY:0,maxY:0};
  return {minX:Math.min(...poly.map(p=>p.x)),maxX:Math.max(...poly.map(p=>p.x)),minY:Math.min(...poly.map(p=>p.y)),maxY:Math.max(...poly.map(p=>p.y))};
}
function crosses(a:Vec2,b:Vec2,c:Vec2,d:Vec2) {
  const cross=(p:Vec2,q:Vec2,r:Vec2)=>(q.x-p.x)*(r.y-p.y)-(q.y-p.y)*(r.x-p.x);
  return cross(a,b,c)*cross(a,b,d)<-1e-8 && cross(c,d,a)*cross(c,d,b)<-1e-8;
}
function inside(p:Vec2, poly:Vec2[]) {
  let yes=false;for(let i=0,j=poly.length-1;i<poly.length;j=i++) {const a=poly[i],b=poly[j];if((a.y>p.y)!==(b.y>p.y)&&p.x<(b.x-a.x)*(p.y-a.y)/(b.y-a.y)+a.x)yes=!yes}return yes;
}
function selfCrossing(poly:Vec2[]) {
  for(let i=0;i<poly.length;i++)for(let j=i+2;j<poly.length;j++){if(i===0&&j===poly.length-1)continue;if(crosses(poly[i],poly[(i+1)%poly.length],poly[j],poly[(j+1)%poly.length]))return true}return false;
}
export function auditPatterns(mesh:SurfaceMesh, pieces:PatternPiece[], mat:MaterialSpec, width:number):QualityIssue[] {
  const issues:QualityIssue[]=[];
  const edgeCounts=new Map<string,number>();
  for(const t of mesh.triangles)for(const [a,b] of [[t.v0,t.v1],[t.v1,t.v2],[t.v2,t.v0]]){const k=[a,b].sort((a,b)=>a-b).join('_');edgeCounts.set(k,(edgeCounts.get(k)||0)+1)}
  if([...edgeCounts.values()].some(n=>n>2))issues.push({severity:'error',message:'Non-manifold mesh edges. Repair the source mesh before cutting.'});
  const polys=pieces.map(tablePolygon);
  pieces.forEach((p,i)=>{
    const error=(message:string)=>issues.push({severity:'error',pieceId:p.id,message:`${p.name}: ${message}`});
    if(p.vertices2D.some(v=>!Number.isFinite(v.x)||!Number.isFinite(v.y)))error('non-finite flattened coordinates.');
    const counts=new Map<string,number>();
    for(const t of p.triangles)for(const [a,b] of [[t.localV0,t.localV1],[t.localV1,t.localV2],[t.localV2,t.localV0]]){const k=[a,b].sort((a,b)=>a-b).join('_');counts.set(k,(counts.get(k)||0)+1)}
    const boundaryEdges=[...counts.values()].filter(n=>n===1).length;
    if(p.boundaryLoop.length<3)error('closed surface has no cut boundary. Add seams.');
    else if(boundaryEdges!==p.boundaryLoop.length)error('multiple or broken boundary loops. Add seams to open holes or disconnected regions.');
    const signs=p.triangles.map(t=>{const a=p.vertices2D[t.localV0],b=p.vertices2D[t.localV1],c=p.vertices2D[t.localV2];return (b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x)});
    if(signs.some(s=>Math.abs(s)<1e-8)||signs.some(s=>s>0)&&signs.some(s=>s<0))error('collapsed or flipped triangles. Split this panel.');
    if(selfCrossing(p.cutPolygon2D)||selfCrossing(p.seamPolygon2D))error('self-intersecting cut or seam outline. Split this panel or reduce allowance.');
    const b=bounds(polys[i]);
    if(b.minX< -0.01||b.maxX>width+0.01||b.minY< -0.01)error('cut outline extends outside the roll. Reposition or increase roll width.');
    const peak=Math.max(Math.abs(p.maxStretchPct),Math.abs(p.maxCompressionPct));
    if(peak>mat.maxAllowableStrainPct)issues.push({severity:'warning',pieceId:p.id,message:`${p.name}: ${peak.toFixed(1)}% edge distortion exceeds the preset ${mat.maxAllowableStrainPct}% limit.`});
  });
  for(let i=0;i<polys.length;i++)for(let j=i+1;j<polys.length;j++){
    const a=polys[i],b=polys[j];if(a.length<3||b.length<3)continue;
    const x=bounds(a),y=bounds(b);if(x.maxX<=y.minX||y.maxX<=x.minX||x.maxY<=y.minY||y.maxY<=x.minY)continue;
    if(a.some(p=>inside(p,b))||b.some(p=>inside(p,a))||a.some((p,k)=>b.some((q,l)=>crosses(p,a[(k+1)%a.length],q,b[(l+1)%b.length]))))issues.push({severity:'error',message:`Cut outlines overlap: ${pieces[i].name} / ${pieces[j].name}. Re-nest or move them apart.`});
  }
  return issues;
}
