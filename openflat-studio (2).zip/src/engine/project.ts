import type { MaterialSpec, ParametricConfig, PatternPiece, RepatternConfig, SolverSettings, SurfaceMesh } from '../types/pattern';
import { computeMeshGeometryData } from './meshGenerators';
export interface Project { format:'openflat'; version:2; mesh:SurfaceMesh; material:MaterialSpec; settings:SolverSettings; parametricConfig:ParametricConfig; repatternConfig:RepatternConfig; placements: {id:string;position:{x:number;y:number};rotationDeg:number;grainlineAngleDeg:number}[] }
export function makeProject(mesh:SurfaceMesh,material:MaterialSpec,settings:SolverSettings,parametricConfig:ParametricConfig,repatternConfig:RepatternConfig,pieces:PatternPiece[]):Project {
  return {format:'openflat',version:2,mesh,material,settings,parametricConfig,repatternConfig,placements:pieces.map(({id,position,rotationDeg,grainlineAngleDeg})=>({id,position,rotationDeg,grainlineAngleDeg}))};
}
export function parseProject(text:string):Project {
  const p=JSON.parse(text);
  if(p?.format!=='openflat'||p.version!==2)throw new Error('Choose an OpenFlat v2 project. Legacy JSON reports contain no mesh and cannot be reopened.');
  const finite=(n:unknown)=>typeof n==='number'&&Number.isFinite(n);
  const range=(n:unknown,a:number,b:number)=>finite(n)&&Number(n)>=a&&Number(n)<=b;
  if(!p.mesh||typeof p.mesh.name!=='string'||typeof p.mesh.templateId!=='string'||!Array.isArray(p.mesh.vertices)||p.mesh.vertices.length<3||p.mesh.vertices.length>84000||!Array.isArray(p.mesh.triangles)||p.mesh.triangles.length<1||p.mesh.triangles.length>28000)throw new Error('Invalid project mesh.');
  if(p.mesh.vertices.some((v:any)=>!v||![v.x,v.y,v.z].every(finite)))throw new Error('Invalid mesh coordinates.');
  if(p.mesh.triangles.some((t:any)=>!t||typeof t.pieceId!=='string'||![t.v0,t.v1,t.v2].every(i=>Number.isInteger(i)&&i>=0&&i<p.mesh.vertices.length)||new Set([t.v0,t.v1,t.v2]).size<3))throw new Error('Invalid mesh triangle indices.');
  const s=p.settings,m=p.material,c=p.parametricConfig,r=p.repatternConfig;
  if(!s||!['optimized','pre_flatten'].includes(s.stage)||!range(s.iterations,1,300)||!range(s.rollWidthMm,10,20000)||!range(s.seamAllowanceMm,0,100)||!range(s.piecePaddingMm,0,1000)||!range(s.notchCountPerSeam,0,20))throw new Error('Invalid solver settings.');
  if(!m||typeof m.name!=='string'||typeof m.id!=='string'||!range(m.poissonRatio,0,0.5)||!range(m.shearStiffnessRatio,0,10)||!range(m.maxAllowableStrainPct,0,1000)||!range(m.thicknessMm,0,100)||!range(m.youngsModulusMPa,0,1e9))throw new Error('Invalid material preset.');
  if(!c||![c.scaleX,c.scaleY,c.scaleZ].every(n=>range(n,0.01,100))||!range(c.curvatureBoost,0.1,10)||!['standard','high'].includes(c.resolution))throw new Error('Invalid shape settings.');
  if(!r||!['feature_crease','normal_kmeans','axis_slices'].includes(r.mode)||!range(r.targetPanelCount,2,100)||!range(r.creaseAngleDeg,0,180))throw new Error('Invalid panel settings.');
  if(!Array.isArray(p.placements)||p.placements.some((v:any)=>!v||typeof v.id!=='string'||!v.position||![v.position.x,v.position.y,v.rotationDeg,v.grainlineAngleDeg].every(finite)))throw new Error('Invalid placements.');
  p.mesh=computeMeshGeometryData(p.mesh.name,p.mesh.templateId,p.mesh.vertices,p.mesh.triangles);
  return p;
}
