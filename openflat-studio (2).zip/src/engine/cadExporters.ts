const xml=(s:string)=>s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]!));
const csv=(s:string)=>'"'+(/^[=+@\-]/.test(s)?"'":'')+s.replace(/"/g,'""')+'"';
import { MaterialSpec, PatternPiece, SolverSettings, SolverSummaryMetrics, SurfaceMesh, Vec2 } from '../types/pattern';

function transformLocalToTable(pt: Vec2, piece: PatternPiece): Vec2 {
  const rad = (piece.rotationDeg * Math.PI) / 180;
  const cos = Math.cos(rad);
  const sin = Math.sin(rad);
  return {
    x: piece.position.x + (pt.x * cos - pt.y * sin),
    y: piece.position.y + (pt.x * sin + pt.y * cos)
  };
}

function rotateVec(v: Vec2, deg: number): Vec2 {
  const rad = (deg * Math.PI) / 180;
  const cos = Math.cos(rad);
  const sin = Math.sin(rad);
  return {
    x: v.x * cos - v.y * sin,
    y: v.x * sin + v.y * cos
  };
}

export function triggerFileDownload(filename: string, content: string, mimeType = 'text/plain;charset=utf-8') {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Generates an AutoCAD R12/2000 compatible DXF file with industrial CAD layers:
 * CUT_LINE, SEAM_LINE, NOTCHES, GRAINLINE, ANNOTATIONS, ROLL_BOUNDARY
 */
export function generateDXFContent(
  pieces: PatternPiece[],
  settings: SolverSettings,
  summary: SolverSummaryMetrics
): string {
  const lines: string[] = [];

  const push = (code: number, val: string | number) => {
    lines.push(String(code));
    lines.push(String(val));
  };

  // HEADER section (Metric millimeters)
  push(0, 'SECTION');
  push(2, 'HEADER');
  push(9, '$INSUNITS');
  push(70, 4); // 4 = millimeters
  push(0, 'ENDSEC');

  // TABLES section (Layer definitions)
  push(0, 'SECTION');
  push(2, 'TABLES');
  push(0, 'TABLE');
  push(2, 'LAYER');
  push(70, 6);

  const layers = [
    { name: 'CUT_LINE', color: 1 },      // Red
    { name: 'SEAM_LINE', color: 4 },     // Cyan
    { name: 'NOTCHES', color: 2 },       // Yellow
    { name: 'GRAINLINE', color: 3 },     // Green
    { name: 'ANNOTATIONS', color: 7 },   // White
    { name: 'ROLL_BOUNDARY', color: 8 }  // Gray
  ];

  for (const l of layers) {
    push(0, 'LAYER');
    push(2, l.name);
    push(70, 0);
    push(62, l.color);
    push(6, 'CONTINUOUS');
  }
  push(0, 'ENDTAB');
  push(0, 'ENDSEC');

  // ENTITIES section
  push(0, 'SECTION');
  push(2, 'ENTITIES');

  const drawClosedPolyline = (pts: Vec2[], layer: string) => {
    if (pts.length < 2) return;
    for (let i = 0; i < pts.length; i++) {
      const p1 = pts[i];
      const p2 = pts[(i + 1) % pts.length];
      push(0, 'LINE');
      push(8, layer);
      push(10, p1.x.toFixed(3));
      push(20, (-p1.y).toFixed(3)); // Flip Y for standard CAD Cartesian Y-up
      push(30, '0.0');
      push(11, p2.x.toFixed(3));
      push(21, (-p2.y).toFixed(3));
      push(31, '0.0');
    }
  };

  const drawSegment = (p1: Vec2, p2: Vec2, layer: string) => {
    push(0, 'LINE');
    push(8, layer);
    push(10, p1.x.toFixed(3));
    push(20, (-p1.y).toFixed(3));
    push(30, '0.0');
    push(11, p2.x.toFixed(3));
    push(21, (-p2.y).toFixed(3));
    push(31, '0.0');
  };

  const drawText = (pt: Vec2, height: number, text: string, layer: string) => {
    push(0, 'TEXT');
    push(8, layer);
    push(10, pt.x.toFixed(3));
    push(20, (-pt.y).toFixed(3));
    push(30, '0.0');
    push(40, height.toFixed(2));
    push(1, text);
  };

  // Roll boundary frame
  const rollW = settings.rollWidthMm;
  const rollL = summary.usedRollLengthMm;
  drawClosedPolyline(
    [
      { x: 0, y: 0 },
      { x: rollW, y: 0 },
      { x: rollW, y: rollL },
      { x: 0, y: rollL }
    ],
    'ROLL_BOUNDARY'
  );

  for (const piece of pieces) {
    // 1. Net Seam Line
    const seamPts = piece.seamPolygon2D.map((pt) => transformLocalToTable(pt, piece));
    drawClosedPolyline(seamPts, 'SEAM_LINE');

    // 2. Outer Cut Line (if seamAllowanceMm > 0)
    if (settings.seamAllowanceMm > 0.1) {
      const cutPts = piece.cutPolygon2D.map((pt) => transformLocalToTable(pt, piece));
      drawClosedPolyline(cutPts, 'CUT_LINE');
    }

    // 3. Alignment Notches
    const notchLen = Math.max(5, settings.seamAllowanceMm > 0 ? settings.seamAllowanceMm : 6);
    for (const notch of piece.notches) {
      const basePt = transformLocalToTable(notch.position2D, piece);
      const worldNorm = rotateVec(notch.normal2D, piece.rotationDeg);
      const tipPt = {
        x: basePt.x + worldNorm.x * notchLen,
        y: basePt.y + worldNorm.y * notchLen
      };
      drawSegment(basePt, tipPt, 'NOTCHES');
      drawText(tipPt, 5, `N${notch.matchNumber}`, 'ANNOTATIONS');
    }

    // 4. Grainline Arrow
    const gLen = Math.max(25, Math.min(piece.bboxWidthMm, piece.bboxHeightMm) * 0.35);
    const totalAngle = piece.rotationDeg + piece.grainlineAngleDeg;
    const gDir = rotateVec({ x: 1, y: 0 }, totalAngle);
    const gStart = {
      x: piece.position.x - gDir.x * gLen * 0.5,
      y: piece.position.y - gDir.y * gLen * 0.5
    };
    const gEnd = {
      x: piece.position.x + gDir.x * gLen * 0.5,
      y: piece.position.y + gDir.y * gLen * 0.5
    };
    drawSegment(gStart, gEnd, 'GRAINLINE');

    // 5. Piece Annotation Label
    drawText(
      { x: piece.position.x - 28, y: piece.position.y - 6 },
      8.5,
      `${piece.name} (${(piece.area2DMm2 / 100).toFixed(1)} cm2)`,
      'ANNOTATIONS'
    );
  }

  push(0, 'ENDSEC');
  push(0, 'EOF');

  return lines.join('\n');
}

/**
 * Generates 1:1 millimeter-scale SVG vector layout for laser cutters, plotters, and Illustrator
 */
export function generateSVGContent(
  pieces: PatternPiece[],
  settings: SolverSettings,
  summary: SolverSummaryMetrics,
  material: MaterialSpec
): string {
  const widthMm = settings.rollWidthMm;
  const heightMm = Math.max(300, summary.usedRollLengthMm + 40);

  const svgParts: string[] = [];
  svgParts.push(`<?xml version="1.0" encoding="UTF-8" standalone="no"?>`);
  svgParts.push(
    `<svg xmlns="http://www.w3.org/2000/svg" width="${widthMm}mm" height="${heightMm}mm" viewBox="0 0 ${widthMm} ${heightMm}">`
  );
  svgParts.push(`  <defs>`);
  svgParts.push(
    `    <style>
      .roll-bg { fill: #FFFFFF; stroke: #64748B; stroke-width: 1.5; stroke-dasharray: 8 4; }
      .cut-line { fill: rgba(245, 158, 11, 0.05); stroke: #EF4444; stroke-width: 1.2; }
      .seam-line { fill: rgba(6, 182, 212, 0.08); stroke: #06B6D4; stroke-width: 1.0; stroke-dasharray: 4 2; }
      .mesh-edge { fill: none; stroke: rgba(148, 163, 184, 0.22); stroke-width: 0.4; }
      .notch-mark { stroke: #F59E0B; stroke-width: 1.4; }
      .grain-line { stroke: #10B981; stroke-width: 1.2; }
      .label-title { font-family: monospace; font-size: 11px; fill: #0F172A; font-weight: bold; }
      .label-sub { font-family: monospace; font-size: 8.5px; fill: #475569; }
    </style>`
  );
  svgParts.push(`  </defs>`);

  // Roll boundary
  svgParts.push(`  <rect x="0" y="0" width="${widthMm}" height="${heightMm}" class="roll-bg" />`);
  svgParts.push(
    `  <text x="16" y="22" class="label-sub">OPENFLAT STUDIO CAD EXPORT | MATERIAL: ${xml(material.name.toUpperCase())} | ROLL WIDTH: ${widthMm}mm | SEAM ALLOWANCE: ${settings.seamAllowanceMm}mm</text>`
  );

  for (const piece of pieces) {
    svgParts.push(`  <g id="${xml(piece.id)}">`);

    // Outer Cut Polygon
    if (settings.seamAllowanceMm > 0.1 && piece.cutPolygon2D.length >= 3) {
      const cutPts = piece.cutPolygon2D
        .map((pt) => {
          const w = transformLocalToTable(pt, piece);
          return `${w.x.toFixed(2)},${w.y.toFixed(2)}`;
        })
        .join(' ');
      svgParts.push(`    <polygon points="${cutPts}" class="cut-line" />`);
    }

    // Net Seam Polygon
    if (piece.seamPolygon2D.length >= 3) {
      const seamPts = piece.seamPolygon2D
        .map((pt) => {
          const w = transformLocalToTable(pt, piece);
          return `${w.x.toFixed(2)},${w.y.toFixed(2)}`;
        })
        .join(' ');
      svgParts.push(`    <polygon points="${seamPts}" class="seam-line" />`);
    }

    // Internal Flattened Mesh Triangles
    for (const tri of piece.triangles) {
      const p0 = transformLocalToTable(piece.vertices2D[tri.localV0], piece);
      const p1 = transformLocalToTable(piece.vertices2D[tri.localV1], piece);
      const p2 = transformLocalToTable(piece.vertices2D[tri.localV2], piece);
      svgParts.push(
        `    <polygon points="${p0.x.toFixed(2)},${p0.y.toFixed(2)} ${p1.x.toFixed(2)},${p1.y.toFixed(2)} ${p2.x.toFixed(2)},${p2.y.toFixed(2)}" class="mesh-edge" />`
      );
    }

    // Notches
    const notchLen = Math.max(5, settings.seamAllowanceMm > 0 ? settings.seamAllowanceMm : 6);
    for (const notch of piece.notches) {
      const basePt = transformLocalToTable(notch.position2D, piece);
      const worldNorm = rotateVec(notch.normal2D, piece.rotationDeg);
      const tipPt = {
        x: basePt.x + worldNorm.x * notchLen,
        y: basePt.y + worldNorm.y * notchLen
      };
      svgParts.push(
        `    <line x1="${basePt.x.toFixed(2)}" y1="${basePt.y.toFixed(2)}" x2="${tipPt.x.toFixed(2)}" y2="${tipPt.y.toFixed(2)}" class="notch-mark" />`
      );
      svgParts.push(
        `    <text x="${(tipPt.x + 2).toFixed(2)}" y="${(tipPt.y - 2).toFixed(2)}" class="label-sub">#${notch.matchNumber}</text>`
      );
    }

    // Grainline
    const gLen = Math.max(30, Math.min(piece.bboxWidthMm, piece.bboxHeightMm) * 0.35);
    const gDir = rotateVec({ x: 1, y: 0 }, piece.rotationDeg + piece.grainlineAngleDeg);
    const g1 = {
      x: piece.position.x - gDir.x * gLen * 0.5,
      y: piece.position.y - gDir.y * gLen * 0.5
    };
    const g2 = {
      x: piece.position.x + gDir.x * gLen * 0.5,
      y: piece.position.y + gDir.y * gLen * 0.5
    };
    svgParts.push(
      `    <line x1="${g1.x.toFixed(2)}" y1="${g1.y.toFixed(2)}" x2="${g2.x.toFixed(2)}" y2="${g2.y.toFixed(2)}" class="grain-line" />`
    );

    // Piece callout
    svgParts.push(
      `    <text x="${piece.position.x.toFixed(2)}" y="${(piece.position.y - 4).toFixed(2)}" text-anchor="middle" class="label-title">${xml(piece.name)}</text>`
    );
    svgParts.push(
      `    <text x="${piece.position.x.toFixed(2)}" y="${(piece.position.y + 9).toFixed(2)}" text-anchor="middle" class="label-sub">${(piece.area2DMm2 / 100).toFixed(1)} cm² | Strain: ${piece.meanStrainPct.toFixed(2)}%</text>`
    );

    svgParts.push(`  </g>`);
  }

  svgParts.push(`<g stroke="#0F172A" stroke-width="0.5"><line x1="16" y1="${heightMm-18}" x2="116" y2="${heightMm-18}"/><line x1="16" y1="${heightMm-23}" x2="16" y2="${heightMm-13}"/><line x1="116" y1="${heightMm-23}" x2="116" y2="${heightMm-13}"/></g><text x="126" y="${heightMm-15}" class="label-sub">100 mm calibration · Print at 100%</text>`);
  svgParts.push(`</svg>`);
  return svgParts.join('\n');
}

/**
 * Generates Wavefront .OBJ with 3D geometry AND the flattened 2D pattern coordinates baked as UV texture coordinates (`vt`)
 */
export function generateOBJWithUVContent(
  mesh: SurfaceMesh,
  pieces: PatternPiece[],
  settings: SolverSettings,
  summary: SolverSummaryMetrics
): string {
  const lines: string[] = [];
  lines.push(`# OpenFlat Studio 3D Mesh + Flattened 2D UV Export`);
  lines.push(`# Model: ${mesh.name}`);
  lines.push(`# Units: millimeters (mm)`);
  lines.push('');

  // Write all 3D vertices
  for (const v of mesh.vertices) {
    lines.push(`v ${v.x.toFixed(4)} ${v.y.toFixed(4)} ${v.z.toFixed(4)}`);
  }
  lines.push('');

  // Write 2D UV coordinates per piece vertex (normalized to roll bounds)
  const normScale = Math.max(settings.rollWidthMm, summary.usedRollLengthMm, 1000);
  const pieceVtOffsets = new Map<string, number>();
  let currentVtOffset = 1;

  for (const piece of pieces) {
    pieceVtOffsets.set(piece.id, currentVtOffset);
    for (const pt2D of piece.vertices2D) {
      const tablePt = transformLocalToTable(pt2D, piece);
      const u = tablePt.x / normScale;
      const v = 1.0 - tablePt.y / normScale;
      lines.push(`vt ${u.toFixed(5)} ${v.toFixed(5)}`);
    }
    currentVtOffset += piece.vertices2D.length;
  }
  lines.push('');

  // Write faces grouped by PatternPiece
  for (const piece of pieces) {
    const vtBase = pieceVtOffsets.get(piece.id) || 1;
    lines.push(`g ${piece.name.replace(/\s+/g, '_')}`);
    for (const tri of piece.triangles) {
      const gV0 = piece.globalVertexIds[tri.localV0] + 1;
      const gV1 = piece.globalVertexIds[tri.localV1] + 1;
      const gV2 = piece.globalVertexIds[tri.localV2] + 1;

      const vt0 = vtBase + tri.localV0;
      const vt1 = vtBase + tri.localV1;
      const vt2 = vtBase + tri.localV2;

      lines.push(`f ${gV0}/${vt0} ${gV1}/${vt1} ${gV2}/${vt2}`);
    }
    lines.push('');
  }

  return lines.join('\n');
}

/**
 * Generates ASCII .STL of the 3D surface geometry for 3D printing / mold tooling
 */
export function generateSTLContent(mesh: SurfaceMesh): string {
  const safeName = mesh.name.replace(/\s+/g, '_');
  const lines: string[] = [`solid ${safeName}`];

  for (const t of mesh.triangles) {
    const v0 = mesh.vertices[t.v0];
    const v1 = mesh.vertices[t.v1];
    const v2 = mesh.vertices[t.v2];
    const n = t.normal;
    lines.push(`  facet normal ${n.x.toFixed(5)} ${n.y.toFixed(5)} ${n.z.toFixed(5)}`);
    lines.push(`    outer loop`);
    lines.push(`      vertex ${v0.x.toFixed(4)} ${v0.y.toFixed(4)} ${v0.z.toFixed(4)}`);
    lines.push(`      vertex ${v1.x.toFixed(4)} ${v1.y.toFixed(4)} ${v1.z.toFixed(4)}`);
    lines.push(`      vertex ${v2.x.toFixed(4)} ${v2.y.toFixed(4)} ${v2.z.toFixed(4)}`);
    lines.push(`    endloop`);
    lines.push(`  endfacet`);
  }

  lines.push(`endsolid ${safeName}`);
  return lines.join('\n');
}

/**
 * Generates an engineering CSV report of all flattened pattern pieces, areas, dimensions, and strain analysis
 */
export function generateCSVReport(
  pieces: PatternPiece[],
  material: MaterialSpec,
  settings: SolverSettings,
  summary: SolverSummaryMetrics
): string {
  const rows: string[] = [];
  rows.push(
    [
      'Piece ID',
      'Panel Name',
      'Material',
      '3D Surface Area (cm2)',
      '2D Flattened Area (cm2)',
      'Perimeter (mm)',
      'Width (mm)',
      'Height (mm)',
      'Seam Allowance (mm)',
      'Mean Strain (%)',
      'Peak Stretch (%)',
      'Peak Compression (%)',
      'Alignment Notches'
    ].join(',')
  );

  for (const p of pieces) {
    rows.push(
      [
        p.id,
        csv(p.name),
        csv(material.name),
        (p.area3DMm2 / 100).toFixed(2),
        (p.area2DMm2 / 100).toFixed(2),
        p.perimeterMm.toFixed(1),
        p.bboxWidthMm.toFixed(1),
        p.bboxHeightMm.toFixed(1),
        settings.seamAllowanceMm.toFixed(1),
        p.meanStrainPct.toFixed(2),
        p.maxStretchPct.toFixed(2),
        p.maxCompressionPct.toFixed(2),
        p.notches.length
      ].join(',')
    );
  }

  rows.push('');
  rows.push(
    `SUMMARY,"Total Pieces: ${summary.pieceCount}","Material Yield: ${summary.materialYieldPct.toFixed(1)}%","Roll Width: ${settings.rollWidthMm}mm","Required Roll Length: ${summary.usedRollLengthMm}mm","Overall Mean Strain: ${summary.overallMeanStrainPct.toFixed(2)}%"`
  );

  return rows.join('\n');
}
