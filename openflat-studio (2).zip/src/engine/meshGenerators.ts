import {separateTriangleIslands} from './panelTopology';
import { MaterialSpec, MeshTriangle, ParametricConfig, RepatternConfig, RepatternMode, SurfaceMesh, Vec3 } from '../types/pattern';

export const MATERIAL_LIBRARY: MaterialSpec[] = [
  {
    id: 'leather_auto',
    name: 'Automotive Nappa Leather (1.4mm)',
    category: 'Leather & Upholstery',
    thicknessMm: 1.4,
    youngsModulusMPa: 45,
    poissonRatio: 0.38,
    shearStiffnessRatio: 0.42,
    maxAllowableStrainPct: 4.5,
    defaultRollWidthMm: 1400,
    description: 'Full-grain perforated automotive seating hide with moderate isotropic hide compliance.'
  },
  {
    id: 'carbon_prepreg',
    name: '3K Woven Carbon Prepreg (2x2 Twill)',
    category: 'Composite',
    thicknessMm: 0.35,
    youngsModulusMPa: 850,
    poissonRatio: 0.12,
    shearStiffnessRatio: 0.18,
    maxAllowableStrainPct: 1.5,
    defaultRollWidthMm: 1270,
    description: 'High-modulus aerospace twill weave; allows trellis scissoring shear up to locking angle with minimal fiber elongation.'
  },
  {
    id: 'marine_hypalon',
    name: 'Marine Hypalon CSM (1100 dtex)',
    category: 'Technical Textile',
    thicknessMm: 1.2,
    youngsModulusMPa: 120,
    poissonRatio: 0.3,
    shearStiffnessRatio: 0.55,
    maxAllowableStrainPct: 2.8,
    defaultRollWidthMm: 1500,
    description: 'Heavy-duty coated polyester scrim for inflatable RIB tubes, boat bimini tops, and structural hulls.'
  },
  {
    id: 'cordura_1000d',
    name: 'Ballistic Cordura 1000D Nylon',
    category: 'Technical Textile',
    thicknessMm: 0.65,
    youngsModulusMPa: 180,
    poissonRatio: 0.25,
    shearStiffnessRatio: 0.6,
    maxAllowableStrainPct: 2.2,
    defaultRollWidthMm: 1520,
    description: 'High-tenacity plain-weave nylon for tactical gear, luggage shells, and abrasion-resistant footwear uppers.'
  },
  {
    id: 'neoprene_stretch',
    name: '4-Way Stretch Closed-Cell Neoprene (3.0mm)',
    category: 'Elastomer',
    thicknessMm: 3.0,
    youngsModulusMPa: 12,
    poissonRatio: 0.46,
    shearStiffnessRatio: 0.35,
    maxAllowableStrainPct: 12.0,
    defaultRollWidthMm: 1350,
    description: 'High-elongation elastomeric foam laminate for ergonomic braces, wetsuits, and contoured soft goods.'
  }
];

export const PIECE_PALETTE: { id: string; name: string; color: string }[] = [
  { id: 'piece_1', name: 'Center Panel', color: '#06B6D4' },   // Cyan
  { id: 'piece_2', name: 'Left Bolster', color: '#F59E0B' },   // Amber
  { id: 'piece_3', name: 'Right Bolster', color: '#10B981' },  // Emerald
  { id: 'piece_4', name: 'Upper Crown', color: '#3B82F6' },    // Blue
  { id: 'piece_5', name: 'Lower Skirt', color: '#EC4899' },    // Pink
  { id: 'piece_6', name: 'Side Gusset', color: '#EAB308' },    // Yellow
  { id: 'piece_7', name: 'Relief Gore A', color: '#14B8A6' },  // Teal
  { id: 'piece_8', name: 'Relief Gore B', color: '#F97316' }   // Orange
];

export interface TemplateMetadata {
  id: string;
  name: string;
  industry: string;
  summary: string;
  defaultMaterialId: string;
  pieceNames: Record<string, string>;
}

export const MODEL_TEMPLATES: TemplateMetadata[] = [
  {id:'calibration_sheet',name:'Calibration · 100 × 50 mm sheet',industry:'Verification',summary:'Planar sheet for checking units, edge preservation and printer scale.',defaultMaterialId:'leather_auto',pieceNames:{piece_1:'100 × 50 mm calibration sheet'}},
  {id:'cylindrical_sleeve',name:'Calibration · Developable cylinder',industry:'Verification',summary:'Faceted 100 mm diameter × 100 mm high sleeve with one open axial seam.',defaultMaterialId:'leather_auto',pieceNames:{piece_1:'Axially seamed sleeve'}},
  {
    id: 'automotive_seat',
    name: 'Automotive Sport Bucket Seat',
    industry: 'Automotive Seating',
    summary: 'Compound doubly-curved seat backrest with sculpted lateral bolsters, lumbar contour, and integrated headrest.',
    defaultMaterialId: 'leather_auto',
    pieceNames: {
      piece_1: 'Center Perforated Insert',
      piece_2: 'Left Lateral Bolster',
      piece_3: 'Right Lateral Bolster',
      piece_4: 'Headrest Face Panel',
      piece_5: 'Lower Lumbar Skirt'
    }
  },
  {
    id: 'aerospace_radome',
    name: 'Aerospace Composite Nose Radome',
    industry: 'Aerospace & Defense',
    summary: 'Synclastic ogive nose cone fairing segmented into four radial prepreg gores and an avionics tip cap.',
    defaultMaterialId: 'carbon_prepreg',
    pieceNames: {
      piece_1: 'Apex Nose Cap',
      piece_2: 'Dorsal Gore Panel',
      piece_3: 'Starboard Gore Panel',
      piece_4: 'Ventral Gore Panel',
      piece_5: 'Port Gore Panel'
    }
  },
  {
    id: 'marine_rib',
    name: 'Marine RIB Inflatable Bow Collar',
    industry: 'Marine & Inflatables',
    summary: 'Curved tubular sponson assembly transitioning into an elevated hydrodynamic bow cone.',
    defaultMaterialId: 'marine_hypalon',
    pieceNames: {
      piece_1: 'Upper Deck Strake',
      piece_2: 'Port Hull Tube',
      piece_3: 'Starboard Hull Tube',
      piece_4: 'Elevated Bow Cone'
    }
  },
  {
    id: 'footwear_last',
    name: 'Ergonomic Athletic Footwear Last',
    industry: 'Footwear & Goods',
    summary: 'Asymmetric 3D shoe upper shell divided into vamp, medial quarter, lateral quarter, and heel counter.',
    defaultMaterialId: 'cordura_1000d',
    pieceNames: {
      piece_1: 'Forefoot Vamp',
      piece_2: 'Lateral Quarter Panel',
      piece_3: 'Medial Quarter Panel',
      piece_4: 'Rear Heel Counter'
    }
  },
  {
    id: 'apparel_bodice',
    name: 'Tailored Compression Torso Shell',
    industry: 'Technical Apparel',
    summary: 'Anatomical torso shell with chest, waist taper, and shoulder slope segmented into tailored pattern blocks.',
    defaultMaterialId: 'neoprene_stretch',
    pieceNames: {
      piece_1: 'Front Sternum Panel',
      piece_2: 'Left Side Bodice',
      piece_3: 'Right Side Bodice',
      piece_4: 'Upper Yoke Collar'
    }
  },
  {
    id: 'tensile_canopy',
    name: 'Architectural Hyperbolic Saddle Canopy',
    industry: 'Tensile Architecture',
    summary: 'Anticlastic negative-Gaussian-curvature tensioned membrane segmented into four structural fabric gores.',
    defaultMaterialId: 'marine_hypalon',
    pieceNames: {
      piece_1: 'North Tensile Gore',
      piece_2: 'East Tensile Gore',
      piece_3: 'South Tensile Gore',
      piece_4: 'West Tensile Gore'
    }
  }
];

function sub3(a: Vec3, b: Vec3): Vec3 {
  return { x: a.x - b.x, y: a.y - b.y, z: a.z - b.z };
}

function cross3(a: Vec3, b: Vec3): Vec3 {
  return {
    x: a.y * b.z - a.z * b.y,
    y: a.z * b.x - a.x * b.z,
    z: a.x * b.y - a.y * b.x
  };
}

function len3(v: Vec3): number {
  return Math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
}

function norm3(v: Vec3): Vec3 {
  const l = len3(v);
  if (l < 1e-9) return { x: 0, y: 0, z: 1 };
  return { x: v.x / l, y: v.y / l, z: v.z / l };
}

function angleBetween(a: Vec3, b: Vec3): number {
  const la = len3(a);
  const lb = len3(b);
  if (la < 1e-9 || lb < 1e-9) return 0;
  const cos = Math.max(-1, Math.min(1, (a.x * b.x + a.y * b.y + a.z * b.z) / (la * lb)));
  return Math.acos(cos);
}

export function computeMeshGeometryData(
  name: string,
  templateId: string,
  vertices: Vec3[],
  rawTris: { v0: number; v1: number; v2: number; pieceId: string }[]
): SurfaceMesh {
  const triangles: MeshTriangle[] = separateTriangleIslands(rawTris).map((t, idx) => {
    const p0 = vertices[t.v0];
    const p1 = vertices[t.v1];
    const p2 = vertices[t.v2];
    const e1 = sub3(p1, p0);
    const e2 = sub3(p2, p0);
    const cr = cross3(e1, e2);
    const area3D = Math.max(1e-12, 0.5 * len3(cr));
    const normal = norm3(cr);
    return {
      id: idx,
      v0: t.v0,
      v1: t.v1,
      v2: t.v2,
      pieceId: t.pieceId,
      normal,
      area3D
    };
  });

  // Compute discrete Gaussian curvature per vertex (normalized to [-1, 1] for inspection)
  const angleSum = new Float64Array(vertices.length);
  const areaSum = new Float64Array(vertices.length);
  const isBoundary = new Uint8Array(vertices.length);

  // Detect boundary edges
  const edgeCounts = new Map<string, number>();
  for (const t of triangles) {
    const edges = [
      [Math.min(t.v0, t.v1), Math.max(t.v0, t.v1)],
      [Math.min(t.v1, t.v2), Math.max(t.v1, t.v2)],
      [Math.min(t.v2, t.v0), Math.max(t.v2, t.v0)]
    ];
    for (const [a, b] of edges) {
      const k = `${a}_${b}`;
      edgeCounts.set(k, (edgeCounts.get(k) || 0) + 1);
    }
  }
  for (const [k, count] of edgeCounts.entries()) {
    if (count === 1) {
      const [a, b] = k.split('_').map(Number);
      isBoundary[a] = 1;
      isBoundary[b] = 1;
    }
  }

  for (const t of triangles) {
    const p0 = vertices[t.v0];
    const p1 = vertices[t.v1];
    const p2 = vertices[t.v2];

    const a0 = angleBetween(sub3(p1, p0), sub3(p2, p0));
    const a1 = angleBetween(sub3(p0, p1), sub3(p2, p1));
    const a2 = Math.max(0, Math.PI - a0 - a1);

    angleSum[t.v0] += a0;
    angleSum[t.v1] += a1;
    angleSum[t.v2] += a2;

    const thirdArea = t.area3D / 3;
    areaSum[t.v0] += thirdArea;
    areaSum[t.v1] += thirdArea;
    areaSum[t.v2] += thirdArea;
  }

  const vertexCurvature: number[] = new Array(vertices.length).fill(0);
  for (let i = 0; i < vertices.length; i++) {
    if (areaSum[i] > 1e-5) {
      const targetAngle = isBoundary[i] ? Math.PI : 2 * Math.PI;
      const deficit = targetAngle - angleSum[i];
      // Scale to readable range
      vertexCurvature[i] = Math.max(-1, Math.min(1, deficit * 2.4));
    }
  }

  // Compute bounding box
  const min = { x: Infinity, y: Infinity, z: Infinity };
  const max = { x: -Infinity, y: -Infinity, z: -Infinity };
  for (const v of vertices) {
    if (v.x < min.x) min.x = v.x;
    if (v.y < min.y) min.y = v.y;
    if (v.z < min.z) min.z = v.z;
    if (v.x > max.x) max.x = v.x;
    if (v.y > max.y) max.y = v.y;
    if (v.z > max.z) max.z = v.z;
  }

  return {
    name,
    templateId,
    vertices,
    triangles,
    vertexCurvature,
    boundingBox: {
      min,
      max,
      size: {
        x: Math.max(1, max.x - min.x),
        y: Math.max(1, max.y - min.y),
        z: Math.max(1, max.z - min.z)
      }
    }
  };
}

export function generateParametricMesh(
  templateId: string,
  config: ParametricConfig
): SurfaceMesh {
  const resMultiplier = config.resolution === 'high' ? 1.5 : 1.0;
  const nx = Math.round(20 * resMultiplier);
  const ny = Math.round(24 * resMultiplier);
  const cBoost = config.curvatureBoost;

  const templateMeta = MODEL_TEMPLATES.find((t) => t.id === templateId) || MODEL_TEMPLATES[0];
  const vertices: Vec3[] = [];
  const rawTris: { v0: number; v1: number; v2: number; pieceId: string }[] = [];

  if(templateId==='calibration_sheet'||templateId==='cylindrical_sleeve') {
    if(templateId==='calibration_sheet') {
      vertices.push({x:0,y:0,z:0},{x:100*config.scaleX,y:0,z:0},{x:100*config.scaleX,y:50*config.scaleY,z:0},{x:0,y:50*config.scaleY,z:0});
      rawTris.push({v0:0,v1:1,v2:2,pieceId:'piece_1'},{v0:0,v1:2,v2:3,pieceId:'piece_1'});
    } else {
      const n=config.resolution==='high'?80:40;
      for(let i=0;i<=n;i++){const a=i/n*Math.PI*2;for(const y of [0,100*config.scaleY])vertices.push({x:50*Math.cos(a)*config.scaleX,y,z:50*Math.sin(a)*config.scaleZ});}
      for(let i=0;i<n;i++){const a=i*2;rawTris.push({v0:a,v1:a+2,v2:a+3,pieceId:'piece_1'},{v0:a,v1:a+3,v2:a+1,pieceId:'piece_1'});}
    }
  } else if (templateId === 'automotive_seat') {
    // Parametric sport bucket seat backrest & bolster surface (in mm, ~520mm wide, ~740mm tall)
    for (let j = 0; j <= ny; j++) {
      const v = j / ny; // 0 (bottom) to 1 (top headrest)
      // Width narrows near shoulders, widens at bolsters, tapers at headrest
      const headrestNarrow = v > 0.72 ? 1 - 0.38 * Math.pow((v - 0.72) / 0.28, 1.2) : 1 + 0.08 * Math.sin(v * Math.PI);
      const halfWidth = 260 * headrestNarrow * config.scaleX;

      for (let i = 0; i <= nx; i++) {
        const u = (i / nx) * 2 - 1; // -1 (left) to +1 (right)
        const x = u * halfWidth;
        const y = (v - 0.5) * 720 * config.scaleY;

        // Bolster wings curve forward strongly on left/right sides (|u| > 0.45)
        const bolsterFactor = Math.pow(Math.max(0, Math.abs(u) - 0.35) / 0.65, 1.75);
        const bolsterHeight = v < 0.72 ? Math.sin(v * Math.PI * 0.95) : 0.25;
        const lumbarCurve = Math.sin(v * Math.PI * 1.3) * 38 * cBoost;
        const centerDish = -Math.cos(u * Math.PI * 0.5) * 28 * cBoost;
        const z = (bolsterFactor * bolsterHeight * 135 * cBoost + lumbarCurve + centerDish) * config.scaleZ;

        vertices.push({ x, y, z });
      }
    }

    for (let j = 0; j < ny; j++) {
      const vMid = (j + 0.5) / ny;
      for (let i = 0; i < nx; i++) {
        const uMid = ((i + 0.5) / nx) * 2 - 1;
        let pieceId = 'piece_1'; // Center insert
        if (vMid > 0.73) {
          pieceId = 'piece_4'; // Headrest Face Panel
        } else if (uMid < -0.42) {
          pieceId = 'piece_2'; // Left Lateral Bolster
        } else if (uMid > 0.42) {
          pieceId = 'piece_3'; // Right Lateral Bolster
        } else if (vMid < 0.18) {
          pieceId = 'piece_5'; // Lower Lumbar Skirt
        }

        const idx0 = j * (nx + 1) + i;
        const idx1 = idx0 + 1;
        const idx2 = (j + 1) * (nx + 1) + i;
        const idx3 = idx2 + 1;

        rawTris.push({ v0: idx0, v1: idx1, v2: idx3, pieceId });
        rawTris.push({ v0: idx0, v1: idx3, v2: idx2, pieceId });
      }
    }
  } else if (templateId === 'aerospace_radome') {
    // Doubly-curved ogive nose cone fairing (polar grid)
    const rings = Math.round(18 * resMultiplier);
    const sectors = Math.round(28 * resMultiplier);
    for (let r = 0; r <= rings; r++) {
      const v = r / rings; // 0 near apex, 1 at base skirt
      const radius = (22 + 260 * Math.pow(v, 0.68 * cBoost)) * config.scaleX;
      const y = (320 - v * 640) * config.scaleY;

      for (let s = 0; s <= sectors; s++) {
        const theta = (s / sectors) * Math.PI * 2;
        const x = radius * Math.cos(theta);
        const z = radius * Math.sin(theta) * config.scaleZ;
        vertices.push({ x, y, z });
      }
    }

    for (let r = 0; r < rings; r++) {
      const vMid = (r + 0.5) / rings;
      for (let s = 0; s < sectors; s++) {
        const angle = ((s + 0.5) / sectors) * 360;
        let pieceId = 'piece_1';
        if (vMid >= 0.24) {
          if (angle < 90) pieceId = 'piece_2';
          else if (angle < 180) pieceId = 'piece_3';
          else if (angle < 270) pieceId = 'piece_4';
          else pieceId = 'piece_5';
        }

        const idx0 = r * (sectors + 1) + s;
        const idx1 = idx0 + 1;
        const idx2 = (r + 1) * (sectors + 1) + s;
        const idx3 = idx2 + 1;

        rawTris.push({ v0: idx0, v1: idx2, v2: idx3, pieceId });
        rawTris.push({ v0: idx0, v1: idx3, v2: idx1, pieceId });
      }
    }
  } else if (templateId === 'marine_rib') {
    // Curved U-shaped inflatable RIB bow collar
    for (let j = 0; j <= ny; j++) {
      const v = j / ny; // along the U-curve from Port stern to Bow to Starboard stern
      const archAngle = (v - 0.5) * Math.PI * 0.92;
      const spineX = Math.sin(archAngle) * 340 * config.scaleX;
      const spineY = (Math.cos(archAngle) * 360 - 150) * config.scaleY;
      const bowLiftZ = Math.exp(-Math.pow((v - 0.5) * 3.5, 2)) * 95 * cBoost;
      const tubeRadius = (95 - 24 * Math.exp(-Math.pow((v - 0.5) * 3, 2))) * config.scaleZ;

      const radialX = Math.sin(archAngle);
      const radialY = Math.cos(archAngle);

      for (let i = 0; i <= nx; i++) {
        const u = (i / nx) * Math.PI * 1.45 - Math.PI * 0.725;
        const localR = tubeRadius * Math.cos(u);
        const localZ = tubeRadius * Math.sin(u) * cBoost;

        const x = spineX + radialX * localR;
        const y = spineY + radialY * localR;
        const z = bowLiftZ + localZ;
        vertices.push({ x, y, z });
      }
    }

    for (let j = 0; j < ny; j++) {
      const vMid = (j + 0.5) / ny;
      for (let i = 0; i < nx; i++) {
        const uMid = (i + 0.5) / nx;
        let pieceId = 'piece_1';
        if (vMid > 0.36 && vMid < 0.64) {
          pieceId = 'piece_4'; // Elevated Bow Cone
        } else if (uMid > 0.35 && uMid < 0.65) {
          pieceId = 'piece_1'; // Upper Deck Strake
        } else if (vMid <= 0.36) {
          pieceId = 'piece_2'; // Port Hull Tube
        } else {
          pieceId = 'piece_3'; // Starboard Hull Tube
        }

        const idx0 = j * (nx + 1) + i;
        const idx1 = idx0 + 1;
        const idx2 = (j + 1) * (nx + 1) + i;
        const idx3 = idx2 + 1;

        rawTris.push({ v0: idx0, v1: idx1, v2: idx3, pieceId });
        rawTris.push({ v0: idx0, v1: idx3, v2: idx2, pieceId });
      }
    }
  } else if (templateId === 'footwear_last') {
    // 3D Ergonomic Shoe Upper shell (from heel v=0 to toe v=1)
    for (let j = 0; j <= ny; j++) {
      const v = j / ny; // 0 = heel, 1 = toe
      const lengthY = (v - 0.5) * 310 * config.scaleY;
      // Foot width profile + medial/lateral asymmetry
      const widthProfile = 52 * Math.sin(Math.pow(v, 0.7) * Math.PI * 0.92) + 28 * (1 - v * 0.6);
      // Instep arch height profile
      const instepHeight = (v < 0.55 ? 88 - v * 45 : 63 * Math.cos(((v - 0.55) / 0.45) * Math.PI * 0.46)) * cBoost;

      for (let i = 0; i <= nx; i++) {
        const u = (i / nx) * 2 - 1; // -1 lateral sole edge, 0 top ridge, +1 medial sole edge
        const theta = u * Math.PI * 0.52;
        const asymmetry = u > 0 ? 1.08 : 0.94;
        const x = Math.sin(theta) * widthProfile * asymmetry * config.scaleX;
        const z = Math.cos(theta) * instepHeight * config.scaleZ;
        vertices.push({ x, y: lengthY, z });
      }
    }

    for (let j = 0; j < ny; j++) {
      const vMid = (j + 0.5) / ny;
      for (let i = 0; i < nx; i++) {
        const uMid = ((i + 0.5) / nx) * 2 - 1;
        let pieceId = 'piece_1'; // Forefoot Vamp
        if (vMid < 0.24) {
          pieceId = 'piece_4'; // Rear Heel Counter
        } else if (vMid < 0.66) {
          if (uMid < -0.18) pieceId = 'piece_2'; // Lateral Quarter
          else if (uMid > 0.18) pieceId = 'piece_3'; // Medial Quarter
          else pieceId = 'piece_1';
        }

        const idx0 = j * (nx + 1) + i;
        const idx1 = idx0 + 1;
        const idx2 = (j + 1) * (nx + 1) + i;
        const idx3 = idx2 + 1;

        rawTris.push({ v0: idx0, v1: idx1, v2: idx3, pieceId });
        rawTris.push({ v0: idx0, v1: idx3, v2: idx2, pieceId });
      }
    }
  } else if (templateId === 'apparel_bodice') {
    // Anatomical Torso Front/Side shell
    for (let j = 0; j <= ny; j++) {
      const v = j / ny; // 0 = hip, 0.4 = waist taper, 0.78 = chest, 1 = shoulder collar
      const waistPinch = 1 - 0.22 * Math.sin(v * Math.PI) * cBoost;
      const chestExpand = v > 0.5 ? Math.sin(((v - 0.4) / 0.6) * Math.PI) * 36 * cBoost : 0;
      const halfWidth = (210 * waistPinch + chestExpand * 0.4) * config.scaleX;
      const y = (v - 0.5) * 580 * config.scaleY;

      for (let i = 0; i <= nx; i++) {
        const u = (i / nx) * 2 - 1; // -1 left side seam to +1 right side seam
        const angle = u * Math.PI * 0.48;
        const x = Math.sin(angle) * halfWidth;
        const z = (Math.cos(angle) * (115 * waistPinch + chestExpand)) * config.scaleZ;
        vertices.push({ x, y, z });
      }
    }

    for (let j = 0; j < ny; j++) {
      const vMid = (j + 0.5) / ny;
      for (let i = 0; i < nx; i++) {
        const uMid = ((i + 0.5) / nx) * 2 - 1;
        let pieceId = 'piece_1';
        if (vMid > 0.76) {
          pieceId = 'piece_4'; // Upper Yoke Collar
        } else if (uMid < -0.36) {
          pieceId = 'piece_2'; // Left Side Bodice
        } else if (uMid > 0.36) {
          pieceId = 'piece_3'; // Right Side Bodice
        }

        const idx0 = j * (nx + 1) + i;
        const idx1 = idx0 + 1;
        const idx2 = (j + 1) * (nx + 1) + i;
        const idx3 = idx2 + 1;

        rawTris.push({ v0: idx0, v1: idx1, v2: idx3, pieceId });
        rawTris.push({ v0: idx0, v1: idx3, v2: idx2, pieceId });
      }
    }
  } else {
    // tensile_canopy: Hyperbolic paraboloid saddle z = (x^2 - y^2)
    for (let j = 0; j <= ny; j++) {
      const v = (j / ny) * 2 - 1;
      for (let i = 0; i <= nx; i++) {
        const u = (i / nx) * 2 - 1;
        const x = u * 340 * config.scaleX;
        const y = v * 340 * config.scaleY;
        const z = (u * u - v * v) * 145 * cBoost * config.scaleZ;
        vertices.push({ x, y, z });
      }
    }

    for (let j = 0; j < ny; j++) {
      const vMid = ((j + 0.5) / ny) * 2 - 1;
      for (let i = 0; i < nx; i++) {
        const uMid = ((i + 0.5) / nx) * 2 - 1;
        let pieceId = 'piece_1';
        if (Math.abs(uMid) > Math.abs(vMid)) {
          pieceId = uMid > 0 ? 'piece_2' : 'piece_4';
        } else {
          pieceId = vMid > 0 ? 'piece_1' : 'piece_3';
        }

        const idx0 = j * (nx + 1) + i;
        const idx1 = idx0 + 1;
        const idx2 = (j + 1) * (nx + 1) + i;
        const idx3 = idx2 + 1;

        rawTris.push({ v0: idx0, v1: idx1, v2: idx3, pieceId });
        rawTris.push({ v0: idx0, v1: idx3, v2: idx2, pieceId });
      }
    }
  }

  return computeMeshGeometryData(templateMeta.name, templateId, vertices, rawTris);
}

/**
 * Industrial Mesh Repatterning & Auto-Seam Segmentation Engine:
 * Partitions any 3D mesh into clean, developable pattern pieces.
 */
export function repatternMesh(
  mesh: SurfaceMesh,
  mode: RepatternMode,
  options?: { targetPanelCount?: number; creaseAngleDeg?: number }
): SurfaceMesh {
  const triangles = mesh.triangles;
  const vertices = mesh.vertices;
  const nTris = triangles.length;
  if (nTris === 0) return mesh;

  const targetCount = Math.min(8, Math.max(2, options?.targetPanelCount || 4));
  const creaseDeg = Math.min(80, Math.max(15, options?.creaseAngleDeg || 38));
  const cosCreaseThreshold = Math.cos((creaseDeg * Math.PI) / 180);

  // Compute triangle centroids
  const triCentroids: Vec3[] = triangles.map((t) => {
    const p0 = vertices[t.v0];
    const p1 = vertices[t.v1];
    const p2 = vertices[t.v2];
    return {
      x: (p0.x + p1.x + p2.x) / 3,
      y: (p0.y + p1.y + p2.y) / 3,
      z: (p0.z + p1.z + p2.z) / 3
    };
  });

  // Build edge-to-triangle adjacency map
  const edgeToTris = new Map<string, number[]>();
  for (let i = 0; i < nTris; i++) {
    const t = triangles[i];
    const e0 = t.v0 < t.v1 ? `${t.v0}_${t.v1}` : `${t.v1}_${t.v0}`;
    const e1 = t.v1 < t.v2 ? `${t.v1}_${t.v2}` : `${t.v2}_${t.v1}`;
    const e2 = t.v2 < t.v0 ? `${t.v2}_${t.v0}` : `${t.v0}_${t.v2}`;
    for (const e of [e0, e1, e2]) {
      if (!edgeToTris.has(e)) edgeToTris.set(e, []);
      edgeToTris.get(e)!.push(i);
    }
  }

  // Build dual-graph neighbor list (edges with dihedral angle <= creaseDeg)
  const nonCreaseNeighbors: number[][] = Array.from({ length: nTris }, () => []);
  const allNeighbors: number[][] = Array.from({ length: nTris }, () => []);

  for (const [, triList] of edgeToTris.entries()) {
    if (triList.length === 2) {
      const [tA, tB] = triList;
      allNeighbors[tA].push(tB);
      allNeighbors[tB].push(tA);

      const nA = triangles[tA].normal;
      const nB = triangles[tB].normal;
      const dot = nA.x * nB.x + nA.y * nB.y + nA.z * nB.z;
      if (dot >= cosCreaseThreshold) {
        nonCreaseNeighbors[tA].push(tB);
        nonCreaseNeighbors[tB].push(tA);
      }
    }
  }

  const pieceAssignments = new Array<string>(nTris).fill('piece_1');

  if (mode === 'feature_crease') {
    // Mode 1: Sharp Crease Seam Partitioning
    const visited = new Uint8Array(nTris);
    const rawComponents: number[][] = [];

    for (let i = 0; i < nTris; i++) {
      if (visited[i]) continue;
      const comp: number[] = [];
      const queue: number[] = [i];
      visited[i] = 1;

      while (queue.length > 0) {
        const curr = queue.pop()!;
        comp.push(curr);
        for (const nbr of nonCreaseNeighbors[curr]) {
          if (!visited[nbr]) {
            visited[nbr] = 1;
            queue.push(nbr);
          }
        }
      }
      rawComponents.push(comp);
    }

    // Sort components by triangle count descending
    rawComponents.sort((a, b) => b.length - a.length);

    // Merge tiny slivers (< 20 triangles or < 1.5% of total) into their largest neighbor
    const minCompSize = Math.max(15, Math.floor(nTris * 0.015));
    const finalComponents: number[][] = [];
    const compIndexMap = new Int32Array(nTris).fill(-1);

    for (let cIdx = 0; cIdx < rawComponents.length; cIdx++) {
      const comp = rawComponents[cIdx];
      if (comp.length >= minCompSize || cIdx < targetCount) {
        finalComponents.push(comp);
        const newCIdx = finalComponents.length - 1;
        for (const tId of comp) compIndexMap[tId] = newCIdx;
      }
    }

    // Reassign orphan slivers
    for (const comp of rawComponents) {
      if (compIndexMap[comp[0]] === -1) {
        // Find best neighbor component
        const neighborCount = new Map<number, number>();
        for (const tId of comp) {
          for (const nbr of allNeighbors[tId]) {
            const nComp = compIndexMap[nbr];
            if (nComp !== -1) {
              neighborCount.set(nComp, (neighborCount.get(nComp) || 0) + 1);
            }
          }
        }
        let bestComp = 0;
        let maxLinks = -1;
        for (const [targetC, cnt] of neighborCount.entries()) {
          if (cnt > maxLinks) {
            maxLinks = cnt;
            bestComp = targetC;
          }
        }
        for (const tId of comp) {
          compIndexMap[tId] = bestComp;
          finalComponents[bestComp].push(tId);
        }
      }
    }

    // Assign final components to piece palette
    for (let cIdx = 0; cIdx < finalComponents.length; cIdx++) {
      const pieceId = PIECE_PALETTE[cIdx % PIECE_PALETTE.length].id;
      for (const tId of finalComponents[cIdx]) {
        pieceAssignments[tId] = pieceId;
      }
    }
  } else if (mode === 'normal_kmeans') {
    // Mode 2: Surface Normal K-Means & Contiguous Region Growing
    // Initialize K directional cluster centroids spread across 3D orientations
    const centroids: Vec3[] = [];
    const angleStep = (Math.PI * 2) / targetCount;
    for (let k = 0; k < targetCount; k++) {
      const theta = k * angleStep;
      centroids.push({
        x: Math.cos(theta),
        y: (k % 2 === 0 ? 0.4 : -0.4),
        z: Math.sin(theta)
      });
    }

    const clusterAssignments = new Int32Array(nTris);

    // K-Means iterations
    for (let iter = 0; iter < 8; iter++) {
      // 1. Assign each triangle to closest centroid
      for (let i = 0; i < nTris; i++) {
        const norm = triangles[i].normal;
        let bestDist = -Infinity;
        let bestK = 0;
        for (let k = 0; k < targetCount; k++) {
          const c = centroids[k];
          const dot = norm.x * c.x + norm.y * c.y + norm.z * c.z;
          if (dot > bestDist) {
            bestDist = dot;
            bestK = k;
          }
        }
        clusterAssignments[i] = bestK;
      }

      // 2. Update centroids
      const sums: Vec3[] = Array.from({ length: targetCount }, () => ({ x: 0, y: 0, z: 0 }));
      const counts = new Int32Array(targetCount);
      for (let i = 0; i < nTris; i++) {
        const k = clusterAssignments[i];
        const norm = triangles[i].normal;
        sums[k].x += norm.x;
        sums[k].y += norm.y;
        sums[k].z += norm.z;
        counts[k]++;
      }
      for (let k = 0; k < targetCount; k++) {
        if (counts[k] > 0) {
          centroids[k] = norm3(sums[k]);
        }
      }
    }

    // Enforce spatial contiguity: Merge disconnected islands into adjacent neighbors
    const visited = new Uint8Array(nTris);
    const contiguousComponents: { k: number; tris: number[] }[] = [];

    for (let i = 0; i < nTris; i++) {
      if (visited[i]) continue;
      const kVal = clusterAssignments[i];
      const comp: number[] = [];
      const queue: number[] = [i];
      visited[i] = 1;

      while (queue.length > 0) {
        const curr = queue.pop()!;
        comp.push(curr);
        for (const nbr of allNeighbors[curr]) {
          if (!visited[nbr] && clusterAssignments[nbr] === kVal) {
            visited[nbr] = 1;
            queue.push(nbr);
          }
        }
      }
      contiguousComponents.push({ k: kVal, tris: comp });
    }

    contiguousComponents.sort((a, b) => b.tris.length - a.tris.length);

    // Keep top K largest contiguous components as the primary pieces
    const primaryComponents = contiguousComponents.slice(0, targetCount);
    const assignedPiece = new Int32Array(nTris).fill(-1);

    for (let pIdx = 0; pIdx < primaryComponents.length; pIdx++) {
      for (const tId of primaryComponents[pIdx].tris) {
        assignedPiece[tId] = pIdx;
      }
    }

    // Flood fill remaining small components to their touching primary piece
    for (let c = targetCount; c < contiguousComponents.length; c++) {
      const comp = contiguousComponents[c].tris;
      const linkCounts = new Map<number, number>();
      for (const tId of comp) {
        for (const nbr of allNeighbors[tId]) {
          const p = assignedPiece[nbr];
          if (p !== -1) linkCounts.set(p, (linkCounts.get(p) || 0) + 1);
        }
      }
      let bestP = 0;
      let maxLinks = -1;
      for (const [p, cnt] of linkCounts.entries()) {
        if (cnt > maxLinks) {
          maxLinks = cnt;
          bestP = p;
        }
      }
      for (const tId of comp) {
        assignedPiece[tId] = bestP;
      }
    }

    for (let i = 0; i < nTris; i++) {
      const pIdx = Math.max(0, assignedPiece[i]);
      pieceAssignments[i] = PIECE_PALETTE[pIdx % PIECE_PALETTE.length].id;
    }
  } else {
    // Mode 3: Axis Slices / Developable Gores
    // Find longest bounding box axis
    const size = mesh.boundingBox.size;
    let axisKey: 'x' | 'y' | 'z' = 'y';
    if (size.x >= size.y && size.x >= size.z) axisKey = 'x';
    else if (size.z >= size.x && size.z >= size.y) axisKey = 'z';

    const minVal = mesh.boundingBox.min[axisKey];
    const maxVal = mesh.boundingBox.max[axisKey];
    const span = Math.max(1e-4, maxVal - minVal);

    for (let i = 0; i < nTris; i++) {
      const coord = triCentroids[i][axisKey];
      const normPos = Math.max(0, Math.min(0.999, (coord - minVal) / span));
      const sliceIdx = Math.floor(normPos * targetCount);
      pieceAssignments[i] = PIECE_PALETTE[sliceIdx % PIECE_PALETTE.length].id;
    }
  }

  const updatedTriangles = triangles.map((t, idx) => ({
    ...t,
    pieceId: pieceAssignments[idx]
  }));

  return {
    ...mesh,
    triangles: separateTriangleIslands(updatedTriangles)
  };
}

/**
 * Robust High-Precision Custom 3D Mesh Parser (.OBJ and ASCII / Binary .STL)
 * Handles large models with scale normalization, adaptive deduplication, and auto-repatterning.
 */
export function parseCustom3DFile(fileName: string, buffer: ArrayBuffer): SurfaceMesh {
  const lower = fileName.toLowerCase();
  if (!/\.(obj|stl)$/.test(lower)) throw new Error('Choose an OBJ or STL mesh.');
  if (buffer.byteLength > 25 * 1024 * 1024) throw new Error('Mesh exceeds the 25 MB import limit. Simplify it before importing.');
  let vertices: Vec3[] = [];
  let rawFaces: { v0: number; v1: number; v2: number; group?: string }[] = [];

  if (lower.endsWith('.obj')) {
    const text = new TextDecoder().decode(buffer);
    const lines = text.split(/\r?\n/);
    let currentGroup = 'piece_1';
    const groupMap = new Map<string, string>();
    let groupCounter = 0;

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) continue;
      const parts = trimmed.split(/\s+/);
      if (parts[0] === 'v' && parts.length >= 4) {
        vertices.push({
          x: Number(parts[1]),
          y: Number(parts[2]),
          z: Number(parts[3])
        });
      } else if (parts[0] === 'g' || parts[0] === 'o' || parts[0] === 'usemtl') {
        const gName = parts.slice(1).join('_') || 'default';
        if (!groupMap.has(gName)) {
          const pieceSlot = `piece_${groupCounter + 1}`;
          groupMap.set(gName, pieceSlot);
          groupCounter++;
        }
        currentGroup = groupMap.get(gName)!;
      } else if (parts[0] === 'f' && parts.length >= 4) {
        const idxs = parts.slice(1).map((tok) => {
          const vIdx = parseInt(tok.split('/')[0], 10);
          return vIdx > 0 ? vIdx - 1 : vertices.length + vIdx;
        });
        for (let k = 1; k < idxs.length - 1; k++) {
          if (
            idxs[0] >= 0 &&
            idxs[k] >= 0 &&
            idxs[k + 1] >= 0 &&
            idxs[0] < vertices.length &&
            idxs[k] < vertices.length &&
            idxs[k + 1] < vertices.length
          ) {
            rawFaces.push({ v0: idxs[0], v1: idxs[k], v2: idxs[k + 1], group: currentGroup });
          }
        }
      }
    }
  } else {
    // Robust STL Parser (ASCII & Binary)
    const textPreview = new TextDecoder().decode(buffer.slice(0, 256));
    const binaryCount = buffer.byteLength >= 84 ? new DataView(buffer).getUint32(80, true) : 0;
    const binaryExact = buffer.byteLength === 84 + binaryCount * 50;
    const isAscii = !binaryExact && textPreview.trim().startsWith('solid');

    // First pass: Read raw coordinate triplets
    const rawTriangles: { p0: Vec3; p1: Vec3; p2: Vec3 }[] = [];

    if (isAscii) {
      const text = new TextDecoder().decode(buffer);
      const vertexRegex = /vertex\s+([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)\s+([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)\s+([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)/g;
      let match: RegExpExecArray | null;
      const curTriPts: Vec3[] = [];
      while ((match = vertexRegex.exec(text)) !== null) {
        curTriPts.push({
          x: parseFloat(match[1]),
          y: parseFloat(match[2]),
          z: parseFloat(match[3])
        });
        if (curTriPts.length === 3) {
          rawTriangles.push({ p0: curTriPts[0], p1: curTriPts[1], p2: curTriPts[2] });
          curTriPts.length = 0;
        }
      }
      if(curTriPts.length || (text.match(/\bvertex\b/g)||[]).length !== rawTriangles.length*3) throw new Error('Incomplete or invalid ASCII STL vertices.');
    } else if (buffer.byteLength >= 84) {
      // Binary STL
      const view = new DataView(buffer);
      const totalTrisHeader = view.getUint32(80, true);
      if (84 + totalTrisHeader * 50 > buffer.byteLength) throw new Error('Truncated binary STL.');
      if (totalTrisHeader > 28000) throw new Error('Mesh exceeds 28,000 triangles. Simplify it; triangles are never silently discarded.');
      let offset = 84;
      for (let i = 0; i < totalTrisHeader && offset + 50 <= buffer.byteLength; i++) {
        {
          const p0 = {
            x: view.getFloat32(offset + 12, true),
            y: view.getFloat32(offset + 16, true),
            z: view.getFloat32(offset + 20, true)
          };
          const p1 = {
            x: view.getFloat32(offset + 24, true),
            y: view.getFloat32(offset + 28, true),
            z: view.getFloat32(offset + 32, true)
          };
          const p2 = {
            x: view.getFloat32(offset + 36, true),
            y: view.getFloat32(offset + 40, true),
            z: view.getFloat32(offset + 44, true)
          };
          rawTriangles.push({ p0, p1, p2 });
        }
        offset += 50;
      }
    }

    if (rawTriangles.length < 1) {
      throw new Error('Could not parse valid 3D facets from the STL file.');
    }

    // Compute bounding box and normalizer before deduplication
    let minX = Infinity, minY = Infinity, minZ = Infinity;
    let maxX = -Infinity, maxY = -Infinity, maxZ = -Infinity;
    for (const tri of rawTriangles) {
      for (const p of [tri.p0, tri.p1, tri.p2]) {
        if (p.x < minX) minX = p.x;
        if (p.y < minY) minY = p.y;
        if (p.z < minZ) minZ = p.z;
        if (p.x > maxX) maxX = p.x;
        if (p.y > maxY) maxY = p.y;
        if (p.z > maxZ) maxZ = p.z;
      }
    }
    const cx = (minX + maxX) * 0.5;
    const cy = (minY + maxY) * 0.5;
    const cz = (minZ + maxZ) * 0.5;
    const maxSpan = Math.max(1e-4, maxX - minX, maxY - minY, maxZ - minZ);
    // Standardize to ~550mm engineering workspace
    const scaleFactor = 1; // Preserve units exactly. Import assumes millimeters.

    // Deduplicate vertices with adaptive 0.25mm welding resolution
    const vertexDedup = new Map<string, number>();
    const weldResolution = Math.max(1e-10, maxSpan * 1e-9);

    const addScaledVertex = (p: Vec3): number => {
      const sx = p.x * scaleFactor;
      const sy = p.y * scaleFactor;
      const sz = p.z * scaleFactor;
      const key = `${Math.round(sx / weldResolution)}_${Math.round(sy / weldResolution)}_${Math.round(sz / weldResolution)}`;
      const existing = vertexDedup.get(key);
      if (existing !== undefined) return existing;
      const idx = vertices.length;
      vertices.push({ x: sx, y: sy, z: sz });
      vertexDedup.set(key, idx);
      return idx;
    };

    for (const tri of rawTriangles) {
      const v0 = addScaledVertex(tri.p0);
      const v1 = addScaledVertex(tri.p1);
      const v2 = addScaledVertex(tri.p2);
      // Avoid degenerate zero-area facets
      if (v0 !== v1 && v1 !== v2 && v2 !== v0) {
        rawFaces.push({ v0, v1, v2 });
      }
    }
  }

  if (vertices.some(v => ![v.x,v.y,v.z].every(Number.isFinite))) throw new Error('Mesh contains invalid coordinates.');
  if (rawFaces.length > 28000) throw new Error('Mesh exceeds 28,000 triangles. Simplify before import.');
  rawFaces = rawFaces.filter(f => f.v0 !== f.v1 && f.v1 !== f.v2 && f.v2 !== f.v0 && len3(cross3(sub3(vertices[f.v1],vertices[f.v0]),sub3(vertices[f.v2],vertices[f.v0]))) > 1e-12);
  if (vertices.length < 3 || rawFaces.length < 1) {
    throw new Error('Could not parse valid 3D triangles from the selected file.');
  }

  // If OBJ had groups, keep them. Otherwise, run automatic intelligent repatterning!
  const distinctGroups = new Set(rawFaces.map((f) => f.group).filter(Boolean));
  const rawTris = rawFaces.map((f) => ({
    v0: f.v0,
    v1: f.v1,
    v2: f.v2,
    pieceId: f.group || 'piece_1'
  }));

  const cleanName = fileName.replace(/\.(obj|stl)$/i, '');
  const baseMesh = computeMeshGeometryData(cleanName, 'custom_upload', vertices, rawTris);

  // If the file already had multiple OBJ groups, return as-is
  if (distinctGroups.size > 1) {
    return baseMesh;
  }

  // Auto-Repattern: Try Sharp Creases first (e.g. 40°). If it's a smooth organic shape, use Normal K-Means (4 panels)
  const creaseRepatterned = repatternMesh(baseMesh, 'feature_crease', { creaseAngleDeg: 40 });
  const distinctCreasePieces = new Set(creaseRepatterned.triangles.map((t) => t.pieceId));

  if (distinctCreasePieces.size >= 2) {
    return creaseRepatterned;
  }

  // Smooth single surface: partition into 4 balanced normal-clustered developable panels
  return repatternMesh(baseMesh, 'normal_kmeans', { targetPanelCount: 4 });
}

