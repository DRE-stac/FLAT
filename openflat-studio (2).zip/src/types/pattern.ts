export interface Vec2 {
  x: number;
  y: number;
}

export interface Vec3 {
  x: number;
  y: number;
  z: number;
}

export interface MeshTriangle {
  id: number;
  v0: number;
  v1: number;
  v2: number;
  pieceId: string;
  normal: Vec3;
  area3D: number; // in mm^2
}

export interface SurfaceMesh {
  name: string;
  templateId: string;
  vertices: Vec3[]; // in millimeters (mm)
  triangles: MeshTriangle[];
  vertexCurvature: number[]; // Gaussian curvature estimate per vertex
  boundingBox: {
    min: Vec3;
    max: Vec3;
    size: Vec3;
  };
}

export interface AlignmentNotch {
  id: string;
  position2D: Vec2;
  normal2D: Vec2;
  matchNumber: number;
  targetPieceId: string;
  edgeIndex: number;
}

export interface FlattenedTriangle {
  triId: number;
  localV0: number;
  localV1: number;
  localV2: number;
  area3D: number;
  area2D: number;
  areaStrainPct: number; // ((area2D - area3D) / area3D) * 100
  maxEdgeStrainPct: number; // signed % stretch (+) or compression (-)
}

export interface PatternPiece {
  id: string;
  name: string;
  color: string;
  triangleIds: number[];
  // Local 3D vertices for this piece
  vertices3D: Vec3[];
  // Global vertex index mapping
  globalVertexIds: number[];
  // Flattened 2D vertices in local piece coordinates (mm)
  vertices2D: Vec2[];
  // Triangles indexing into local vertices
  triangles: FlattenedTriangle[];
  // Ordered outer boundary loop (indices into local vertices)
  boundaryLoop: number[];
  // Ordered 2D points of the net seam boundary
  seamPolygon2D: Vec2[];
  // Outward offset polygon for cutting (with seam allowance in mm)
  cutPolygon2D: Vec2[];
  // Alignment notches along shared seams
  notches: AlignmentNotch[];
  // Placement on the 2D cutting table / fabric roll (mm)
  position: Vec2;
  rotationDeg: number;
  grainlineAngleDeg: number;
  // Piece metrics
  area3DMm2: number;
  area2DMm2: number;
  perimeterMm: number;
  bboxWidthMm: number;
  bboxHeightMm: number;
  meanStrainPct: number;
  maxStretchPct: number;
  maxCompressionPct: number;
}

export interface MaterialSpec {
  id: string;
  name: string;
  category: 'Composite' | 'Leather & Upholstery' | 'Technical Textile' | 'Elastomer';
  thicknessMm: number;
  youngsModulusMPa: number;
  poissonRatio: number;
  shearStiffnessRatio: number; // resists diagonal trellis shear
  maxAllowableStrainPct: number; // threshold before wrinkling/tearing warning
  defaultRollWidthMm: number;
  description: string;
}

export interface ParametricConfig {
  scaleX: number;
  scaleY: number;
  scaleZ: number;
  curvatureBoost: number; // 0.5 to 1.8
  resolution: 'standard' | 'high';
}

export type ShadingMode3D = 'panels' | 'strain' | 'curvature' | 'material';
export type ToolMode3D = 'inspect' | 'paint_piece' | 'split_dart';
export type RepatternMode = 'feature_crease' | 'normal_kmeans' | 'axis_slices';

export interface RepatternConfig {
  mode: RepatternMode;
  targetPanelCount: number; // 2 to 8
  creaseAngleDeg: number;   // 20 to 75
}

export interface SolverSettings {
  stage: 'pre_flatten' | 'optimized';
  iterations: number;
  seamAllowanceMm: number;
  notchCountPerSeam: number;
  rollWidthMm: number;
  piecePaddingMm: number;
}

export interface SolverSummaryMetrics {
  totalArea3DCm2: number;
  totalArea2DCm2: number;
  overallMeanStrainPct: number;
  overallMaxStrainPct: number;
  materialYieldPct: number;
  usedRollLengthMm: number;
  pieceCount: number;
  triangleCount: number;
  vertexCount: number;
}
