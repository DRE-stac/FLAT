import fs from 'node:fs';
import {generateParametricMesh,MODEL_TEMPLATES,MATERIAL_LIBRARY} from '../src/engine/meshGenerators';
import {flattenAndOptimizeMesh} from '../src/engine/flatteningSolver';
import {auditPatterns} from '../src/engine/quality';
const results=[];
for(const template of MODEL_TEMPLATES)for(const resolution of ['standard','high'] as const){
 const mesh=generateParametricMesh(template.id,{scaleX:1,scaleY:1,scaleZ:1,curvatureBoost:1,resolution});const material=MATERIAL_LIBRARY.find(m=>m.id===template.defaultMaterialId)!;
 const settings={stage:'optimized' as const,iterations:45,seamAllowanceMm:10,notchCountPerSeam:2,rollWidthMm:material.defaultRollWidthMm,piecePaddingMm:25};
 const start=performance.now(),r=flattenAndOptimizeMesh(mesh,material,settings),elapsedMs=performance.now()-start;
 const issues=auditPatterns(mesh,r.pieces,material,settings.rollWidthMm);
 results.push({template:template.id,resolution,material:material.id,triangles:mesh.triangles.length,elapsedMs,meanEdgeDistortionPct:r.summary.overallMeanStrainPct,peakEdgeDistortionPct:r.summary.overallMaxStrainPct,areaChangePct:(r.summary.totalArea2DCm2/r.summary.totalArea3DCm2-1)*100,errors:issues.filter(i=>i.severity==='error').length,warnings:issues.filter(i=>i.severity==='warning').length,issues});
}
fs.mkdirSync('qa',{recursive:true});fs.writeFileSync('qa/benchmark.json',JSON.stringify({date:new Date().toISOString(),node:process.version,settings:'45 iterations; default material; 10mm allowance; no physical calibration',results},null,2));console.table(results.map(({issues,...r})=>r));
