# OpenFlat Studio 1.1

A local browser workspace for inspecting 3D surfaces, assigning panels, estimating flattening distortion, laying out patterns and exporting CAD files.

**This release is a hardened engineering prototype. It is not a calibrated textile/composite forming simulator or a certified production pattern system.** The planar and cylindrical verification examples preserve their triangulated metrics to numerical tolerance. Some compound-curved examples fail geometric checks or exceed their material preset limits. Those results are visible, not hidden.

## Use the included build

Install Node.js 22 or newer. On Windows, double-click `Launch-Windows.bat`. On any platform:

```sh
node launch.mjs
```

Open `http://127.0.0.1:8080`. No npm installation, API key or internet access is needed to run the included build. Keep the terminal open. Do not double-click `dist/index.html`: browsers require an HTTP origin for modules and workers.

For GoDaddy/cPanel or another static host, upload **the contents of `dist/`**, including `assets/`, into your destination folder. Relative asset URLs support a subfolder installation. HTTPS is recommended. This package has not been deployed to your domain.

## Workflow

1. Select a template or import OBJ/STL. Coordinates are interpreted as **millimeters**. Dimensions and STL coordinates are preserved; there is no hidden rescaling. Convert meters/inches in your CAD package first. Imports are limited to 25 MB and 28,000 triangles, with at most 256 disconnected panels, and are rejected rather than silently sampled above that limit.
2. Use the two **Calibration** templates to verify units and flattening. The 100 × 50 mm sheet is also a practical print-scale reference. The cylindrical sleeve has an explicit open axial seam.
3. Inspect panels, curvature and edge distortion. Select a material preset. Presets are illustrative: Young's modulus and thickness do not drive the flattening calculation. Poisson/shear values tune geometric relaxation weights.
4. Repattern, paint panel assignments or split a panel. Recheck distortion after each change. The split tool partitions faces; it does not construct a production dart with a specified intake or apex.
Disconnected panel islands are retained as separate pieces rather than losing their outlines.

5. Set seam allowance and roll width. Auto-Nest uses actual cutting-outline bounds, preserves the chosen rotation/grain direction and places shelves with a gap. It is a deterministic heuristic, not an optimal irregular-shape packer. Move/rotate pieces explicitly when needed. Roll length and yield update with placement; yield uses cut-outline area.
6. Open **Checks**. Repair geometric errors before exporting patterns. Material-limit warnings require review and physical calibration even when exports are enabled. Passing checks does not establish manufacturability.
7. Export DXF, physical-size SVG with a 100 mm scale reference, OBJ with UVs, source surface STL, CSV or project JSON. The STL contains source triangles; open shells stay open. SVG has a white background for printing. Print at **100%**, without fit-to-page, and verify the ruler.
8. **Save project** retains mesh, panel assignments, material preset, settings and placements. **Open project** reconstructs them. Legacy JSON reports contain no geometry and cannot be reopened. Browser recovery is offered on reload; keep a project file as your durable backup.

Shortcuts: Ctrl/Cmd+S save, Ctrl/Cmd+O open, Ctrl/Cmd+Z undo, Ctrl/Cmd+Shift+Z redo, Escape closes dialogs/drawers. Undo retains the most recent 20 checkpoints. Phones/tablets have a Controls drawer and stacked split view; use a single viewport for detailed work.

## Develop and verify

```sh
npm ci
npm run dev
npm run lint
npm test
npm run benchmark
npm run build
npx playwright install chromium
npm run test:browser
```

The browser harness serves the production build itself. `CHROMIUM_PATH` optionally selects an installed Chromium executable. `npm run benchmark` records geometric distortion and diagnostics for all eight templates at standard and high resolution. Benchmark timings are solver-only measurements on the executing machine, not end-to-end browser performance guarantees.

See `REVIEW.md` for the audit, release scope and remaining engineering gates. `qa/` contains the numerical benchmark, browser acceptance results, sample project/downloads and desktop/mobile screenshots. `tests/` contains reproducible regressions and the browser harness.
