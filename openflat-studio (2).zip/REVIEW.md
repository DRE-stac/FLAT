# OpenFlat Studio: audit and release review

Reviewed and rebuilt on 8 October 2026. Release 1.1.0.

## Verdict

The supplied app was a promising visual prototype, but it was not ready to trust with cutting files. This release closes concrete workflow, import, geometry-accounting and export faults and provides reproducible numerical and browser tests. It does **not** establish a world-class, production-calibrated flattening algorithm. The app is ready to run as a local pattern-development and inspection workspace, with its production limits made explicit.

## Defects found and corrected

| Original problem | Release behavior |
|---|---|
| Dependency installation failed because Vite's esbuild peer requirement conflicted with the explicit older esbuild dependency | Removed unused/conflicting direct dependencies; supplied a working npm lockfile and production build |
| Synchronous solver ran on the UI thread after a timeout; old requests could overwrite newer changes | Dedicated worker, request ownership and cancellation of superseded solves |
| STL normalization silently changed small/large imported dimensions | Preserved coordinates and dimensions; UI explicitly assumes millimeters |
| Large binary STL meshes were stride-sampled, dropping triangles and breaking topology | Explicit size/triangle limits and actionable rejection; no silent sampling |
| Binary STL headers beginning with `solid` could be misclassified | Exact binary byte-count detection plus ASCII validation and truncation checks |
| Fixed 0.25 mm welding and artificial area/length floors damaged small geometry | Relative precision welding, finite-coordinate validation, substantially reduced numerical floors |
| OBJ groups wrapped every eight pieces; malformed face indices were skipped | Unique group identifiers and strict invalid-index rejection |
| Disconnected islands under one piece ID lost boundaries when only the longest loop was exported | Islands become independently named panels; all triangles remain accounted for |
| Average-plane initialization collapsed some curved/developable panels | Added metric triangle unfolding with an initialization comparison against the original projection |
| Cross-hinge springs used 3D chord distances instead of flattened distances | Rest distances derived from the two unfolded triangles across each shared hinge |
| Auto-Nest mutated shared objects, then reran the solver with stale placement state | Immutable placement updates without a redundant solve; actual rotated cut bounds drive shelf packing |
| Nesting rotated wide parts without protecting chosen grain direction | Preserves rotations; orientation changes are explicit user actions |
| Roll metrics became stale when pieces moved; yield was artificially capped | Live layout summaries; yield derives from cutting-outline area without an arbitrary cap |
| Conditional React hook in ExportModal | Stable hook order; repeated open/close tested |
| Project JSON omitted geometry and had no import workflow | Versioned full-mesh projects, validation, reopen, undo/redo, and browser recovery |
| Cutting files could be emitted for missing boundaries, flips or overlapping parts | Checks drawer and disabled DXF/SVG/UV exports for detected geometric failures |
| SVG labels were not escaped and CSV names were not correctly quoted | XML escaping, CSV escaping and leading spreadsheet-formula protection on names |
| Dark-background SVG wasted ink and lacked a print-scale check | White physical-size SVG and a 100 mm calibration reference |
| Overlapping toolbar controls and viewport sizes broke in split/phone layouts | Separate tool rows, scrollable controls, ResizeObservers, fit framing and a phone controls drawer |
| Modal keyboard navigation and focus handling were missing | Modal semantics, focus management, Tab containment and Escape |
| External fonts and unused AI/server dependencies added needless requirements | System-font fallbacks; tested zero external requests and no API-key requirement |
| Surface STL was described as solid tooling and solver help implied calibrated physics | Explicit source-surface and geometric-estimate descriptions |

## Verification

- TypeScript check and production build passed.
- **16 numerical regression tests passed.** Coverage includes planes, developable strips/sleeves, all eight built-in models, import dimensions, binary/ASCII STL, invalid files, OBJ groups, nesting, live metrics, project roundtrip, export contents/escaping, holes, closed surfaces and disconnected panels.
- **19 browser acceptance checks passed** against the production build using Chromium. These cover worker startup, latest-request ownership, project download/reopen, undo/redo, nesting, diagnostics, repeated modals, all layouts, recovery, phone controls, all six downloads, export blocking and recoverable invalid-project errors.
- No uncaught JavaScript errors or external requests occurred in the tested browser workflow. Desktop viewport: 1600 × 1000. Phone viewport: 390 × 844. This is not a Safari/Firefox or physical-device matrix.
- Exact test names, benchmark output, browser results and screenshots are retained in `tests/` and `qa/`.

## Measured geometric results

The following are standard-resolution results with each template's default material, 45 iterations and 10 mm seam allowance. “Distortion” is relative edge-length error against the input triangulated mesh. Mean values are area-weighted magnitudes; peak values show the largest local deviation. Neither is stress or measured material strain. Timing covers one solver call in Node on this machine, excludes rendering/import/audit time, and is not a statistically stable performance benchmark.

| Template | Triangles | Mean edge distortion | Peak edge distortion | Blocking issues | Material warnings | Solver time |
|---|---:|---:|---:|---:|---:|---:|
| calibration_sheet | 2 | 0.00% | 0.00% | 0 | 0 | 2.5 ms |
| cylindrical_sleeve | 80 | 0.00% | 0.00% | 0 | 0 | 7.8 ms |
| automotive_seat | 960 | 1.22% | 12.61% | 0 | 2 | 82.8 ms |
| aerospace_radome | 1008 | 1.76% | 20.77% | 0 | 5 | 26.7 ms |
| marine_rib | 960 | 3.19% | 34.96% | 2 | 7 | 98.9 ms |
| footwear_last | 960 | 4.03% | 73.44% | 2 | 4 | 26.9 ms |
| apparel_bodice | 960 | 2.17% | 9.78% | 0 | 0 | 20.4 ms |
| tensile_canopy | 960 | 2.09% | 10.99% | 0 | 4 | 32.0 ms |

The flat sheet has zero measured edge distortion; the standard sleeve's peak is below 3 × 10⁻¹²%. This demonstrates the implemented behavior for these faceted developable fixtures. It does not validate arbitrary compound-curved surfaces. The sleeve follows faceted chord geometry, not an analytic continuous-cylinder circumference.

Some compound-curved examples have finite, complete outputs but unacceptable local distortion. The marine and footwear examples still contain a flipped/self-intersecting panel and are blocked for cutting exports. Increasing mesh resolution does not guarantee improvement: the high-resolution footwear case has roughly 86% peak edge distortion. Smaller average values cannot conceal that local failure. All high-resolution measurements and per-panel diagnostic messages are in `qa/benchmark.json`.

## Remaining production gates

1. **Calibrated anisotropic material response.** Current spring weights are heuristic. Young's modulus and thickness do not drive the relaxation. Measured warp/weft/bias curves, forming experiments and material-specific constitutive modeling are needed before predicting physical strain, stress, wrinkles, failures or composite drape.
2. **Constrained injective parameterization.** The implementation chooses a metric unfolding/projection seed and relaxes it. It has no formal global-convergence or bijectivity guarantee, and local area scaling is not a mathematically sufficient fold barrier. Add robust no-flip constraints and benchmark against accepted ground truth before production claims.
3. **Robust polygon geometry.** Seam allowance uses a clamped miter construction. Self-crossing outlines are detected and blocked, but arbitrary concave offsets and topology changes need a robust polygon offset/boolean implementation. Multiple boundary loops are blocked rather than exported as holes.
4. **Manufacturing seam design.** Notches indicate correspondence, but seam-length compatibility, seam ease, actual dart intake/apex, assembly order and grading need explicit controls and verification. The split tool is a face partition, not a complete engineered dart tool.
5. **Grain-constrained nesting.** Current packing is shelf-based with conservative outline bounds and preserved rotation. It is not a globally optimal polygon nester and does not model directional nap, paired/mirrored cutting, repeat registration or manufacturing kerf.
6. **Broader acceptance.** Test real customer meshes, unusual OBJ polygons, adversarial topology, large jobs near the import limit, multiple browsers, touch hardware, actual DXF consumers, printer scaling and physical assembly. OBJ n-gons use fan triangulation; triangulate non-convex polygons in CAD first.

These limits are material to the user's task. A polished UI and passing software checks do not by themselves make a cut pattern manufacturable. This release makes the app useful, reviewable and reproducible while explicitly preventing several known bad outputs.

## Delivery

`dist/` is the complete static build. `launch.mjs` and `Launch-Windows.bat` run it locally without npm dependencies once Node is installed. Source, npm lockfile, tests, numerical/browser evidence and instructions are included. No website deployment or changes to an existing domain were performed.
